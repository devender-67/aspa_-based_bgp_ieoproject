"""
tests/test_skeleton.py -- unit tests for parsing, paths, topology, aggregation, CLI.

Covers parsing, malformed input, receiver-visible path building, topology
lookups, aggregation (every row of the project's table) and a CLI smoke test.
Verdict-level tests for ASPA / policy arrive with Milestones 3 and 4.
"""

from __future__ import annotations

import copy
import json
from pathlib import Path

import pytest

from core.aggregation import combine
from core.models import Relation, Verdict
from core.parser import InputError, parse_scenario
from core.path_builder import build_receiver_path, compress
from core.topology import Topology
from main import main

ROOT = Path(__file__).resolve().parent.parent
EXAMPLES = ROOT / "examples"


def load(name: str) -> dict:
    """Load an example scenario from examples/."""
    return json.loads((EXAMPLES / f"{name}.json").read_text())


# ---------------------------------------------------------------- parser

def test_valid_example_parses() -> None:
    """A valid example parses, and an AS0 record keeps an empty provider list."""
    s = parse_scenario(load("valid"))
    assert s.export.exporting_as == 200
    assert s.aspa_records[100].providers == ()          # explicit "no providers"


@pytest.mark.parametrize("mutate, message", [
    (lambda d: d["route"].update(learned_from=100), "learned_from"),
    (lambda d: d["route"].update(as_path_received=["AS3x0"]), "not a valid AS number"),
    (lambda d: d["export"].update(receiving_as=200), "same AS"),
    (lambda d: d["topology"]["relationships"].append(
        {"type": "sibling", "ases": [100, 200]}), "unknown relationship type"),
    (lambda d: d["route"].update(learned_from=999, as_path_received=[999]), "not listed"),
    (lambda d: d["aspa_records"].append({"customer_as": 300, "providers": [1]}), "duplicate"),
    (lambda d: d["aspa_records"][0].update(status="maybe"), "status"),
    (lambda d: d.update(schema_version="9"), "schema_version"),
    (lambda d: d["route"].update(as_path_received=[300, 200]), "loop detection"),
])
def test_malformed_input_rejected(mutate, message) -> None:
    """Each kind of malformed input is rejected with a message naming the problem."""
    data = copy.deepcopy(load("valid"))
    mutate(data)
    with pytest.raises(InputError, match=message):
        parse_scenario(data)


def test_conflicting_relationship_rejected() -> None:
    """Two different relationships for the same pair are rejected."""
    data = load("valid")
    data["topology"]["relationships"].append({"type": "provider-customer", "provider": 200, "customer": 100})
    s = parse_scenario(data)
    with pytest.raises(InputError, match="conflicting"):
        Topology(s.ases, s.relationships)


def test_missing_and_empty_records_are_different() -> None:
    """A missing record and an AS0 (no providers) record are kept apart."""
    s = parse_scenario(load("unknown"))
    assert s.aspa_records[300].status.value == "missing"
    assert s.aspa_records[100].status.value == "present" and s.aspa_records[100].providers == ()


# ---------------------------------------------------------------- path builder

def test_compress_collapses_prepends() -> None:
    """Consecutive prepends collapse to one AS."""
    assert compress((100, 100, 200, 200, 200, 300)) == (100, 200, 300)


def _built(data: dict):
    """Parse a scenario and build its receiver-visible path."""
    s = parse_scenario(data)
    return build_receiver_path(s, Topology(s.ases, s.relationships))


def test_receiver_visible_path_with_prepends() -> None:
    """The exporter prepends itself the requested number of times."""
    data = load("invalid_policy")
    data["export"]["prepend_count"] = 3
    built = _built(data)
    assert built.receiver_visible_wire == (300, 300, 300, 200, 500)
    assert built.compressed_origin_first == (500, 200, 300)


def test_as_set_detected() -> None:
    """An AS_SET in the path is detected and the path is not compressed."""
    data = load("invalid_aspa")
    data["route"]["as_path_received"] = [600, [64500, 64501], 800]
    built = _built(data)
    assert built.has_as_set and built.compressed_origin_first is None


# ---------------------------------------------------------------- topology

def test_relationship_direction() -> None:
    """Relationships are read correctly from both sides."""
    s = parse_scenario(load("invalid_policy"))
    t = Topology(s.ases, s.relationships)
    assert t.relation(of=300, to=200) is Relation.PROVIDER
    assert t.relation(of=200, to=300) is Relation.CUSTOMER
    assert t.relation(of=300, to=400) is Relation.PEER
    assert t.relation(of=100, to=500) is None          # never inferred


# ---------------------------------------------------------------- aggregation

V, I, U, N = Verdict.VALID, Verdict.INVALID, Verdict.UNKNOWN, Verdict.NOT_IMPLEMENTED


@pytest.mark.parametrize("aspa, pol, overall", [
    (V, V, V), (I, V, I), (V, I, I), (I, I, I),
    (U, V, U), (V, U, U), (U, U, U), (I, U, I),
    (U, I, I),                                   # row missing from the spec table
    (N, N, N), (I, N, I), (N, V, N), (U, N, N),
])
def test_aggregation_table(aspa, pol, overall) -> None:
    """Every row of the aggregation table gives the expected overall verdict."""
    assert combine(aspa, pol) is overall


# ---------------------------------------------------------------- CLI

@pytest.mark.parametrize("name", ["valid", "invalid_aspa", "invalid_policy", "unknown"])
def test_cli_runs_and_reports_both_layers(name, capsys) -> None:
    """The CLI produces JSON with both layers and the expected overall verdict."""
    assert main(["--input", str(EXAMPLES / f"{name}.json"), "--json"]) == 0
    out = json.loads(capsys.readouterr().out)
    assert out["aspa"]["layer"] == "ASPA"
    assert out["export_policy"]["layer"] == "EXPORT_POLICY"
    assert out["overall"]["verdict"] == out["expected"]["overall"]


def test_cli_malformed_exit_code(capsys) -> None:
    """The CLI exits with code 2 and reports INPUT ERROR for a malformed file."""
    assert main(["--input", str(EXAMPLES / "malformed.json")]) == 2
    assert "INPUT ERROR" in capsys.readouterr().err
