"""Automated tests (run with: python3 -m pytest -v)."""
