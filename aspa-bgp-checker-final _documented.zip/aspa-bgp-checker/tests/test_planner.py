"""
tests/test_planner.py -- change planner: lemmas, theorem and example scenarios.
"""

from __future__ import annotations

import random
from pathlib import Path

import pytest

from core.aspa.ramp_logic import ramp_bounds
from core.aspa.validator import verdict_for_route
from core.models import AspaRecord, RecordStatus, Relation, Verdict
from core.planner.loader import load_change
from core.planner.plan import plan_change

CHANGES = Path(__file__).resolve().parent.parent / "examples" / "changes"
RANK = {Verdict.INVALID: 0, Verdict.UNKNOWN: 1, Verdict.VALID: 2}
ROLES = [Relation.CUSTOMER, Relation.PEER, Relation.PROVIDER]


def _random_case(rng: random.Random):
    """Generate a random path and a random ASPA database for property tests."""
    n = rng.randint(2, 6)
    path = tuple(rng.sample(range(1, 30), n))            # wire order, sender first
    db = {}
    for a in path:
        r = rng.random()
        if r < 0.25:
            continue                                      # no record
        provs = tuple(sorted(x for x in rng.sample(range(1, 30), rng.randint(0, 4)) if x != a))
        db[a] = AspaRecord(a, RecordStatus.PRESENT, provs)
    return path, db


# ------------------------------------------------------------ Lemma 1 (monotonicity)

def test_lemma1_adding_providers_never_makes_a_route_worse() -> None:
    """Lemma 1 on 4000 random cases: adding a provider never lowers a verdict."""
    rng = random.Random(42)
    for _ in range(4000):
        path, db = _random_case(rng)
        present = [a for a in db]
        if not present:
            continue
        a = rng.choice(present)
        extra = rng.choice([x for x in range(1, 31) if x != a])
        bigger = dict(db)
        bigger[a] = AspaRecord(a, RecordStatus.PRESENT, tuple(sorted(set(db[a].providers) | {extra})))
        role = rng.choice(ROLES)
        v1 = verdict_for_route(path, path[0], 99, role, db)
        v2 = verdict_for_route(path, path[0], 99, role, bigger)
        assert RANK[v2] >= RANK[v1], (path, db, a, extra, role)


def test_lemma2_withdrawing_a_record_never_creates_invalid() -> None:
    """Lemma 2 on 4000 random cases: withdrawing a record never creates INVALID."""
    rng = random.Random(7)
    for _ in range(4000):
        path, db = _random_case(rng)
        if not db:
            continue
        a = rng.choice(list(db))
        smaller = {k: v for k, v in db.items() if k != a}
        role = rng.choice(ROLES)
        v1 = verdict_for_route(path, path[0], 99, role, db)
        v2 = verdict_for_route(path, path[0], 99, role, smaller)
        if v1 is not Verdict.INVALID:
            assert v2 is not Verdict.INVALID


def test_first_publication_is_not_monotone() -> None:
    """Counter-example: publishing a FIRST record can turn UNKNOWN into INVALID."""
    path = (200, 300)                     # AS300 -> AS200, received by AS100 from customer AS200
    before: dict = {}
    after = {300: AspaRecord(300, RecordStatus.PRESENT, (250,))}
    assert verdict_for_route(path, 200, 100, Relation.CUSTOMER, before) is Verdict.UNKNOWN
    assert verdict_for_route(path, 200, 100, Relation.CUSTOMER, after) is Verdict.INVALID


def test_ramp_bounds_ordering() -> None:
    """On 2000 random cases min ramps never exceed max ramps."""
    rng = random.Random(3)
    for _ in range(2000):
        path, db = _random_case(rng)
        rb = ramp_bounds(tuple(reversed(path)), db)
        assert rb.min_up <= rb.max_up and rb.min_down <= rb.max_down


# ------------------------------------------------------------ examples / theorem

@pytest.fixture(scope="module")
def results():
    """Plan every example change once and share the results between tests."""
    return {f.stem: plan_change(load_change(str(f))) for f in sorted(CHANGES.glob("*.json"))}


def _plan(r, name):
    """Return the plan of a result whose name starts with ``name``."""
    return next(p for p in r["plans"] if p["name"].startswith(name))


@pytest.mark.parametrize("name", ["provider_switch", "add_backup", "transit_to_peering",
                                  "first_publication", "two_customers"])
def test_naive_plan_is_unsafe(results, name) -> None:
    """The naive plan is unsafe on the example changes."""
    assert not _plan(results[name], "naive")["safe"]


@pytest.mark.parametrize("name", ["provider_switch", "add_backup", "transit_to_peering",
                                  "first_publication", "two_customers"])
def test_best_plan_is_safe_and_not_slower_than_mbb(results, name) -> None:
    """The best plan is safe and never slower than make-before-break."""
    r = results[name]
    best, mbb = _plan(r, "best"), _plan(r, "make-before-break")
    assert best["safe"]
    if mbb["safe"]:
        assert best["minutes"] <= mbb["minutes"]


def test_theorem_mbb_safe_when_records_present_and_bgp_order_keeps_reachability(results) -> None:
    """Theorem 1: make-before-break is safe in these conditions."""
    for name in ("provider_switch", "add_backup", "two_customers"):
        assert _plan(results[name], "make-before-break")["safe"], name


def test_transit_to_peering_needs_new_provider_first(results) -> None:
    """For a downgrade, the new provider must be brought up first."""
    best = _plan(results["transit_to_peering"], "best")
    texts = [s["text"] for s in best["steps"]]
    up = next(i for i, t in enumerate(texts) if "bring up AS250" in t)
    re = next(i for i, t in enumerate(texts) if "reconfigure" in t)
    assert up < re
    assert best["exposure_route_minutes"] == pytest.approx(65.0)   # BETA + DELTA, the lower bound


def test_first_publication_best_plan_skips_union(results) -> None:
    """First publication: BGP first, then publish, one wait (70 minutes)."""
    best = _plan(results["first_publication"], "best")
    assert best["minutes"] == pytest.approx(70.0)
    assert not any("union" in s["text"] for s in best["steps"])


def test_broken_target_is_reported(results) -> None:
    """A wrong target record is reported and no plan is claimed safe."""
    r = results["broken_target"]
    assert r["target_safe"] is False and r["target_violations"] and not r["best_found"]
