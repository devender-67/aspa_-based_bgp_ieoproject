"""
tests/test_fixtures.py -- run every fixture in tests/fixtures/ and compare with its
hand-derived (proposed) expectations, including the Unknown-resolution output.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List

import pytest

from core.models import Verdict
from core.parser import load_scenario
from core.unknown_resolver import apply, collect_items, evaluate
from main import check

FIXTURES = sorted((Path(__file__).parent / "fixtures").glob("*.json"))


def run(path: Path):
    """Load a fixture and run the full pipeline on it."""
    s = load_scenario(str(path))
    topo, built, overall, unc = check(s)
    return s, built, overall, unc


def test_at_least_twenty_fixtures() -> None:
    """The project brief requires at least 20 fixtures."""
    assert len(FIXTURES) >= 20


@pytest.mark.parametrize("path", FIXTURES, ids=lambda p: p.stem)
def test_layer_and_overall_verdicts(path: Path) -> None:
    """ASPA, policy and overall verdicts match the hand-derived expectation."""
    s, _, overall, _ = run(path)
    exp = s.expected or {}
    assert overall.aspa.verdict.value == exp["aspa"], overall.aspa.reasons
    assert overall.policy.verdict.value == exp["export_policy"], overall.policy.reasons
    assert overall.verdict.value == exp["overall"]


@pytest.mark.parametrize("path", FIXTURES, ids=lambda p: p.stem)
def test_every_result_is_explained(path: Path) -> None:
    """Every layer gives reasons, a rule and a specification reference."""
    _, _, overall, _ = run(path)
    for layer in (overall.aspa, overall.policy):
        assert layer.reasons and layer.rule and layer.spec_refs
    assert overall.reason


@pytest.mark.parametrize("path", FIXTURES, ids=lambda p: p.stem)
def test_uncertainty_expectations(path: Path) -> None:
    """Bounds, class, influence, settling sets, suspected leaker and OTC status match."""
    s, built, overall, unc = run(path)
    exp: Dict[str, Any] = s.expected or {}
    target = unc.get("target")
    for key, model in (("any_record", "any_record_model"), ("consistent", "topology_consistent_model")):
        if key in exp:
            got = unc[model][target]
            assert (got["best"], got["worst"]) == (exp[key]["best"], exp[key]["worst"]), (key, got)
    if "classification" in exp:
        classes = {v["class"] for v in unc["classification"].values()}
        assert exp["classification"] in classes, unc["classification"]
    if "settling" in exp:
        got_sets = [sorted(x["items"]) for x in unc["settling_sets"]["sets"]]
        for want in exp["settling"]:
            assert sorted(want) in got_sets, got_sets
    if "settling_size" in exp:
        assert unc.get("status") == "COMPLETE" or unc["settling_sets"]["size"] == exp["settling_size"]
    if "influence" in exp:
        got_inf = {d["id"]: d["influence"] for d in unc["influence"]}
        for k, v in exp["influence"].items():
            assert got_inf[k] == pytest.approx(v)
    for m in exp.get("missing", []):
        joined = " ".join(overall.aspa.missing_info + overall.policy.missing_info)
        assert m.split(" (")[0].lower() in joined.lower(), joined
    if "suspected_leaker" in exp:
        suspects = {r.get("suspected_leaker") for r in overall.aspa.details["runs"].values()}
        assert exp["suspected_leaker"] in suspects
    if "otc_status" in exp:
        assert overall.policy.details["otc"]["status"] == exp["otc_status"]
    if "receiver_loop" in exp:
        assert built.receiver_loop is exp["receiver_loop"]


# ------------------------------------------------------------ properties

ASPA_ONLY_UNKNOWN = [p for p in FIXTURES
                     if run(p)[2].aspa.verdict is Verdict.UNKNOWN
                     and {i.layer for i in collect_items(load_scenario(str(p)))} == {"ASPA"}]


@pytest.mark.parametrize("path", ASPA_ONLY_UNKNOWN, ids=lambda p: p.stem)
def test_any_record_bounds_are_always_full_range(path: Path) -> None:
    """Theorem (docs/algorithm.md): if ASPA is UNKNOWN and only ASPA records are
    missing, the any-record model always gives best VALID and worst INVALID."""
    _, _, _, unc = run(path)
    b = unc["any_record_model"]["aspa"]
    assert (b["best"], b["worst"]) == ("VALID", "INVALID")


@pytest.mark.parametrize("path", FIXTURES, ids=lambda p: p.stem)
def test_resolver_never_contradicts_a_decided_layer(path: Path) -> None:
    """Completing missing data must never flip a layer that was already VALID/INVALID
    with no missing data of its own."""
    s, _, overall, _ = run(path)
    items = collect_items(s)
    if not items or len(items) > 3:
        return
    import itertools
    for ch in itertools.product(*[range(len(i.options)) for i in items]):
        a, p, o = evaluate(apply(s, items, ch))
        if overall.verdict is Verdict.INVALID:
            assert o is Verdict.INVALID or overall.aspa.verdict is Verdict.UNKNOWN \
                or overall.policy.verdict is Verdict.UNKNOWN
