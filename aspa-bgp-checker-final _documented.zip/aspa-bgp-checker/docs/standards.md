# Pinned standards and project decisions

Status: decisions taken by the project team on 21 Nov 2026; fixtures still **proposed**
until mentor review.

## Documents

| Purpose | Document | Sections used |
|---|---|---|
| ASPA path verification (Layer 1) | **draft-ietf-sidrops-aspa-verification-31** (17 Nov 2026, Internet-Draft, not an RFC) | 4 registration, 5.1 interaction with other checks, 5.3 provider authorization, 5.4 ramp bounds, 5.5 upstream, 5.6 downstream, 5.7 mitigation, 6.4 complex relationships |
| OTC + BGP Roles (Layer 2) | RFC 9234 (Proposed Standard) | 3.1 role propagation rules, 5 OTC |
| Export conventions | Gao-Rexford valley-free model; RFC 7908 leak taxonomy | baseline table |
| Loop detection | RFC 4271 Sec. 9.1.2 | warnings only |

Why -31 and not -28: -31 is the newest revision and its text could be checked
line by line. Note the renumbering in -31: upstream is 5.5 and downstream 5.6
(they were 5.4 and 5.5 in -26). If a newer revision appears, re-check Sec. 5.

## Decisions

| # | Question | Decision |
|---|---|---|
| Q1 | ASPA revision | -31 |
| Q2 | UNKNOWN + INVALID | INVALID. Plus the Unknown-resolution engine (docs/algorithm.md Sec. 5) |
| Q3 | Undeclared receiver-exporter relationship | Run both algorithms; same result -> keep, different -> UNKNOWN with both shown |
| Q4 | Route servers and complex relationships | In scope: transparent / non-transparent RS, complex with optional per-prefix roles, Sec. 6.4 downstream fallback |
| Q5 | BGP Roles not configured | OTC reported as NOT_APPLICABLE ("roles not configured"); valley-free still enforced |
| Q6 | Hypothetical records contradicting topology | Both models reported: any-record and topology-consistent |
| Q7 | ASPA VALID + POLICY INVALID | Main: complex relationship where both ASes correctly list each other (C01). Secondary: stale over-permissive record (X02) |
| Q8 | Receiver ASN already in path | Warning + note, not an input error (legitimate, e.g. path poisoning); verdicts still computed |

## Modelling assumptions

1. Paths in JSON are wire order (leftmost = most recent).
2. `missing` and `invalid_signature` -> "No Attestation". `providers: []` or `[0]`
   -> explicit "no providers". These are different.
3. One ASPA record per AS in the synthetic DB (the draft unions several).
4. Relationships come only from the topology; nothing is inferred for verdicts.
   (The resolver's prediction may use published ASPA records as evidence; it never
   changes a verdict.)
5. OTC in the input is the state as the exporter received it.
6. RFC 9234 Roles are never configured on complex sessions, so OTC ingress/egress
   rules are skipped on those sessions.
7. Route servers: an RS exports only to RS-clients in this model.
