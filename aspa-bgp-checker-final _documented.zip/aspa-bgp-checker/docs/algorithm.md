# Algorithms

Pinned: draft-ietf-sidrops-aspa-verification-31 (17 Nov 2026), RFC 9234.
Path notation: COMPRESSED_AS_PATH A(1..N), A(1) = origin, A(N) = the exporter
(the receiver's neighbour). The receiver itself is A(N+1) and is not in the path.

## 1. Receiver-visible path

```
Procedure BUILD_RECEIVER_PATH(received, X, Y, prepend)
  1. If X is a transparent route server of client Y: visible := received
     Else visible := [X] * prepend + received
  2. If Y occurs in visible: warn (Y discards it by loop detection, RFC 4271 9.1.2)
  3. If visible has an AS_SET: no compressed path (ASPA step 3 gives INVALID)
  4. Else compressed := reverse(visible) with consecutive repeats removed
```

## 2. Layer 1 -- ASPA (receiver's view)

```
Procedure AUTHORIZED(x, y)                                         [Sec. 5.3]
  1. No valid ASPA for x (missing / bad signature)  -> "No Attestation"
  2. y in x's provider set                           -> "Provider+"
  3. otherwise                                        -> "Not Provider+"

Procedure RAMP_BOUNDS(A(1..N))                                     [Sec. 5.4]
  1. max_up   = min I : AUTHORIZED(A(I),A(I+1)) = Not Provider+      (else N)
  2. min_up   = min I : AUTHORIZED(A(I),A(I+1)) != Provider+         (else N)
  3. max_down = N-J+1, J = max j : AUTHORIZED(A(j),A(j-1)) = Not Provider+   (else N)
  4. min_down = N-J+1, J = max j : AUTHORIZED(A(j),A(j-1)) != Provider+      (else N)

Procedure SELECT_ALGORITHM(Y's view of X)
  customer, peer, RS, RS-client -> upstream   (Sec. 5.5)
  provider                      -> downstream (Sec. 5.6)
  complex, no prefix role       -> downstream (Sec. 6.4 fallback)
  undeclared                    -> run both; equal results -> that result, else UNKNOWN

Procedure ASPA_VERIFY(A, algorithm)                          [Sec. 5.5 / 5.6]
  1. empty path                                         -> INVALID
  2. A(N) != X  (skipped if upstream and Y is an RS-client) -> INVALID
  3. AS_SET present                                     -> INVALID
  4. upstream: max_down = min_down = 0
     max_up + max_down < N                              -> INVALID
  5. min_up + min_down < N                              -> UNKNOWN
  6. otherwise                                          -> VALID
```

Explanation rules: on INVALID the deciding hop is the first Not Provider+ up
hop (and for downstream also the last Not Provider+ down hop). The suspected
leak point is the AS just after the up-ramp apex, A(max_up + 1). ASPA locates
it; it cannot prove who leaked.

## 3. Layer 2 -- export policy (exporter's view)

```
Procedure VALLEY_FREE(source, target)              [RFC 9234 Sec. 3.1]
  1. configured exception matches               -> VALID
  2. target in {customer, RS-client}            -> VALID
  3. source in {local, customer}                -> VALID
  4. source and target both known               -> INVALID
  5. otherwise                                  -> UNKNOWN

Procedure OTC_CHECK(otc, source, target, X)        [RFC 9234 Sec. 5]
  0. BGP Roles not configured / not stated      -> NOT_APPLICABLE (reported only)
  1. OTC present, source customer or RS-client  -> VIOLATION
  2. OTC present, source peer P, value != P     -> VIOLATION
  3. OTC absent, source provider/peer/RS        -> OTC := source AS
  4. OTC present, target provider/peer/RS       -> VIOLATION
  5. OTC absent, target customer/peer/RS-client -> sent with OTC := X
  (steps 1-3 skipped on complex sessions; unknown OTC -> try every state)

Procedure EXPORT_POLICY_VERIFY
  INVALID if either check is a violation, UNKNOWN if either is unknown, else VALID
```

## 4. Aggregation

INVALID > UNKNOWN > VALID (configurable). Includes ASPA UNKNOWN + POLICY INVALID -> INVALID.

## 5. Unknown resolution

```
Procedure RESOLVE_UNKNOWN(scenario)
  Input : scenario; Output: bounds, classification, influence, settling sets
  1. Items: missing ASPA records on the path (options = which path neighbours
     the record lists), undeclared relationships (3 options), complex roles
     (3 options), unknown OTC (absent / = source / other).
  2. Enumerate all completions (exhaustive up to 4096, else seeded sample).
  3. For each completion run the REAL Layer 1, Layer 2 and aggregation.
  4. Topology-consistent completion: every guessed record matches the declared
     topology (Sec. 4 registration rules) AND every guessed relationship matches
     the records that are published.
  5. Bounds per model; classification over consistent completions:
       {INVALID} -> LATENT-INVALID, {VALID} -> LATENT-VALID, else UNDETERMINED
  6. Influence(k) = share of assignments of the other items for which
     changing only item k changes the verdict.
  7. Settling set = smallest S such that, once S is known (ASPA items at
     their correct value), the verdict no longer depends on the others.
```

### Theorem (why the topology-consistent model is needed)

*If the ASPA verdict is UNKNOWN and the only missing data are ASPA records,
then under the any-record model the best case is VALID and the worst case is
INVALID.*

Proof. UNKNOWN means max_up + max_down >= N and min_up + min_down < N.
(a) Let every missing AS list all its path neighbours. Each "No Attestation"
hop becomes "Provider+" and no "Not Provider+" hop changes, so the new min
bounds equal the old max bounds: sum >= N, VALID.
(b) Let every missing AS list none of them. Each "No Attestation" hop becomes
"Not Provider+", so the new max bounds equal the old min bounds: sum < N, INVALID.
Each case is one record per AS, so both completions are allowed. QED.

Consequence: "best VALID, worst INVALID" carries no information for an ASPA
Unknown. Useful information comes only from constraints: the declared
relationships and the records that are already published. The test
`test_any_record_bounds_are_always_full_range` checks this on every fixture.

### Why it matters

Sec. 5.7 tells routers to treat Unknown at the same preference as Valid.
A LATENT-INVALID result marks a route that standard ASPA accepts today but
that correct deployment would reject: a hidden leak (fixtures P18, invalid_policy).
The settling set tells the operator exactly whose record to ask for.

### Limits

* The prediction is only as good as the declared topology.
* Exhaustive enumeration is exponential in the number of items; above 4096
  completions a fixed-seed sample is used and settling sets are skipped.
* For ASPA-only cases, closed-form bounds from the ramp formulas are possible
  (future work).
