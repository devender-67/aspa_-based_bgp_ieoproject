# User guide

This guide explains the two input formats (a route export to check, and an ASPA change to
plan), every field, and how to read the output. Ready-to-edit templates are in
`examples/templates/`.

---

## 1. Checking a route export

```bash
python3 main.py --input my_route.json            # text report
python3 main.py --input my_route.json --json     # JSON
python3 main.py --input my_folder --summary      # one line per file in a folder
```

### 1.1 Minimal example

```json
{
  "schema_version": "0.1",
  "scenario_id": "MY-01",
  "description": "AS200 sends its customer AS300's route to its provider AS100.",
  "topology": {
    "ases": [100, 200, 300],
    "relationships": [
      {"type": "provider-customer", "provider": 100, "customer": 200},
      {"type": "provider-customer", "provider": 200, "customer": 300}
    ]
  },
  "aspa_records": [
    {"customer_as": 300, "status": "present", "providers": [200]},
    {"customer_as": 200, "status": "present", "providers": [100]},
    {"customer_as": 100, "status": "present", "providers": []}
  ],
  "route": {
    "prefix": "203.0.113.0/24",
    "as_path_received": [300],
    "learned_from": 300,
    "otc": {"present": false}
  },
  "export": {"exporting_as": 200, "receiving_as": 100, "prepend_count": 1},
  "policy_context": {"bgp_roles_configured": true}
}
```

### 1.2 Field reference

| Field | Required | Meaning |
|---|---|---|
| `schema_version` | yes | must be `"0.1"` |
| `scenario_id`, `description` | no | names the scenario in the report |
| `review_status` | no | default `"proposed"` |
| `topology.ases` | yes | every AS used anywhere in the file |
| `topology.relationships` | yes | list of relationships (see 1.3) |
| `aspa_records` | no | list of ASPA records (see 1.4) |
| `route.as_path_received` | yes | the AS_PATH **as the exporter received it**, newest AS first, origin last. `[]` if the exporter originates the prefix. A nested list is an AS_SET, e.g. `[300, [64500, 64501]]` |
| `route.learned_from` | yes | the neighbour the route came from; must equal the first AS of the path. `null` if the exporter originates the prefix |
| `route.prefix` | no | needed only for complex relationships with per-prefix roles |
| `route.otc` | no | `{"present": false}`, `{"present": true, "value": 200}`, or `null` / omitted = OTC state unknown |
| `export.exporting_as` | yes | the AS that wants to send the route (X) |
| `export.receiving_as` | yes | the neighbour that would receive it (Y) |
| `export.prepend_count` | no | how many times X adds its own AS number (default 1) |
| `policy_context.bgp_roles_configured` | no | `true` (default), `false` or `null` (not stated). If not `true`, OTC is reported as NOT_APPLICABLE |
| `policy_context.export_exceptions` | no | `[{"learned_from": 400, "receiving_as": 500, "reason": "partial transit"}]`; `learned_from` may be omitted to match any source |
| `expected` | no | the expected result (used by the test fixtures) |

AS numbers may be written as `300`, `"300"` or `"AS300"`.

### 1.3 Relationship types

| `type` | Fields | Meaning |
|---|---|---|
| `provider-customer` | `provider`, `customer` | the customer pays the provider for transit |
| `peer` | `ases: [a, b]` | settlement-free peering |
| `route-server` | `rs`, `client`, `transparent` (default `true`) | IXP route server; a transparent one does not add its AS number |
| `complex` | `ases: [a, b]`, optional `prefix_roles` | hybrid relationship whose role depends on the prefix |

`prefix_roles` example:

```json
{"type": "complex", "ases": [200, 300],
 "prefix_roles": [
   {"prefix": "203.0.113.0/24", "type": "provider-customer", "provider": 200},
   {"prefix": "198.51.100.0/24", "type": "peer"}]}
```

Relationships are never guessed. If one that is needed is missing, the result is UNKNOWN and
the report says which relationship to declare.

### 1.4 ASPA records

| `status` | `providers` | Meaning |
|---|---|---|
| `present` | list of provider ASes | a valid record. `[]` (or `[0]`) is an **AS0 record**: "I have no providers" |
| `missing` | (none) | the AS has no record (No Attestation) |
| `invalid_signature` | (none) | the record fails validation (treated as No Attestation) |

An AS that does not appear in `aspa_records` at all is treated like `missing`.
Only one record per AS is allowed; list all its providers in that record.

### 1.5 Reading the text report

| Section | Content |
|---|---|
| 1-2 | the received AS_PATH and the path the receiver will see (after prepending), plus the compressed, origin-first path used by the ASPA draft |
| 3-5 | exporting AS, receiving AS and their relationship |
| 6 | the ASPA records examined |
| 7 | **ASPA verification**: verdict, procedure used (upstream / downstream), deciding hop, rule, draft section, hop table and ramp bounds |
| 8 | **Export policy**: valley-free and OTC checks, rule, RFC section |
| 9 | OTC status |
| 10-11 | **overall verdict** and the aggregation rule that produced it |
| 12 | missing information and, if anything is UNKNOWN, the **Unknown analysis**: items, best/worst verdicts in both models, the class (LATENT-VALID / LATENT-INVALID / UNDETERMINED), influence of each item and the settling sets |

For fixtures, the last line compares the result with the expected answer.

### 1.6 Verdicts

| Verdict | Meaning |
|---|---|
| VALID | the layer passed with enough information |
| INVALID | a proven violation (a leak in the path, a forbidden export, an AS_SET, ...) |
| UNKNOWN | information is missing (a record or a relationship); never treated as INVALID |
| NOT_IMPLEMENTED | reserved for checks the tool does not support |

Overall verdict precedence: INVALID > NOT_IMPLEMENTED > UNKNOWN > VALID.

### 1.7 Errors

Malformed input is never turned into a verdict. The tool prints `INPUT ERROR: ...` naming the
field and exits with code 2, for example:

```
INPUT ERROR: route: learned_from is AS100 but the received AS_PATH starts with AS300
```

---

## 2. Planning an ASPA change

```bash
python3 main.py --input my_change.json --plan
python3 main.py --input my_change.json --plan --json
```

### 2.1 Example

```json
{
  "schema_version": "0.1",
  "kind": "aspa-change",
  "change_id": "MY-CHANGE",
  "description": "AS300 moves its transit from AS200 to AS250.",
  "topology_before": {"relationships": [
    {"type": "peer", "ases": [100, 101]},
    {"type": "provider-customer", "provider": 100, "customer": 200},
    {"type": "provider-customer", "provider": 101, "customer": 250},
    {"type": "provider-customer", "provider": 200, "customer": 300}]},
  "topology_after": {"relationships": [
    {"type": "peer", "ases": [100, 101]},
    {"type": "provider-customer", "provider": 100, "customer": 200},
    {"type": "provider-customer", "provider": 101, "customer": 250},
    {"type": "provider-customer", "provider": 250, "customer": 300}]},
  "aspa_before": [{"customer_as": 300, "status": "present", "providers": [200]}],
  "aspa_after":  [{"customer_as": 300, "status": "present", "providers": [250]}],
  "parameters": {"delta_minutes": 60, "bgp_convergence_minutes": 5}
}
```

### 2.2 Field reference

| Field | Meaning |
|---|---|
| `kind` | must be `"aspa-change"` |
| `topology_before`, `topology_after` | BGP links before and after; only `provider-customer` and `peer` are supported |
| `aspa_before`, `aspa_after` | ASPA records before and after (same format as 1.4); an AS absent before and present after is a **first publication** |
| `parameters.delta_minutes` | Delta: the longest a validator may lag behind the latest record (default 60) |
| `parameters.bgp_convergence_minutes` | Beta: how long one BGP change takes to settle (default 5) |
| `parameters.validators` | ASes that run ASPA validation: a list or `"all"` (default) |
| `parameters.origins` | ASes whose prefixes are simulated: a list or `"all"` (default) |

### 2.3 Reading the plan report

The report first says which records and BGP links change and whether the **start** and the
**target** configurations are safe (if the target is not safe, the new records are wrong and no
order of steps can help; the broken routes are listed).

It then shows three plans:

| Plan | What it is |
|---|---|
| naive | publish every new record, do every BGP change, wait once |
| make-before-break | add new providers first (union record), wait, BGP changes, publish the final record, wait |
| best | the plan found by the search: fastest safe plan, then least leak exposure |

For each plan: SAFE / UNSAFE, total minutes, **leak exposure** in route-minutes (leaks that the
final records reject but some validator still accepts, multiplied by how long), routes at risk,
and each step. Unsafe steps list which validator would reject which legitimate route under which
record version.

---

## 3. Running the tests

```bash
python3 -m pytest -v                         # everything (194 test cases)
python3 -m pytest tests/test_fixtures.py -v  # only the 34 fixtures
python3 main.py --input tests/fixtures --summary
```

To change or add fixtures, edit `tools/make_fixtures.py` and run
`python3 tools/make_fixtures.py`; write the expected answer by hand from the specification
before running the checker on it.
