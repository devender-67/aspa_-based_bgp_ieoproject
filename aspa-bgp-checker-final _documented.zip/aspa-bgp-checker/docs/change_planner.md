# Safe ASPA changes under validator lag

## 1. Problem

An AS changes its upstream connectivity (new provider, backup provider,
transit -> peering, first ASPA publication, several customers moving at once).
Two systems must change together:

* **BGP** (links / sessions), which converges in about BETA minutes, and
* **ASPA records**, which reach validators after a delay of up to DELTA
  minutes, with different validators updating at different times.

While a record change is spreading, validators disagree. A wrong order causes:

* **outage**: a legitimate route is INVALID at some validator and is dropped,
  or a BGP step order leaves an AS with no route at all;
* **exposure**: a leak that the target configuration would reject is still
  accepted, because an old provider is still listed somewhere.

## 2. What exists already (literature check, Nov 2026)

| Work | What it gives | What it does not give |
|---|---|---|
| draft-ietf-sidrops-aspa-verification, older -16/-17 ("Make Before Break") and -30/-31 Sec. 4 | advice: single ASPA object, list standby providers in advance, make-before-break | no model of validator lag, no proof, no ordering of BGP steps, no exposure measure |
| Operator guides (e.g. the xTom blog "What Is ASPA") | "add the new provider before the session is up, remove the old one after" | same rule of thumb, unverified |
| APNIC MyAPNIC ASPA checks | validates a change against current BGP routes before submission | one snapshot; no multi-validator transition window |
| RPKI Time-of-Flight (Fontugne et al., PAM 2023); Kristoff et al. (IMC 2020) | measured RPKI propagation delays and inconsistent relying-party fetching | measurement only; ROA-focused |
| Consistent network updates (SDN), e.g. Reitblatt et al., "Abstractions for Network Update", SIGCOMM 2012 | order updates so every intermediate state satisfies a policy | data-plane forwarding, not RPKI/ASPA |

Gap addressed here: a formal model of ASPA changes under bounded validator lag;
proofs of when make-before-break is sufficient and where it fails; automatic
synthesis of the fastest safe plan; and a measure of the leak-exposure window.
(Quick search only; a full survey is still needed before claiming novelty.)

## 3. Model

* Configuration C = (L, D): link set and ASPA records.
* R(L): every route each AS receives, from Gao-Rexford propagation
  (core/planner/routing.py).
* A changing AS c moves through record stages old -> (union) -> new.
  union = providers before the change + providers after it.
* Pending versions: after a PUBLISH, each validator may hold any version
  published since the last WAIT DELTA.
* Actions: PUBLISH (instant), BGP step (BETA minutes; routes of the link sets
  before and after the step both in use), WAIT DELTA.

```
Procedure SAFE(state)
  Input : link sets in use, pending record versions
  Output: true/false, violations, exposed leaks
  1. For each link set L in use: every (AS, origin) pair reachable both before
     and after the whole change must be reachable in L
  2. For each route r in R(L) and each combination of record versions the
     validators may hold for the ASes on r: verdict(r) != INVALID
  3. Exposed := leaks (from LEAK_PROBES) that are INVALID under the target
     records but not INVALID under some possible view
```

```
Procedure PLAN_CHANGE(C0, C1, DELTA, BETA)
  1. If C0 or C1 is unsafe -> report its broken routes; stop (Theorem 2)
  2. NAIVE := publish all new records; all BGP steps; WAIT
  3. MBB   := publish unions (or first records); WAIT; BGP steps;
              publish new records (and pure removals); WAIT
  4. BEST  := Dijkstra over SAFE states, cost (minutes, exposure, steps)
  5. Report all three with violations, duration and exposure
```

## 4. Results proved

**Lemma 1 (adding providers is monotone).** If D' differs from D only by extra
providers in present records, then for every route, verdict(D') >= verdict(D)
(INVALID < UNKNOWN < VALID).
*Proof.* Only "Not Provider+" hops can become "Provider+". max_up and min_up are
the first index of a bad hop, so they can only grow; max_down and min_down are
N - J + 1 for the last bad hop J, so they can only grow too. The thresholds in
Sec. 5.5/5.6 are monotone in these sums. QED. (Checked on 4,000 random cases in
tests/test_planner.py.)

**Lemma 2 (withdrawing a record never creates INVALID).** A withdrawn record
turns hops into "No Attestation". The max bounds ignore No Attestation, so they
cannot shrink, and INVALID needs max_up + max_down < N. QED. It can turn VALID
into UNKNOWN (a security loss, not an outage).

**Lemma 3 (first publication is not monotone).** Counter-example: AS300 has no
record; publishing {AS250} turns the route AS200 AS300 (received by AS100 from
customer AS200) from UNKNOWN into INVALID. So a first ASPA is the riskiest step.

**Lemma 4 (correct records never reject valley-free routes).** If every
present record lists exactly the AS's providers in L (subsets: Lemma 1), every
route in R(L) is non-INVALID. *Proof.* Routes received from a customer or peer
are pure up-ramps: every hop is Provider+ or No Attestation, so max_up = N.
Routes received from a provider are up-ramp, at most one peer hop, down-ramp;
the up part gives max_up >= K and the down part max_down >= N - L + 1 with
L - K <= 1, so the sum is >= N. QED.

**Theorem 1 (when make-before-break is safe).** Assume records of ASes that do
not change are correct for both L0 and L1, and the BGP steps are ordered so
that reachability is kept (new links up before old ones go down; a type
change only after the replacement provider is up). Then
`publish unions -> WAIT -> BGP steps -> publish new -> WAIT` is safe for every
validator lag <= DELTA.
*Proof.* Before the BGP steps every view of c is old or union, both supersets of
c's providers in L0. During the steps every view is union (the WAIT settled it),
a superset of c's providers in every intermediate link set. After the steps the
views are union or new, supersets of c's providers in L1. Lemma 4 plus Lemma 1
give no INVALID route; the ordering gives reachability. QED.

**Theorem 2 (necessity).** If C0 or C1 is unsafe, no plan is safe (they are the
first and last states). The planner reports the broken routes instead.

**Theorem 3 (exposure lower bound for downgrades).** If provider X of c becomes
a peer (the link stays) and some leak through X is rejected under the target
records, every safe plan accepts that leak for at least BETA + DELTA minutes.
*Proof.* Removing X before the session is reconfigured makes c's routes via X
INVALID at updated validators (unsafe). So the removal is published at the
earliest just after the reconfiguration (BETA minutes with X still listed), and
validators may keep the old view for DELTA more minutes. QED. The planner meets
this bound exactly (e.g. 5 + 60 = 65 route-minutes per exposed leak).

**Observation (one-wait plans for multihomed ASes).** If c keeps a provider in
old and new throughout, `shut down old link -> publish new -> WAIT -> bring up
new link` is safe and saves DELTA minutes compared with make-before-break, at
the cost of reduced redundancy during the wait. The search finds this plan
automatically; the textbook rule does not.

## 5. Where the textbook rule fails (found by the planner)

* **Transit -> peering with the wrong BGP order**: reconfiguring the old
  provider before the new one is up leaves the AS without transit.
* **Pure provider removal published before the BGP change**: routes still
  using the removed provider become INVALID.
* **First publication**: the union trick needs a covering record; publishing
  only the new provider set first breaks routes still using the old provider.
* **Broken target**: a new record that forgets a provider makes every plan
  unsafe; the planner says so up front.

## 6. Evaluation (synthetic, offline)

Setup: `tools/evaluate_planner.py`; 19-AS tiered topologies (3 Tier-1 full mesh,
6 Tier-2 with 1-2 Tier-1 providers and 20% Tier-2 peering, 10 stubs with 1-2
providers); six change kinds, 8 scenarios each; DELTA = 60 min, BETA = 5 min;
two ASPA adoption levels (correct records published by 30% / 70% of ASes; the
changing ASes always publish, except in first-publication cases).
Make-before-break baseline uses the sensible BGP order (bring up, then
reconfigure, then shut down). Raw data: results/planner_eval_adopt30.csv and
results/planner_eval_adopt70.csv.

| | naive | make-before-break | planner (best) |
|---|---|---|---|
| unsafe plans, 30% adoption | 48/48 | 0/48 | 0/48 |
| unsafe plans, 70% adoption | 48/48 | 0/48 | 0/48 |
| mean duration, 30% / 70% (min) | 70 / 70 | 110 / 110 | 84 / 90 |
| mean exposure, 30% / 70% (route-min) | 72 / 48 (but unsafe) | 321 / 145 | 162 / 87 |
| planner faster than make-before-break | | | 21/48 and 16/48 |
| planner slower than a safe make-before-break | | | 0/96 |

Reading: changing everything at once put legitimate routes at risk in every
scenario (6-52 routes on average depending on the kind). Make-before-break was
always safe, consistent with Theorem 1, but slow and with a long exposure tail.
The planner was never slower, saved one DELTA when a multihomed AS could keep a
provider during the switch, and roughly halved exposure. First publication
and provider switches gained the most; adding a backup gained nothing (the
textbook plan is already optimal there).

## 7. Limits

* Only provider-customer and peer links in the route simulator (route servers
  and complex relationships are handled by the checker but not by the planner).
* Availability is checked per received route (conservative): any legitimate
  route rejected anywhere counts as unsafe, even if a backup route exists.
* Exposure uses a synthetic leak model (RFC 7908 types 1-4 by every AS).
* Search is exponential in the number of actions; capped at 5,000 states.
* DELTA is one bound for all validators; per-validator lags are future work.
