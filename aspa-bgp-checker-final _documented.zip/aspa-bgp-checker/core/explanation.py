"""
core/explanation.py -- turn results into a terminal report or a JSON object.
All wording comes from the layer results and the resolver; this module only lays it out.
"""

from __future__ import annotations

import os
import sys
from typing import Any, Dict, List

from core.models import LayerResult, OverallResult, Scenario, Verdict
from core.path_builder import BuiltPath, format_wire
from core.topology import Topology

_COL = {"VALID": "\033[32m", "INVALID": "\033[31m", "UNKNOWN": "\033[33m",
        "NOT_IMPLEMENTED": "\033[90m"}
_RESET, _BOLD = "\033[0m", "\033[1m"


def _use_colour(flag: bool) -> bool:
    """Use colours only if asked, stdout is a terminal and NO_COLOR is not set."""
    return flag and sys.stdout.isatty() and os.environ.get("NO_COLOR") is None


def _v(text: str, colour: bool) -> str:
    """Colour a verdict word (VALID / INVALID / UNKNOWN) for the terminal."""
    return f"{_COL.get(text, '')}{_BOLD}{text}{_RESET}" if colour and text in _COL else text


def _layer_block(num: str, title: str, r: LayerResult, c: bool) -> List[str]:
    """Format one layer result: verdict, reasons, rule and spec references."""
    lines = [f"{num}. {title}: {_v(r.verdict.value, c)}   ({r.summary})"]
    lines += [f"      - {t}" for t in r.reasons if t]
    if r.rule:
        lines.append(f"      Rule: {r.rule}")
    lines.append(f"      Spec: {'; '.join(r.spec_refs)}")
    return lines


def _hop_table(r: LayerResult) -> List[str]:
    """Format the per-hop authorized() table and the ramp bounds of each ASPA run."""
    out = []
    for alg, run in r.details.get("runs", {}).items():
        if "ramps" not in run:
            continue
        rp = run["ramps"]
        out.append(f"      [{alg}] N={rp['N']}  max_up={rp['max_up_ramp']} min_up={rp['min_up_ramp']}  "
                   f"max_down={rp['max_down_ramp']} min_down={rp['min_down_ramp']}")
        for h in run.get("hops", []):
            arrow = f"AS{h['customer']} -> AS{h['provider']}"
            idx = f"i={h['i']}" if "i" in h else f"j={h['j']}"
            out.append(f"         {h['dir']:<4} {idx:<4} authorized({arrow}) = {h['result']}")
    return out


def _resolver_block(u: Dict[str, Any], c: bool) -> List[str]:
    """Format the Unknown-resolution analysis: items, bounds, class, influence, settling sets."""
    if u.get("status") != "ANALYSED":
        return [f"    Uncertainty analysis: {u.get('note', u.get('status'))}"]
    out = [f"    Uncertainty analysis ({u['method']}, {u['completions']} completions, "
           f"{u['consistent_completions']} topology-consistent; analysing {u['target'].upper()} verdict)"]
    out.append("    Unknown items:")
    for it in u["items"]:
        out.append(f"      - [{it['layer']}] {it['text']}")
    for model, label in (("any_record_model", "Any-record model         "),
                         ("topology_consistent_model", "Topology-consistent model")):
        b = u[model]
        for layer in ("aspa", "policy", "overall"):
            if layer == u["target"] or layer == "overall":
                d = b[layer]
                if d["count"]:
                    out.append(f"    {label} {layer:<7}: best {_v(d['best'], c)}, worst {_v(d['worst'], c)}  "
                               f"{d['distribution']}")
    for layer, cl in u["classification"].items():
        out.append(f"    Classification ({layer}): {_v(cl['class'], False)} -- {cl['text']}")
    out.append("    Influence (share of cases where this item alone flips the verdict):")
    for inf in u["influence"]:
        tag = "critical" if inf["critical"] else "does not matter"
        out.append(f"      {inf['id']:<18} {inf['influence']:.2f}  {tag}")
    st = u.get("settling_sets")
    if st:
        if st["size"] == 0:
            out.append(f"    Settling set: none needed -- {st['text']}")
        elif st["size"]:
            for sset in st["sets"]:
                out.append(f"    Smallest settling set: {{{', '.join(sset['items'])}}} -> "
                           f"{' or '.join(sset['settles_to'])}")
        else:
            out.append(f"    Settling set: {st['text']}")
    return out


def render_text(s: Scenario, built: BuiltPath, topo: Topology, result: OverallResult,
                uncertainty: Dict[str, Any], colour: bool = True) -> str:
    """Render the full terminal report for one scenario.

    Sections: input path, receiver-visible path, relationships, ASPA records
    examined, both layer results with rules and spec references, the overall
    verdict, the Unknown analysis and any data warnings.
    """
    c = _use_colour(colour)
    x, y = s.export.exporting_as, s.export.receiving_as
    bar = "=" * 78
    out: List[str] = [bar, f"Scenario: {s.scenario_id}   [{s.review_status}]"]
    if s.description:
        out.append(f"  {s.description}")
    out.append(bar)
    out.append(f" 1. Input AS_PATH (received by AS{x}): {format_wire(built.received_wire)}"
               + (f"   prefix {s.route.prefix}" if s.route.prefix else ""))
    out.append(f" 2. Receiver-visible AS_PATH:         {format_wire(built.receiver_visible_wire)}")
    if built.compressed_origin_first:
        out.append("    Draft order AS(1)..AS(N), compressed: "
                   + " -> ".join(f"AS{a}" for a in built.compressed_origin_first))
    out.append(f" 3. Exporting AS:       AS{x}")
    out.append(f" 4. Receiving neighbour: AS{y}")
    out.append(f" 5. Relationship:       {topo.describe(of=x, to=y, prefix=s.route.prefix)}")
    out.append(" 6. ASPA records examined:")
    recs = result.aspa.details.get("records_examined", [])
    out += ["    (none)"] if not recs else []
    for r in recs:
        prov = "-" if r["providers"] is None else (
            "[] (no providers)" if not r["providers"] else ", ".join(f"AS{p}" for p in r["providers"]))
        note = f"  ({r['note']})" if r.get("note") else ""
        out.append(f"    AS{r['as']:<8} {r['status']:<18} providers: {prov}{note}")
    out.append("")
    out += _layer_block(" 7", "ASPA VERIFICATION", result.aspa, c)
    out += _hop_table(result.aspa)
    out += _layer_block(" 8", "EXPORT POLICY VERIFICATION", result.policy, c)
    otc = result.policy.details.get("otc", {})
    sent = otc.get("sent_otc")
    out.append(f" 9. OTC: {otc.get('status')} -- {otc.get('received', '')}"
               + (f"; route would be sent with OTC = AS{sent}"
                  if otc.get("status") == "PASS" and isinstance(sent, int) and sent > 0 else ""))
    out.append("")
    out.append(f"10. OVERALL RESULT: {_v(result.verdict.value, c)}")
    out.append(f"11. Explanation: {result.reason}")
    out.append(f"    Aggregation rule: {result.rule_applied}")
    for n in result.notes:
        out.append(f"    Note: {n}")
    out.append("12. Missing information:")
    out += [f"    - [ASPA] {m}" for m in result.aspa.missing_info]
    out += [f"    - [POLICY] {m}" for m in result.policy.missing_info]
    if not (result.aspa.missing_info or result.policy.missing_info):
        out.append("    (none)")
    out += _resolver_block(uncertainty, c)

    warnings = topo.consistency_warnings() + topo.aspa_consistency_warnings(s.aspa_records)
    if warnings:
        out.append("Data warnings:")
        out += [f"  ! {w}" for w in warnings]
    if s.expected:
        exp = {k: v for k, v in s.expected.items() if k in ("aspa", "export_policy", "overall")}
        got = {"aspa": result.aspa.verdict.value, "export_policy": result.policy.verdict.value,
               "overall": result.verdict.value}
        status = "matches" if all(got[k] == v for k, v in exp.items()) else "DIFFERS FROM"
        out.append(f"Proposed fixture expectation {exp} -- computed result {status} it")
    out.append(bar)
    return "\n".join(out)


def render_json(s: Scenario, built: BuiltPath, topo: Topology, result: OverallResult,
                uncertainty: Dict[str, Any]) -> Dict[str, Any]:
    """Return the same information as render_text() as a JSON-serialisable dictionary.

    The format is versioned by ``output_schema_version`` so that a future web
    front end can rely on it.
    """
    def wire(path: Any) -> List[Any]:
        """Convert a wire path to JSON lists (AS_SET tuples become lists)."""
        return [list(seg) if isinstance(seg, tuple) else seg for seg in path]

    return {
        "output_schema_version": "0.2",
        "scenario_id": s.scenario_id,
        "review_status": s.review_status,
        "pinned": {"aspa": "draft-ietf-sidrops-aspa-verification-31", "otc": "RFC 9234"},
        "input_as_path": wire(built.received_wire),
        "receiver_visible_as_path": wire(built.receiver_visible_wire),
        "compressed_path_origin_first": list(built.compressed_origin_first or []),
        "exporting_as": s.export.exporting_as,
        "receiving_as": s.export.receiving_as,
        "relationship": topo.describe(of=s.export.exporting_as, to=s.export.receiving_as,
                                      prefix=s.route.prefix),
        "aspa": result.aspa.to_dict(),
        "export_policy": result.policy.to_dict(),
        "overall": result.to_dict(),
        "uncertainty": uncertainty,
        "path_warnings": built.warnings,
        "data_warnings": topo.consistency_warnings() + topo.aspa_consistency_warnings(s.aspa_records),
        "expected": s.expected,
    }
