"""
core/aggregation.py -- combine the two layer verdicts into one overall verdict.

This module is fully implemented: it is project policy, not an IETF rule.

Procedure AGGREGATE(a, p)
  Input : a = ASPA verdict, p = export-policy verdict
  Output: overall verdict
  1. If a or p is INVALID          -> INVALID   (a proven violation wins)
  2. Else if a or p NOT_IMPLEMENTED -> NOT_IMPLEMENTED (cannot conclude)
  3. Else if a or p is UNKNOWN     -> UNKNOWN
  4. Else                          -> VALID     (both checks ran and passed)

The order of steps is a configurable precedence list, so a mentor can
change it without touching the engines.  The two LayerResult objects are
passed through untouched.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional

from core.models import LayerResult, OverallResult, Verdict

DEFAULT_PRECEDENCE: List[Verdict] = [
    Verdict.INVALID,
    Verdict.NOT_IMPLEMENTED,
    Verdict.UNKNOWN,
    Verdict.VALID,
]


@dataclass(frozen=True)
class AggregationConfig:
    """Settings for combining the two layer verdicts.

    Attributes:
        precedence: verdicts in order of priority. The first verdict in the
            list that either layer returned becomes the overall verdict.
            Default: INVALID > NOT_IMPLEMENTED > UNKNOWN > VALID.
    """
    precedence: List[Verdict] = field(default_factory=lambda: list(DEFAULT_PRECEDENCE))


def combine(a: Verdict, p: Verdict, cfg: AggregationConfig = AggregationConfig()) -> Verdict:
    """Combine an ASPA verdict and a policy verdict using the precedence list.

    Example: combine(UNKNOWN, INVALID) == INVALID with the default settings.
    """
    for v in cfg.precedence:
        if a is v or p is v:
            return v
    raise ValueError(f"precedence list does not cover {a} / {p}")


def aggregate(aspa: LayerResult, policy: LayerResult,
              cfg: AggregationConfig = AggregationConfig(),
              notes: Optional[List[str]] = None) -> OverallResult:
    """Combine the two layer results into an OverallResult with an explanation.

    The reason text says which layer decided and whether a leak earlier in
    the path (ASPA) or the exporter's own export (policy) was the problem.

    Args:
        aspa: the Layer 1 result.
        policy: the Layer 2 result.
        cfg: the aggregation settings.
        notes: optional extra notes to attach.
    """
    overall = combine(aspa.verdict, policy.verdict, cfg)
    a, p = aspa.verdict.value, policy.verdict.value
    if overall is Verdict.INVALID:
        failed = [r.layer for r in (aspa, policy) if r.verdict is Verdict.INVALID]
        reason = (f"{' and '.join(failed)} found a proven violation; "
                  "a violation in any layer outweighs uncertainty or success in the other.")
    elif overall is Verdict.NOT_IMPLEMENTED:
        reason = "At least one verification engine is not implemented yet, so no overall verdict is given."
    elif overall is Verdict.UNKNOWN:
        unk = [r.layer for r in (aspa, policy) if r.verdict is Verdict.UNKNOWN]
        reason = (f"No violation was proven, but {' and '.join(unk)} lacked information; "
                  "VALID requires both layers to pass with complete information.")
    else:
        reason = "Both layers ran with sufficient information and both passed."
    rule = f"ASPA={a}, POLICY={p} -> {overall.value} (precedence: " + \
        " > ".join(v.value for v in cfg.precedence) + ")"
    if overall is Verdict.INVALID and len(failed) == 1:
        other = policy if failed[0] == "ASPA" else aspa
        suspects = {run.get("suspected_leaker") for run in aspa.details.get("runs", {}).values()}
        own_hop = aspa.details.get("exporter") in suspects
        if failed[0] == "ASPA" and policy.verdict is Verdict.VALID and own_hop:
            reason += (" The exporter's policy allows this export (for example by a local exception), "
                       "but the receiver's ASPA check flags the exporter's own hop, so it would reject it.")
        elif failed[0] == "ASPA" and policy.verdict is Verdict.VALID:
            reason += (" The exporter's own decision is permitted; the problem is already in the "
                       "path it received (a leak or forged hop upstream).")
        elif failed[0] == "EXPORT_POLICY" and other.verdict is Verdict.VALID:
            reason += (" The path itself passes ASPA, so the receiver would NOT detect this; only "
                       "the exporter's policy check catches it.")
        elif failed[0] == "EXPORT_POLICY" and other.verdict is Verdict.UNKNOWN:
            reason += " ASPA could not decide (missing records), so the policy check is what catches it."
    return OverallResult(overall, reason, aspa, policy, rule, list(notes or []))
