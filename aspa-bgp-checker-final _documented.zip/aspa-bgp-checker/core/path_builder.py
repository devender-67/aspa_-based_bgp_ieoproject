"""
core/path_builder.py -- build the AS_PATH the receiving neighbour will see.

The project checks a *proposed* export, so Layer 1 must verify the path
AFTER the exporter adds its own ASN, i.e. what the receiver will get.

Example
-------
Exporter AS300 received [200, 100] (origin AS100), exports to AS400, prepend 1.
  receiver-visible (wire order):     [300, 200, 100]
  draft order AS(1)..AS(N):          [100, 200, 300]

Special case: a TRANSPARENT route server does not add its ASN, so the
receiver-visible path equals the received path.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional, Tuple

from core.models import ASN, PathSegment, Relation, Scenario
from core.topology import Topology


@dataclass(frozen=True)
class BuiltPath:
    """The AS_PATH as the receiver will see it, plus facts derived from it.

    Attributes:
        received_wire: the path the exporter received (wire order).
        receiver_visible_wire: the path after the exporter prepends itself
            (unchanged for a transparent route server).
        has_as_set: True if any segment is an AS_SET (ASPA then gives INVALID).
        compressed_origin_first: origin-first path with prepends collapsed,
            as the ASPA draft numbers it (None when an AS_SET is present).
        exporter_prepended: False only for a transparent route server.
        receiver_loop: True if the receiver already appears in the path.
        warnings: human-readable notes about the path.
    """
    received_wire: Tuple[PathSegment, ...]
    receiver_visible_wire: Tuple[PathSegment, ...]
    has_as_set: bool
    # Origin-first, consecutive duplicates collapsed (COMPRESSED_AS_PATH).
    # None when an AS_SET is present.
    compressed_origin_first: Optional[Tuple[ASN, ...]]
    exporter_prepended: bool
    receiver_loop: bool
    warnings: List[str] = field(default_factory=list)


def compress(seq: Tuple[ASN, ...]) -> Tuple[ASN, ...]:
    """Collapse consecutive repeats: (100, 100, 200, 200, 200) -> (100, 200)."""
    out: List[ASN] = []
    for asn in seq:
        if not out or out[-1] != asn:
            out.append(asn)
    return tuple(out)


def build_receiver_path(s: Scenario, topo: Topology) -> BuiltPath:
    """Build the AS_PATH that the receiving AS would see.

    The exporter X prepends its AS number ``prepend_count`` times, unless X is
    a transparent route server for the receiver. The result is also compressed
    (prepends removed) and reversed into the origin-first order used by the
    ASPA draft.

    Args:
        s: the scenario.
        topo: the declared topology.

    Returns:
        A BuiltPath with the received, visible and compressed paths.
    """
    x, y = s.export.exporting_as, s.export.receiving_as
    received = s.route.as_path_received
    warnings: List[str] = []

    transparent_rs = (topo.relation(of=y, to=x) is Relation.RS and topo.rs_is_transparent(x, y))
    if transparent_rs:
        visible: Tuple[PathSegment, ...] = received
        warnings.append(f"AS{x} is a transparent route server: it does not add its ASN")
    else:
        visible = (x,) * s.export.prepend_count + received

    flat = [a for seg in visible for a in (seg if isinstance(seg, tuple) else (seg,))]
    receiver_loop = y in flat
    if receiver_loop:
        warnings.append(f"AS{y} already appears in the path: its AS_PATH loop detection "
                        "(RFC 4271 Sec. 9.1.2) would discard the route before ASPA is applied")

    has_set = any(isinstance(seg, tuple) for seg in visible)
    compressed: Optional[Tuple[ASN, ...]] = None
    if has_set:
        warnings.append("AS_PATH contains an AS_SET")
    else:
        compressed = compress(tuple(reversed([int(a) for a in visible])))  # type: ignore[arg-type]
        if len(set(compressed)) != len(compressed):
            warnings.append("AS_PATH contains a non-consecutive repeated AS (loop or poisoning)")

    return BuiltPath(received, visible, has_set, compressed, not transparent_rs,
                     receiver_loop, warnings)


def format_wire(path: Tuple[PathSegment, ...]) -> str:
    """Format a wire-order path as text, e.g. 'AS300 AS200 {AS1, AS2}'."""
    if not path:
        return "(empty -- locally originated)"
    return " ".join("{" + ", ".join(f"AS{a}" for a in seg) + "}" if isinstance(seg, tuple)
                    else f"AS{seg}" for seg in path)
