"""
core/topology.py -- explicit AS relationships.

Relationships come ONLY from the declared topology. Nothing here looks at
AS numbers or AS_PATH order to guess who is whose provider.

Supported kinds: provider-customer, peer, route-server (transparent or not),
complex (hybrid, optionally with a role per prefix).
"""

from __future__ import annotations

from typing import Dict, FrozenSet, Iterable, List, Optional, Tuple

from core.models import ASN, AspaRecord, PrefixRole, RecordStatus, Relation, RelationshipDecl
from core.parser import InputError


class Topology:
    """The declared AS relationships, queried from either side.

    Stores for every ordered pair (x, y) what y is to x (provider, customer,
    peer, route server, RS-client or complex). Relationships are only ever
    taken from the input; nothing is inferred from AS numbers or path order.
    """
    def __init__(self, ases: FrozenSet[ASN], decls: Iterable[RelationshipDecl]) -> None:
        """Store every declared relationship from both sides.

        Raises:
            InputError: for a self-relationship or two conflicting declarations
                for the same pair (a hybrid pair must be declared as complex).
        """
        self.ases = ases
        self._view: Dict[Tuple[ASN, ASN], Relation] = {}       # (x, y) -> what y is to x
        self._prefix_roles: Dict[FrozenSet[ASN], Tuple[PrefixRole, ...]] = {}
        self._rs_transparent: Dict[Tuple[ASN, ASN], bool] = {}  # (rs, client) -> bool
        for d in decls:
            if d.a == d.b:
                raise InputError(f"topology: AS{d.a} has a relationship with itself")
            if d.kind == "provider-customer":
                self._add(d.b, d.a, Relation.PROVIDER)
                self._add(d.a, d.b, Relation.CUSTOMER)
            elif d.kind == "peer":
                self._add(d.a, d.b, Relation.PEER)
                self._add(d.b, d.a, Relation.PEER)
            elif d.kind == "route-server":
                self._add(d.b, d.a, Relation.RS)          # seen from client b, a is its RS
                self._add(d.a, d.b, Relation.RS_CLIENT)
                self._rs_transparent[(d.a, d.b)] = d.transparent
            elif d.kind == "complex":
                self._add(d.a, d.b, Relation.COMPLEX)
                self._add(d.b, d.a, Relation.COMPLEX)
                self._prefix_roles[frozenset((d.a, d.b))] = d.prefix_roles

    def _add(self, x: ASN, y: ASN, rel: Relation) -> None:
        """Record what y is to x, rejecting a conflicting earlier declaration."""
        old = self._view.get((x, y))
        if old is not None and old is not rel:
            raise InputError(f"topology: conflicting relationships between AS{x} and AS{y} "
                             f"({old.value} vs {rel.value}); declare it once, as 'complex' "
                             "if it really is hybrid")
        self._view[(x, y)] = rel

    # ---- lookups -------------------------------------------------------

    def base_relation(self, of: ASN, to: ASN) -> Optional[Relation]:
        """Declared relationship, ignoring per-prefix roles."""
        return self._view.get((of, to))

    def relation(self, of: ASN, to: ASN, prefix: Optional[str] = None) -> Optional[Relation]:
        """What `to` is, seen from `of`, for this prefix. None = not declared.
        A complex relationship resolves to its per-prefix role if one is given."""
        rel = self._view.get((of, to))
        if rel is Relation.COMPLEX and prefix is not None:
            for role in self._prefix_roles.get(frozenset((of, to)), ()):
                if role.prefix == prefix:
                    if role.kind == "peer":
                        return Relation.PEER
                    return Relation.PROVIDER if role.provider == to else Relation.CUSTOMER
        return rel

    def is_complex(self, x: ASN, y: ASN) -> bool:
        """Return True if x and y have a complex (hybrid, per-prefix) relationship."""
        return self._view.get((x, y)) is Relation.COMPLEX

    def rs_is_transparent(self, rs: ASN, client: ASN) -> bool:
        """Return True if route server ``rs`` does not add its AS number for ``client`` (default True)."""
        return self._rs_transparent.get((rs, client), True)

    def describe(self, of: ASN, to: ASN, prefix: Optional[str] = None) -> str:
        """Describe in words what ``to`` is to ``of``, e.g. "AS200 is a provider of AS300".

        Mentions complex relationships and route-server transparency when relevant.
        """
        rel = self.relation(of, to, prefix)
        if rel is None:
            return f"no relationship declared between AS{of} and AS{to}"
        text = f"AS{to} is a {rel.value} of AS{of}"
        if self.is_complex(of, to) and rel is not Relation.COMPLEX:
            text += f" (complex relationship; role for prefix {prefix})"
        if rel is Relation.RS:
            text += " (transparent)" if self.rs_is_transparent(to, of) else " (non-transparent)"
        if rel is Relation.RS_CLIENT:
            text += " (transparent RS)" if self.rs_is_transparent(of, to) else " (non-transparent RS)"
        return text

    def neighbours(self, asn: ASN) -> List[Tuple[ASN, Relation]]:
        """Return every declared neighbour of ``asn`` with its relation, sorted by AS number."""
        return sorted((y, r) for (x, y), r in self._view.items() if x == asn)

    def should_list_as_provider(self, customer: ASN, other: ASN) -> Optional[bool]:
        """Would a CORRECT ASPA record of `customer` list `other`?
        draft -31 Sec. 4: list every provider, every non-transparent RS you are
        a client of, and any neighbour that is a provider for some prefixes.
        None = the topology does not say (no declared relationship)."""
        rel = self._view.get((customer, other))
        if rel is None:
            return None
        if rel is Relation.PROVIDER:
            return True
        if rel is Relation.RS:
            return not self.rs_is_transparent(other, customer)
        if rel is Relation.COMPLEX:
            roles = self._prefix_roles.get(frozenset((customer, other)), ())
            if not roles:
                return None
            return any(r.kind == "provider-customer" and r.provider == other for r in roles)
        return False                           # customer, peer, RS-client

    # ---- consistency checks ---------------------------------------------

    def consistency_warnings(self) -> List[str]:
        """Return warnings about the topology itself.

        Reports ASes without any relationship and customer->provider cycles.
        These are warnings, not errors: the check still runs.
        """
        warnings: List[str] = []
        for asn in sorted(self.ases):
            if not self.neighbours(asn):
                warnings.append(f"AS{asn} has no declared relationships")
        warnings.extend(self._provider_cycles())
        return warnings

    def aspa_consistency_warnings(self, records: Dict[ASN, AspaRecord]) -> List[str]:
        """Compare published ASPA records with the declared topology.
        Over-permissive records can hide leaks (false VALID); records that omit
        a real provider cause false INVALID."""
        out: List[str] = []
        for cas, rec in sorted(records.items()):
            if rec.status is not RecordStatus.PRESENT:
                continue
            for p in rec.providers:
                if self.should_list_as_provider(cas, p) is False:
                    out.append(f"AS{cas}'s ASPA lists AS{p} as a provider, but the topology says "
                               f"{self.describe(cas, p)} (stale or over-permissive record)")
            for y, _ in self.neighbours(cas):
                if self.should_list_as_provider(cas, y) is True and y not in rec.providers:
                    out.append(f"AS{cas}'s ASPA omits AS{y}, which the topology says it must "
                               f"list ({self.describe(cas, y)})")
        return out

    def _provider_cycles(self) -> List[str]:
        """Find customer->provider cycles (an AS that is indirectly its own provider)."""
        up = {x: [y for (xx, y), r in self._view.items() if xx == x and r is Relation.PROVIDER]
              for x in self.ases}
        state: Dict[ASN, int] = {}
        found: List[str] = []

        def dfs(n: ASN, stack: List[ASN]) -> None:
            """Depth-first search that records any cycle along customer->provider links."""
            state[n] = 1
            for p in up.get(n, []):
                if state.get(p) == 1:
                    cyc = stack[stack.index(p):] + [p]
                    found.append("customer->provider cycle: " + " -> ".join(f"AS{a}" for a in cyc))
                elif p not in state:
                    dfs(p, stack + [p])
            state[n] = 2

        for a in sorted(self.ases):
            if a not in state:
                dfs(a, [a])
        return found
