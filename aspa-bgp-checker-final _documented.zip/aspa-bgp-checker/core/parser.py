"""
core/parser.py -- load a scenario JSON file and validate it.

Design rule: malformed input is reported as an InputError with a precise
message.  It is NEVER silently turned into a verdict.  "The file is broken"
and "the route is INVALID" are different statements.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from core.models import (
    MAX_ASN,
    AspaRecord,
    ExportInput,
    OtcInput,
    PathSegment,
    ExportException,
    PolicyContext,
    PrefixRole,
    RecordStatus,
    RelationshipDecl,
    RouteInput,
    Scenario,
)

SUPPORTED_SCHEMA_VERSIONS = {"0.1"}


class InputError(ValueError):
    """Raised for any malformed or internally inconsistent scenario."""


# ---------------------------------------------------------------- helpers

def _parse_asn(value: Any, where: str, allow_zero: bool = False) -> int:
    """Accept 300, "300" or "AS300"; reject anything else."""
    if isinstance(value, bool):  # bool is a subclass of int in Python
        raise InputError(f"{where}: expected an AS number, got a boolean")
    if isinstance(value, str):
        text = value.strip().upper()
        if text.startswith("AS"):
            text = text[2:]
        if not text.isdigit():
            raise InputError(f"{where}: '{value}' is not a valid AS number")
        value = int(text)
    if not isinstance(value, int):
        raise InputError(f"{where}: expected an AS number, got {type(value).__name__}")
    low = 0 if allow_zero else 1
    if not (low <= value <= MAX_ASN):
        raise InputError(f"{where}: AS number {value} is outside {low}..{MAX_ASN}")
    return value


def _require(obj: Dict[str, Any], key: str, where: str) -> Any:
    """Return obj[key], raising InputError that names the location if it is missing."""
    if not isinstance(obj, dict):
        raise InputError(f"{where}: expected a JSON object")
    if key not in obj:
        raise InputError(f"{where}: missing required field '{key}'")
    return obj[key]


def _parse_path(raw: Any, where: str) -> Tuple[PathSegment, ...]:
    """Wire-order AS_PATH. A nested list is an AS_SET, e.g. [300, [64500, 64501], 100]."""
    if not isinstance(raw, list):
        raise InputError(f"{where}: AS_PATH must be a list")
    segments: List[PathSegment] = []
    for i, item in enumerate(raw):
        if isinstance(item, list):
            if not item:
                raise InputError(f"{where}[{i}]: empty AS_SET")
            segments.append(tuple(_parse_asn(x, f"{where}[{i}]") for x in item))
        else:
            segments.append(_parse_asn(item, f"{where}[{i}]"))
    return tuple(segments)


# ---------------------------------------------------------------- sections

def _parse_prefix_roles(raw: Any, a: int, b: int, where: str) -> Tuple[PrefixRole, ...]:
    """Parse the per-prefix roles of a complex relationship."""
    if raw is None:
        return ()
    if not isinstance(raw, list):
        raise InputError(f"{where}.prefix_roles: must be a list")
    roles: List[PrefixRole] = []
    for i, r in enumerate(raw):
        w = f"{where}.prefix_roles[{i}]"
        prefix = _require(r, "prefix", w)
        kind = _require(r, "type", w)
        if kind == "peer":
            roles.append(PrefixRole(str(prefix), "peer"))
        elif kind == "provider-customer":
            prov = _parse_asn(_require(r, "provider", w), w + ".provider")
            if prov not in (a, b):
                raise InputError(f"{w}.provider: AS{prov} is not part of this relationship")
            roles.append(PrefixRole(str(prefix), "provider-customer", prov))
        else:
            raise InputError(f"{w}.type: use 'provider-customer' or 'peer'")
    return tuple(roles)


def _parse_topology(raw: Dict[str, Any]) -> Tuple[frozenset, Tuple[RelationshipDecl, ...]]:
    """Parse the topology block: the AS list and every declared relationship."""
    ases_raw = _require(raw, "ases", "topology")
    if not isinstance(ases_raw, list) or not ases_raw:
        raise InputError("topology.ases: must be a non-empty list")
    ases = frozenset(_parse_asn(a, "topology.ases") for a in ases_raw)

    rels: List[RelationshipDecl] = []
    for i, r in enumerate(_require(raw, "relationships", "topology")):
        where = f"topology.relationships[{i}]"
        kind = _require(r, "type", where)
        transparent, roles = True, ()
        if kind == "provider-customer":
            a = _parse_asn(_require(r, "provider", where), where + ".provider")
            b = _parse_asn(_require(r, "customer", where), where + ".customer")
        elif kind in ("peer", "complex"):
            pair = _require(r, "ases", where)
            if not isinstance(pair, list) or len(pair) != 2:
                raise InputError(f"{where}.ases: needs exactly two ASes")
            a, b = (_parse_asn(x, where + ".ases") for x in pair)
            if kind == "complex":
                roles = _parse_prefix_roles(r.get("prefix_roles"), a, b, where)
        elif kind == "route-server":
            a = _parse_asn(_require(r, "rs", where), where + ".rs")
            b = _parse_asn(_require(r, "client", where), where + ".client")
            transparent = r.get("transparent", True)
            if not isinstance(transparent, bool):
                raise InputError(f"{where}.transparent: must be true or false")
        else:
            raise InputError(f"{where}.type: unknown relationship type '{kind}' (use "
                             "'provider-customer', 'peer', 'route-server' or 'complex')")
        for asn in (a, b):
            if asn not in ases:
                raise InputError(f"{where}: AS{asn} is not listed in topology.ases")
        rels.append(RelationshipDecl(kind, a, b, transparent, roles))
    return ases, tuple(rels)


def _parse_aspa(raw: Any) -> Dict[int, AspaRecord]:
    """Parse the ASPA records; reject duplicates, unknown statuses and bad AS numbers."""
    if not isinstance(raw, list):
        raise InputError("aspa_records: must be a list")
    records: Dict[int, AspaRecord] = {}
    for i, r in enumerate(raw):
        where = f"aspa_records[{i}]"
        cas = _parse_asn(_require(r, "customer_as", where), where + ".customer_as")
        if cas in records:
            # The draft allows several ASPA objects per AS (their SPAS are
            # unioned). The synthetic DB keeps one record per AS to keep
            # fixtures unambiguous; list all providers in that one record.
            raise InputError(f"{where}: duplicate record for AS{cas}; merge them into one")
        status_raw = r.get("status", "present")
        try:
            status = RecordStatus(status_raw)
        except ValueError:
            raise InputError(f"{where}.status: '{status_raw}' is not one of "
                             f"{[s.value for s in RecordStatus]}") from None

        providers: Tuple[int, ...] = ()
        if status is RecordStatus.PRESENT:
            plist = _require(r, "providers", where)
            if not isinstance(plist, list):
                raise InputError(f"{where}.providers: must be a list")
            parsed = [_parse_asn(p, where + ".providers", allow_zero=True) for p in plist]
            if cas in parsed:
                raise InputError(f"{where}: AS{cas} lists itself as its own provider")
            # [] and [0] both mean "no providers". AS0 next to real providers
            # is ignored (it has no effect on verification).
            providers = tuple(sorted({p for p in parsed if p != 0}))
        elif r.get("providers"):
            raise InputError(f"{where}: a '{status.value}' record must not list providers")
        records[cas] = AspaRecord(cas, status, providers)
    return records


def _parse_otc(raw: Any) -> OtcInput:
    """
    "otc": {"present": false}                -> known, absent
    "otc": {"present": true, "value": 200}   -> known, present with value
    "otc": null  or field omitted            -> UNKNOWN context
    """
    if raw is None:
        return OtcInput(known=False)
    present = _require(raw, "present", "route.otc")
    if not isinstance(present, bool):
        raise InputError("route.otc.present: must be true or false")
    if not present:
        return OtcInput(known=True, present=False)
    value = _parse_asn(_require(raw, "value", "route.otc"), "route.otc.value")
    return OtcInput(known=True, present=True, value=value)


# ---------------------------------------------------------------- public API

def parse_scenario(data: Dict[str, Any]) -> Scenario:
    """Validate a scenario dictionary and convert it into a Scenario.

    Every field is checked (types, AS numbers, duplicate records, unknown
    relationship types, learned_from consistency, loops). Nothing is guessed:
    any problem raises InputError with a message that names the field.

    Args:
        data: the decoded JSON object.

    Returns:
        A frozen Scenario ready for the engines.

    Raises:
        InputError: if the input is malformed or inconsistent.
    """
    if not isinstance(data, dict):
        raise InputError("top level: expected a JSON object")
    version = str(data.get("schema_version", ""))
    if version not in SUPPORTED_SCHEMA_VERSIONS:
        raise InputError(f"schema_version '{version}' not supported "
                         f"(supported: {sorted(SUPPORTED_SCHEMA_VERSIONS)})")

    ases, rels = _parse_topology(_require(data, "topology", "top level"))
    aspa = _parse_aspa(data.get("aspa_records", []))

    route_raw = _require(data, "route", "top level")
    path = _parse_path(_require(route_raw, "as_path_received", "route"), "route.as_path_received")
    lf_raw = route_raw.get("learned_from")
    learned_from: Optional[int] = None if lf_raw is None else _parse_asn(lf_raw, "route.learned_from")
    route = RouteInput(
        prefix=route_raw.get("prefix"),
        as_path_received=path,
        learned_from=learned_from,
        otc=_parse_otc(route_raw.get("otc")),
    )

    exp_raw = _require(data, "export", "top level")
    prepend = exp_raw.get("prepend_count", 1)
    if not isinstance(prepend, int) or isinstance(prepend, bool) or prepend < 1:
        raise InputError("export.prepend_count: must be an integer >= 1")
    export = ExportInput(
        exporting_as=_parse_asn(_require(exp_raw, "exporting_as", "export"), "export.exporting_as"),
        receiving_as=_parse_asn(_require(exp_raw, "receiving_as", "export"), "export.receiving_as"),
        prepend_count=prepend,
    )

    pol_raw = data.get("policy_context", {}) or {}
    roles = pol_raw.get("bgp_roles_configured", True)
    if roles is not None and not isinstance(roles, bool):
        raise InputError("policy_context.bgp_roles_configured: must be true, false or null")
    exceptions: List[ExportException] = []
    for i, e in enumerate(pol_raw.get("export_exceptions", []) or []):
        w = f"policy_context.export_exceptions[{i}]"
        lf = e.get("learned_from") if isinstance(e, dict) else None
        exceptions.append(ExportException(
            learned_from=None if lf is None else _parse_asn(lf, w + ".learned_from"),
            receiving_as=_parse_asn(_require(e, "receiving_as", w), w + ".receiving_as"),
            reason=str(e.get("reason", "configured exception"))))
    policy = PolicyContext(bgp_roles_configured=roles, exceptions=tuple(exceptions))

    _check_consistency(ases, route, export)

    return Scenario(
        scenario_id=str(data.get("scenario_id", "unnamed")),
        description=str(data.get("description", "")),
        review_status=str(data.get("review_status", "proposed")),
        ases=ases,
        relationships=rels,
        aspa_records=aspa,
        route=route,
        export=export,
        policy=policy,
        expected=data.get("expected"),
    )


def _check_consistency(ases: frozenset, route: RouteInput, export: ExportInput) -> None:
    """Cross-field checks that make a scenario self-contradictory."""
    x, y = export.exporting_as, export.receiving_as
    if x == y:
        raise InputError("export: exporting_as and receiving_as are the same AS")
    for asn, name in ((x, "exporting_as"), (y, "receiving_as")):
        if asn not in ases:
            raise InputError(f"export.{name}: AS{asn} is not listed in topology.ases")

    path = route.as_path_received
    if not path:
        if route.learned_from is not None:
            raise InputError("route: empty AS_PATH means locally originated, "
                             "so learned_from must be null")
        return
    if route.learned_from is not None and route.learned_from not in ases:
        raise InputError(f"route.learned_from: AS{route.learned_from} is not listed in topology.ases")
    if route.learned_from is None:
        raise InputError("route: non-empty AS_PATH needs learned_from "
                         "(null is only for locally originated routes)")
    first = path[0]
    if isinstance(first, tuple):
        raise InputError("route.as_path_received: the most recent segment is an AS_SET; "
                         "cannot identify the neighbour")
    if first != route.learned_from:
        # Not inferring anything: we only check that two stated facts agree.
        raise InputError(f"route: learned_from is AS{route.learned_from} but the received "
                         f"AS_PATH starts with AS{first}")
    flat = [a for seg in path for a in (seg if isinstance(seg, tuple) else (seg,))]
    if x in flat:
        raise InputError(f"route: exporting AS{x} already appears in the received AS_PATH; "
                         "it would have discarded the route by loop detection (RFC 4271 9.1.2)")


def load_scenario(path: str) -> Scenario:
    """Read a scenario JSON file and parse it with parse_scenario().

    Args:
        path: path to the JSON file.

    Raises:
        InputError: if the file is missing, is not valid JSON, or fails validation.
    """
    file = Path(path)
    if not file.is_file():
        raise InputError(f"file not found: {path}")
    try:
        data = json.loads(file.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise InputError(f"{path}: invalid JSON at line {exc.lineno}, column {exc.colno}: {exc.msg}") from None
    return parse_scenario(data)
