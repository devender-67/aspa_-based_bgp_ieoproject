"""
core/unknown_resolver.py -- Unknown-resolution engine (research contribution).

Problem it solves
-----------------
Draft -31 Sec. 5.7 tells routers to treat Unknown at the same preference
as Valid. So a real route leak that is "hidden" behind one missing ASPA
record is accepted exactly like a clean route, and a bare "Unknown" tells
the operator nothing about which case they are in.

This engine opens up every UNKNOWN:
  * What could the answer be?        best / worst case under two models
  * What WILL it be if ASes publish
    correct records?                  topology-consistent prediction
                                      -> LATENT-INVALID / LATENT-VALID / UNDETERMINED
  * Which missing facts matter?       influence score per item (swing count)
  * What is the least we must learn?  smallest settling set

Key idea: never guess answers. Every hypothetical completion is fed back
through the REAL verify_aspa, verify_export_policy and aggregate.

Two completion models
---------------------
ANY-RECORD (unconstrained): a missing ASPA record may list any subset of its
  path neighbours; an undeclared relationship may be any of
  provider/customer/peer; an unknown OTC may be absent / = source / other.
TOPOLOGY-CONSISTENT: a missing record must say what a CORRECT record would
  say given the declared relationships (draft -31 Sec. 4): list exactly the
  neighbours that are its providers (or non-transparent RSes). In the other
  direction, a guessed relationship must agree with records that ARE
  published (a signed "AS200 is my provider" rules out "AS200 is my peer").
  Where neither says anything, the item stays free.

Why two models: for ASPA alone the any-record model ALWAYS gives
best = VALID and worst = INVALID for an Unknown path (proof in
docs/algorithm.md), so it is uninformative on its own. The topology-
consistent model is what turns Unknown into a usable prediction.

Procedure RESOLVE_UNKNOWN(scenario)
  Input : scenario whose ASPA or policy result may be UNKNOWN
  Output: items, bounds under both models, classification, influence, settling sets
  1. Collect unknown items:
       ASPA records (missing / bad signature) consulted on the path,
       undeclared relationships (exporter-source, exporter-receiver),
       complex relationships with no role for the prefix,
       unknown OTC state (only when BGP Roles are configured).
  2. For each item list its options (see models above).
  3. Enumerate all completions (exhaustive if <= EXHAUSTIVE_LIMIT,
     else a seeded random sample). For each: build the completed scenario,
     run both layers and the aggregator, store the three verdicts.
  4. Mark a completion topology-consistent if every ASPA item agrees with
     the (completed) topology.
  5. Bounds: best/worst/distribution of each verdict under both models.
  6. Classification of the target verdict over consistent completions:
       only INVALID -> LATENT-INVALID, only VALID -> LATENT-VALID, else UNDETERMINED.
  7. Influence of item k: fraction of assignments of the OTHER items for
     which changing only item k changes the target verdict (a Banzhaf-style
     swing count). Influence > 0 means the item is critical.
  8. Settling set: smallest set S of items such that, once S is known
     (with ASPA items in S taking their topology-consistent value), the
     target verdict no longer depends on the remaining items.
"""

from __future__ import annotations

import itertools
import random
from dataclasses import dataclass, replace
from typing import Any, Callable, Dict, FrozenSet, List, Optional, Sequence, Tuple

from core.aggregation import aggregate
from core.aspa.validator import DOWN, records_used, select_algorithms, verify_aspa
from core.models import (ASN, AspaRecord, OtcInput, PrefixRole, RecordStatus, Relation,
                         RelationshipDecl, Scenario, Verdict)
from core.path_builder import build_receiver_path
from core.policy.export_policy import verify_export_policy
from core.policy.otc import OTHER_AS
from core.topology import Topology

EXHAUSTIVE_LIMIT = 4096
SAMPLE_SIZE = 2000
MAX_SETTLING_SIZE = 4
RANK = {Verdict.INVALID: 0, Verdict.UNKNOWN: 1, Verdict.VALID: 2}


@dataclass(frozen=True)
class Item:
    """One unknown fact that the resolver will fill in.

    Attributes:
        id: stable identifier, e.g. "ASPA:AS300".
        layer: which layer it affects ("ASPA", "RELATIONSHIP" or "OTC").
        text: description for the report.
        options: the possible values of the fact.
        labels: a readable label for each option.
        asn: the AS whose record is missing (ASPA items).
        neighbours: the path neighbours the record decides (ASPA items).
        pair: the two ASes of an undeclared relationship.
    """
    id: str
    layer: str                 # "ASPA", "RELATIONSHIP", "OTC"
    text: str
    options: Tuple[Any, ...]
    labels: Tuple[str, ...]
    asn: Optional[ASN] = None
    neighbours: Tuple[ASN, ...] = ()
    pair: Optional[Tuple[ASN, ASN]] = None


# ------------------------------------------------------------------ step 1-2

def collect_items(s: Scenario) -> List[Item]:
    """Steps 1-2: list every unknown fact in the scenario and its possible values.

    Unknown facts are missing or badly signed ASPA records on the path,
    undeclared relationships, complex relationships without a role for the
    prefix, and the OTC state when it is not given.
    """
    topo = Topology(s.ases, s.relationships)
    built = build_receiver_path(s, topo)
    x, y, lf, prefix = s.export.exporting_as, s.export.receiving_as, s.route.learned_from, s.route.prefix
    items: List[Item] = []

    def rel_item(a: ASN, b: ASN, purpose: str) -> None:
        """Add an item for the relationship a-b if it is undeclared or has no role for this prefix."""
        if topo.base_relation(a, b) is None:
            opts = (("provider-customer", a, b), ("provider-customer", b, a), ("peer", a, b))
            labels = (f"AS{a} is provider of AS{b}", f"AS{b} is provider of AS{a}", "peers")
            items.append(Item(f"REL:AS{a}-AS{b}", "RELATIONSHIP",
                              f"relationship AS{a}-AS{b} not declared ({purpose})", opts, labels, pair=(a, b)))
        elif topo.is_complex(a, b) and topo.relation(a, b, prefix) is Relation.COMPLEX:
            opts = (("role", a), ("role", b), ("role", None))
            labels = (f"AS{a} is provider for {prefix}", f"AS{b} is provider for {prefix}",
                      f"peers for {prefix}")
            items.append(Item(f"ROLE:AS{a}-AS{b}", "RELATIONSHIP",
                              f"complex AS{a}-AS{b}: no role for {prefix} ({purpose})", opts, labels,
                              pair=(a, b)))

    if lf is not None:
        rel_item(x, lf, "route source")
    rel_item(x, y, "export target")
    rel_xy_unknown = any(i.pair == (x, y) for i in items)

    if built.compressed_origin_first is not None:
        path = built.compressed_origin_first
        algs = select_algorithms(s, topo)[0]
        use_down = DOWN in algs or rel_xy_unknown
        used = records_used(path, [DOWN] if use_down else ["upstream"])
        for k, asn in enumerate(path):
            if asn not in used:
                continue
            rec = s.aspa_records.get(asn)
            if rec is not None and rec.status is RecordStatus.PRESENT:
                continue
            nbrs: List[ASN] = []
            if k + 1 < len(path):
                nbrs.append(path[k + 1])                 # up hop: authorized(A(k), A(k+1))
            if use_down and k >= 1:
                nbrs.append(path[k - 1])                 # down hop: authorized(A(k), A(k-1))
            if not nbrs:
                continue
            subsets = [frozenset(c) for r in range(len(nbrs) + 1) for c in itertools.combinations(nbrs, r)]
            labels = tuple("lists " + (", ".join(f"AS{n}" for n in sorted(sub)) if sub else "none of "
                           + "/".join(f"AS{n}" for n in nbrs)) for sub in subsets)
            status = "missing" if rec is None else rec.status.value
            items.append(Item(f"ASPA:AS{asn}", "ASPA",
                              f"ASPA record of AS{asn} ({status}); decides hops to "
                              + ", ".join(f"AS{n}" for n in nbrs),
                              tuple(subsets), labels, asn=asn, neighbours=tuple(nbrs)))

    if s.policy.bgp_roles_configured and not s.route.otc.known:
        opts: List[OtcInput] = [OtcInput(True, False)]
        labels_l = ["absent"]
        if lf is not None:
            opts.append(OtcInput(True, True, lf))
            labels_l.append(f"OTC = AS{lf}")
        opts.append(OtcInput(True, True, OTHER_AS))
        labels_l.append("OTC = another AS")
        items.append(Item("OTC", "OTC", "OTC state of the received route (not given)",
                          tuple(opts), tuple(labels_l)))
    return items


# ------------------------------------------------------------------ step 3

def apply(s: Scenario, items: Sequence[Item], choice: Sequence[int]) -> Scenario:
    """Step 3: build the scenario in which every item takes the chosen option.

    Args:
        s: the original scenario.
        items: the unknown items.
        choice: for each item, the index of the option to use.

    Returns:
        A new, complete Scenario (the original is not changed).
    """
    records = dict(s.aspa_records)
    rels = list(s.relationships)
    route = s.route
    for item, c in zip(items, choice):
        opt = item.options[c]
        if item.layer == "ASPA":
            records[item.asn] = AspaRecord(item.asn, RecordStatus.PRESENT, tuple(sorted(opt)))
        elif item.layer == "RELATIONSHIP" and opt[0] != "role":
            kind, a, b = opt
            rels.append(RelationshipDecl(kind, a, b))
        elif item.layer == "RELATIONSHIP":
            a, b = item.pair  # type: ignore[misc]
            new_role = PrefixRole(s.route.prefix or "", "peer" if opt[1] is None else "provider-customer", opt[1])
            rels = [replace(d, prefix_roles=d.prefix_roles + (new_role,))
                    if d.kind == "complex" and {d.a, d.b} == {a, b} else d for d in rels]
        elif item.layer == "OTC":
            route = replace(route, otc=opt)
    return replace(s, aspa_records=records, relationships=tuple(rels), route=route)


def evaluate(s: Scenario) -> Tuple[Verdict, Verdict, Verdict]:
    """Run the real ASPA, policy and aggregation engines and return (aspa, policy, overall) verdicts."""
    topo = Topology(s.ases, s.relationships)
    built = build_receiver_path(s, topo)
    a = verify_aspa(s, built, topo)
    p = verify_export_policy(s, topo)
    return a.verdict, p.verdict, aggregate(a, p).verdict


def item_consistent(item: Item, opt: Any, topo: Topology) -> bool:
    """Return True if an option for an item agrees with the declared topology.

    For an ASPA item the guessed provider set must list exactly the declared
    providers among the path neighbours (draft-31 Sec. 4). Other items are
    always consistent.
    """
    if item.layer != "ASPA":
        return True
    for n in item.neighbours:
        should = topo.should_list_as_provider(item.asn, n)  # type: ignore[arg-type]
        if should is not None and should != (n in opt):
            return False
    return True


def records_agree(s: Scenario, topo: Topology, items: Sequence[Item]) -> bool:
    """A guessed relationship must not contradict a PUBLISHED (signed) ASPA record:
    if AS c's record lists AS p, p must be able to be c's provider; if it does not
    list p, p must not be c's provider. Only checked for pairs that were guessed."""
    for it in items:
        if it.layer != "RELATIONSHIP" or it.pair is None:
            continue
        a, b = it.pair
        for cas, other in ((a, b), (b, a)):
            rec = s.aspa_records.get(cas)
            if rec is None or rec.status is not RecordStatus.PRESENT:
                continue
            should = topo.should_list_as_provider(cas, other)
            if should is not None and should != (other in rec.providers):
                return False
    return True


# ------------------------------------------------------------------ helpers

def _bounds(verdicts: List[Verdict]) -> Dict[str, Any]:
    """Return best, worst and the count of each verdict over a list of verdicts."""
    if not verdicts:
        return {"best": None, "worst": None, "distribution": {}, "count": 0}
    dist: Dict[str, int] = {}
    for v in verdicts:
        dist[v.value] = dist.get(v.value, 0) + 1
    return {"best": max(verdicts, key=RANK.get).value, "worst": min(verdicts, key=RANK.get).value,
            "distribution": dist, "count": len(verdicts)}


def _classify(verdicts: List[Verdict]) -> str:
    """Classify consistent completions: LATENT-VALID, LATENT-INVALID or UNDETERMINED."""
    kinds = set(verdicts)
    if kinds == {Verdict.INVALID}:
        return "LATENT-INVALID"
    if kinds == {Verdict.VALID}:
        return "LATENT-VALID"
    return "UNDETERMINED"


CLASS_TEXT = {
    "LATENT-INVALID": ("hidden problem: if the missing facts are what the declared topology implies, "
                       "the result is INVALID. Routers treat Unknown like Valid (draft -31 Sec. 5.7), "
                       "so today this would be accepted."),
    "LATENT-VALID": ("the Unknown comes only from missing data: if the listed ASes publish records "
                     "matching their declared relationships, the result is VALID."),
    "UNDETERMINED": ("the declared topology does not settle it: the result depends on facts the "
                     "topology does not state (see the settling set)."),
}


# ------------------------------------------------------------------ main entry

def resolve_unknowns(s: Scenario, actual: Dict[str, Verdict]) -> Dict[str, Any]:
    """`actual` = {"aspa": v, "policy": v, "overall": v} from the real run."""
    items = collect_items(s)
    if not items:
        return {"status": "COMPLETE", "note": "no missing information affects this export", "items": []}

    # Which verdict to analyse: overall if it is UNKNOWN, else the UNKNOWN layer, else overall.
    target = "overall"
    if actual["overall"] is not Verdict.UNKNOWN:
        for layer in ("aspa", "policy"):
            if actual[layer] is Verdict.UNKNOWN:
                target = layer
                break
    tidx = {"aspa": 0, "policy": 1, "overall": 2}[target]

    sizes = [len(i.options) for i in items]
    total = 1
    for n in sizes:
        total *= n
    exhaustive = total <= EXHAUSTIVE_LIMIT
    if exhaustive:
        choices = list(itertools.product(*[range(n) for n in sizes]))
    else:
        rng = random.Random(0)
        choices = [tuple(rng.randrange(n) for n in sizes) for _ in range(SAMPLE_SIZE)]

    results: Dict[Tuple[int, ...], Tuple[Verdict, Verdict, Verdict]] = {}
    consistent: Dict[Tuple[int, ...], bool] = {}
    for ch in choices:
        if ch in results:
            continue
        completed = apply(s, items, ch)
        results[ch] = evaluate(completed)
        topo_c = Topology(completed.ases, completed.relationships)
        consistent[ch] = all(item_consistent(it, it.options[c], topo_c) for it, c in zip(items, ch)) \
            and records_agree(completed, topo_c, items)

    keys = list(results)
    cons_keys = [k for k in keys if consistent[k]]

    def bounds_for(sel: List[Tuple[int, ...]]) -> Dict[str, Any]:
        """Return best/worst verdicts of each layer over the selected completions."""
        return {name: _bounds([results[k][i] for k in sel])
                for i, name in enumerate(("aspa", "policy", "overall"))}

    any_model, topo_model = bounds_for(keys), bounds_for(cons_keys)
    classification = {}
    for i, name in enumerate(("aspa", "policy", "overall")):
        if actual[name] is Verdict.UNKNOWN and cons_keys:
            cls = _classify([results[k][i] for k in cons_keys])
            classification[name] = {"class": cls, "text": CLASS_TEXT[cls]}

    influence = _influence(items, results, tidx, exhaustive, s)
    settling = _settling_sets(items, results, consistent, tidx, s) if exhaustive else None

    return {
        "status": "ANALYSED",
        "target": target,
        "method": "exhaustive" if exhaustive else f"sampled ({SAMPLE_SIZE} of {total})",
        "completions": len(keys),
        "consistent_completions": len(cons_keys),
        "items": [{"id": it.id, "layer": it.layer, "text": it.text, "options": list(it.labels)}
                  for it in items],
        "any_record_model": any_model,
        "topology_consistent_model": topo_model,
        "classification": classification,
        "influence": influence,
        "settling_sets": settling,
        "sources": sorted({it.layer for it in items}),
    }


def _influence(items: List[Item], results: Dict[Tuple[int, ...], Tuple[Verdict, ...]], tidx: int,
               exhaustive: bool, s: Scenario) -> List[Dict[str, Any]]:
    """Influence of each item: the share of choices for the other items in which
    changing only this item changes the verdict (a Banzhaf-style swing count).
    """
    out = []
    for k, it in enumerate(items):
        if exhaustive:
            groups: Dict[Tuple[int, ...], set] = {}
            for ch, res in results.items():
                groups.setdefault(ch[:k] + ch[k + 1:], set()).add(res[tidx])
            swings = sum(1 for g in groups.values() if len(g) > 1)
            score = swings / len(groups) if groups else 0.0
        else:
            sample = list(results)[:200]
            swings = 0
            for ch in sample:
                base = results[ch][tidx]
                for alt in range(len(it.options)):
                    if alt != ch[k]:
                        alt_ch = ch[:k] + (alt,) + ch[k + 1:]
                        if evaluate(apply(s, items, alt_ch))[tidx] is not base:
                            swings += 1
                            break
            score = swings / len(sample) if sample else 0.0
        out.append({"id": it.id, "layer": it.layer, "influence": round(score, 3), "critical": score > 0})
    out.sort(key=lambda d: -d["influence"])
    return out


def _settling_sets(items: List[Item], results: Dict[Tuple[int, ...], Tuple[Verdict, ...]],
                   consistent_all: Dict[Tuple[int, ...], bool], tidx: int, s: Scenario
                   ) -> Dict[str, Any]:
    """Smallest S such that knowing S (ASPA items in S at their topology-consistent
    value) leaves the target verdict independent of everything else."""
    # Per-completion, per-item consistency (needed because relationships can be items too).
    topo_cache: Dict[Tuple[int, ...], Topology] = {}

    def item_ok(ch: Tuple[int, ...], k: int) -> bool:
        """Return True if item k's value in completion ``ch`` is consistent with that completion's topology."""
        if items[k].layer != "ASPA":
            return True
        if ch not in topo_cache:
            c = apply(s, items, ch)
            topo_cache[ch] = Topology(c.ases, c.relationships)
        return item_consistent(items[k], items[k].options[ch[k]], topo_cache[ch])

    n = len(items)
    all_v = {res[tidx] for res in results.values()}
    if len(all_v) == 1:
        return {"size": 0, "sets": [], "settles_to": [next(iter(all_v)).value],
                "text": "no missing item can change this verdict"}
    for size in range(1, min(n, MAX_SETTLING_SIZE) + 1):
        found = []
        for S in itertools.combinations(range(n), size):
            groups: Dict[Tuple[int, ...], set] = {}
            for ch, res in results.items():
                if all(item_ok(ch, k) for k in S):
                    groups.setdefault(tuple(ch[k] for k in S), set()).add(res[tidx])
            if groups and all(len(g) == 1 for g in groups.values()):
                outcomes = sorted({next(iter(g)).value for g in groups.values()})
                found.append({"items": [items[k].id for k in S], "settles_to": outcomes})
        if found:
            return {"size": size, "sets": found[:6],
                    "text": "learning these items (ASPA records as their correct values) fixes the verdict"}
    return {"size": None, "sets": [], "text": f"no settling set of size <= {MAX_SETTLING_SIZE}"}
