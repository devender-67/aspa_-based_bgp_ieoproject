"""
core/planner/report.py -- terminal report for a change plan.
"""

from __future__ import annotations

from typing import Any, Dict, List


def _viol(v: Dict[str, Any]) -> str:
    """Describe one violation: which validator rejects which route under which record view."""
    if v["from"] is None:
        return f"AS{v['validator']} loses its route to AS{v['path'][0]}'s prefix: {v['view']}"
    path = " ".join(f"AS{a}" for a in v["path"])
    view = "; ".join(f"AS{a} -> {('no record' if x == 'no record' else '{' + ', '.join(f'AS{p}' for p in x) + '}')}"
                     for a, x in v["view"].items())
    return f"validator AS{v['validator']} rejects [{path}] when it holds {view}"


def render_plan(r: Dict[str, Any]) -> str:
    """Render the planner result as a terminal report.

    Shows the records and BGP links that change, the parameters, whether the
    start and target are safe, and each plan step by step with its safety,
    duration and leak exposure.
    """
    bar = "=" * 78
    out: List[str] = [bar, f"Change: {r['change_id']}", f"  {r['description']}", bar]
    out.append(f"Records changing: {', '.join(r['changing_records']) or '(none)'}"
               + (f"   first publication: {', '.join(r['first_publication'])}" if r["first_publication"] else ""))
    out.append("BGP changes:      " + ("; ".join(x.replace('BGP: ', '') for x in r["link_changes"]) or "(none)"))
    out.append(f"Validator lag bound DELTA = {r['delta_minutes']:g} min, BGP convergence BETA = "
               f"{r['bgp_convergence_minutes']:g} min")
    out.append(f"Start configuration safe: {r['start_safe']}   Target configuration safe: {r['target_safe']}")
    for key, label in (("start_violations", "start"), ("target_violations", "target")):
        for v in r[key][:5]:
            out.append(f"  ! {label}: {_viol(v)}")
    if not r["target_safe"]:
        out.append("  -> The TARGET itself breaks routes: fix the new records before planning.")
    for pl in r["plans"]:
        out.append("")
        status = "SAFE" if pl["safe"] else "UNSAFE"
        out.append(f"PLAN: {pl['name']}  [{status}]  duration {pl['minutes']:g} min, "
                   f"leak exposure {pl['exposure_route_minutes']:g} route-min, "
                   f"routes at risk {pl['routes_at_risk']}, outage {pl['outage_route_minutes']:g} route-min")
        for i, s in enumerate(pl["steps"], 1):
            flag = "" if s["safe"] else "   <-- UNSAFE"
            exp = f"   (exposed leaks: {s['exposed']})" if s["exposed"] else ""
            out.append(f"  {i:>2}. {s['text']}{exp}{flag}")
            for v in s["violations"][:3]:
                out.append(f"        ! {_viol(v)}")
            if len(s["violations"]) > 3:
                out.append(f"        ! ... and {len(s['violations']) - 3} more")
            for e in s.get("exposed_list", [])[:2]:
                path = " ".join(f"AS{a}" for a in e["path"])
                out.append(f"        ~ leak still accepted: AS{e['leaker']} re-sends [{path}] to AS{e['receiver']}")
    if not r["best_found"] and r["start_safe"] and r["target_safe"]:
        out.append("\nNo safe plan found within the search limit.")
    out.append(bar)
    return "\n".join(out)
