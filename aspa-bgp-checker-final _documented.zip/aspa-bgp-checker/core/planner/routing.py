"""
core/planner/routing.py -- which routes exist in the network?

The planner must know every legitimate route that validators will check, so
we simulate BGP route propagation on the synthetic topology using the
standard Gao-Rexford model:

  * preference: customer route > peer route > provider route,
    then shorter AS_PATH, then lower neighbour ASN (deterministic tie-break);
  * export: own and customer routes to everyone; peer and provider routes
    only to customers (the valley-free rule);
  * an AS drops a route that already contains its own ASN (loop detection).

Procedure PROPAGATE(links, origin)
  Input : set of links (provider-customer, peer), origin AS
  Output: best route of every AS that can reach the origin
  1. best[origin] := (origin), learned from "self"
  2. Repeat until nothing changes:
       for every AS u with a best route, for every neighbour v:
         if u may export best[u] to v and v is not in best[u]:
           candidate := (v) + best[u], ranked by v's relationship to u
           if candidate beats best[v], best[v] := candidate
  3. Return best

Procedure RECEIVED_ROUTES(links)
  Output: every (receiver v, sender u, wire path) that v receives from a
          neighbour, for every origin -- the routes ASPA will check.
"""

from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
from typing import Dict, FrozenSet, List, Optional, Tuple

from core.models import ASN, Relation, RelationshipDecl
from core.topology import Topology

PREF = {"self": -1, Relation.CUSTOMER: 0, Relation.PEER: 1, Relation.PROVIDER: 2}


@dataclass(frozen=True)
class ReceivedRoute:
    """A route that a neighbour sends to a receiver in the simulation.

    Attributes:
        receiver: the AS receiving the route.
        sender: the neighbour sending it.
        wire: AS_PATH as received (sender first, origin last).
        sender_role: what the sender is to the receiver.
    """
    receiver: ASN
    sender: ASN
    wire: Tuple[ASN, ...]           # as received: sender first, origin last
    sender_role: Relation           # what the sender is, seen from the receiver

    @property
    def origin(self) -> ASN:
        """The AS that originated the prefix (last AS of the path)."""
        return self.wire[-1]


def _topo(links: FrozenSet[RelationshipDecl]) -> Topology:
    """Build (and cache through the callers) a Topology from a link set."""
    ases = frozenset(a for d in links for a in (d.a, d.b))
    return Topology(ases, sorted(links, key=lambda d: (d.kind, d.a, d.b)))


def _may_export(learned: object, to_role: Optional[Relation]) -> bool:
    """Valley-free export: own/customer routes to all, others only to customers."""
    return learned in ("self", Relation.CUSTOMER) or to_role is Relation.CUSTOMER


def propagate(links: FrozenSet[RelationshipDecl], origin: ASN) -> Dict[ASN, Tuple[Tuple[ASN, ...], object]]:
    """best[v] = (wire path v announces, i.e. starting with v; how v learned it)."""
    topo = _topo(links)
    best: Dict[ASN, Tuple[Tuple[ASN, ...], object]] = {origin: ((origin,), "self")}
    changed = True
    rounds = 0
    while changed:
        changed = False
        rounds += 1
        if rounds > 10 * (len(topo.ases) + 2):
            raise RuntimeError("route propagation did not converge (provider cycle?)")
        for u in sorted(best):
            path_u, learned_u = best[u]
            for v, _ in topo.neighbours(u):
                if v in path_u or not _may_export(learned_u, topo.relation(u, v)):
                    continue
                role = topo.relation(v, u)           # what u is to v
                cand = ((v,) + path_u, role)
                cur = best.get(v)
                key = lambda e: (PREF[e[1]], len(e[0]), e[0][1] if len(e[0]) > 1 else 0)
                if cur is None or key(cand) < key(cur):
                    best[v] = cand
                    changed = True
    return best


@lru_cache(maxsize=256)
def received_routes(links: FrozenSet[RelationshipDecl],
                    origins: Optional[Tuple[ASN, ...]] = None) -> Tuple[ReceivedRoute, ...]:
    """Every route each AS receives from each neighbour, for the given origins.

    Uses propagate() (Gao-Rexford route selection and valley-free export) for
    each origin and records what every neighbour would send. Cached, because
    the planner asks for the same link sets many times.

    Args:
        links: the BGP links in use.
        origins: the ASes whose prefixes to simulate (all ASes if None).
    """
    topo = _topo(links)
    out: List[ReceivedRoute] = []
    for o in (origins or tuple(sorted(topo.ases))):
        best = propagate(links, o)
        for u, (path_u, learned_u) in best.items():
            for v, _ in topo.neighbours(u):
                if v in path_u or not _may_export(learned_u, topo.relation(u, v)):
                    continue
                out.append(ReceivedRoute(v, u, path_u, topo.relation(v, u)))  # type: ignore[arg-type]
    return tuple(out)


@lru_cache(maxsize=256)
def leak_probes(links: FrozenSet[RelationshipDecl],
                origins: Optional[Tuple[ASN, ...]] = None) -> Tuple[ReceivedRoute, ...]:
    """Synthetic route leaks used to measure the exposure window: every AS L
    re-exports its best provider- or peer-learned route to its OTHER providers
    and peers (an RFC 7908 type 1-4 leak)."""
    topo = _topo(links)
    out: List[ReceivedRoute] = []
    for o in (origins or tuple(sorted(topo.ases))):
        best = propagate(links, o)
        for leaker, (path_l, learned) in best.items():
            if learned not in (Relation.PROVIDER, Relation.PEER):
                continue
            came_from = path_l[1]
            for w, rel in topo.neighbours(leaker):
                if rel in (Relation.PROVIDER, Relation.PEER) and w != came_from and w not in path_l:
                    out.append(ReceivedRoute(w, leaker, path_l, topo.relation(w, leaker)))  # type: ignore[arg-type]
    return tuple(out)


@lru_cache(maxsize=256)
def reachable_pairs(links: FrozenSet[RelationshipDecl],
                    origins: Optional[Tuple[ASN, ...]] = None) -> FrozenSet[Tuple[ASN, ASN]]:
    """(AS, origin) pairs where the AS has a route to the origin's prefix."""
    topo = _topo(links)
    out = set()
    for o in (origins or tuple(sorted(topo.ases))):
        out |= {(v, o) for v in propagate(links, o)}
    return frozenset(out)
