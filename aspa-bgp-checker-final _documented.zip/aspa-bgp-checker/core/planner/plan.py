"""
core/planner/plan.py -- ASPA change planner.

Problem
-------
An operator wants to move from configuration C0 = (links L0, ASPA records D0)
to C1 = (L1, D1): e.g. switch transit provider, add a backup provider,
publish a first ASPA. RPKI changes reach validators with a delay of up to
DELTA minutes, and different validators update at different times. While a
change is spreading, some validators hold the old record and some the new.

Two things can go wrong:
  * OUTAGE   -- a legitimate route is INVALID at some validator (dropped);
  * EXPOSURE -- a leak that the target configuration would reject is accepted
                somewhere, because a provider is still listed in some view.

Model
-----
State   = (stage of each changing AS's record, link changes applied,
           versions each validator may still hold).
Actions = PUBLISH a new record version (instant),
          BGP link change (takes BETA minutes to converge; old and new routes
          both in use meanwhile),
          WAIT DELTA (afterwards every validator holds the latest version).
A state is SAFE if every legitimate received route is non-INVALID under
EVERY combination of record versions validators may hold.

Record stages per changing AS: old -> union -> new  (make-before-break), or
old -> new directly (replace). "union" = old providers + new providers.

Procedure PLAN_CHANGE(C0, C1, DELTA, BETA)
  Input : start and target configurations, validator lag bound, BGP convergence time
  Output: naive plan (with outages found), make-before-break plan, best plan
  1. If C0 or C1 is itself unsafe -> report the broken routes; no plan can be safe
  2. NAIVE := publish every new record, apply every link change, WAIT
  3. MBB   := publish unions, WAIT, link changes, publish new records, WAIT
  4. BEST  := Dijkstra over states using only SAFE states,
              cost = (total minutes, exposure route-minutes, number of steps)
  5. Evaluate all three: safety violations, duration, exposure
"""

from __future__ import annotations

import heapq
import itertools
from dataclasses import dataclass, field
from typing import Any, Dict, FrozenSet, List, Optional, Sequence, Tuple

from core.aspa.validator import verdict_for_route
from core.models import ASN, AspaRecord, RecordStatus, RelationshipDecl, Verdict
from core.planner.routing import ReceivedRoute, leak_probes, reachable_pairs, received_routes

OLD, UNION, NEW = "old", "union", "new"
MAX_SEARCH_STATES = 5000


# ------------------------------------------------------------------ model

@dataclass(frozen=True)
class ChangeProblem:
    """An ASPA change scenario: the network and records before and after.

    Attributes:
        change_id, description: identification for the report.
        links_before, links_after: BGP links before and after the change.
        records_before, records_after: ASPA records before and after.
        delta: maximum validator lag in minutes (a WAIT step lasts delta).
        beta: BGP convergence time in minutes (a BGP step lasts beta).
        validators: ASes that perform ASPA verification (None = all).
        origins: ASes whose prefixes are simulated (None = all).
    """
    change_id: str
    description: str
    links_before: FrozenSet[RelationshipDecl]
    links_after: FrozenSet[RelationshipDecl]
    records_before: Dict[ASN, AspaRecord]
    records_after: Dict[ASN, AspaRecord]
    delta: float = 60.0                    # minutes, max validator lag
    beta: float = 5.0                      # minutes, BGP convergence
    validators: Optional[FrozenSet[ASN]] = None   # None = every AS validates
    origins: Optional[Tuple[ASN, ...]] = None

    @property
    def changing(self) -> Tuple[ASN, ...]:
        """ASes whose ASPA record differs between before and after (sorted)."""
        keys = set(self.records_before) | set(self.records_after)
        return tuple(sorted(a for a in keys if self.records_before.get(a) != self.records_after.get(a)))

    @property
    def link_changes(self) -> Tuple[Tuple[str, Optional[RelationshipDecl], Optional[RelationshipDecl]], ...]:
        """BGP actions. A relationship whose TYPE changes on the same pair (e.g. transit
        -> peering) is one atomic 'change' action: the session is reconfigured."""
        added = sorted(self.links_after - self.links_before, key=_dkey)
        removed = sorted(self.links_before - self.links_after, key=_dkey)
        out: List[Tuple[str, Optional[RelationshipDecl], Optional[RelationshipDecl]]] = []
        for d in added:
            twin = next((o for o in removed if {o.a, o.b} == {d.a, d.b}), None)
            if twin is not None:
                removed.remove(twin)
                out.append(("change", twin, d))
            else:
                out.append(("add", None, d))
        out += [("remove", d, None) for d in removed]
        return tuple(out)

    @property
    def required_reachability(self) -> FrozenSet[Tuple[ASN, ASN]]:
        """(AS, origin) pairs reachable both before and after: must never be lost."""
        return reachable_pairs(self.links_before, self.origins) & reachable_pairs(self.links_after, self.origins)


def _dkey(d: RelationshipDecl) -> Tuple[str, int, int]:
    """Sort key for a relationship declaration."""
    return (d.kind, d.a, d.b)


def _present(rec: Optional[AspaRecord]) -> bool:
    """True if the record exists and has a valid signature."""
    return rec is not None and rec.status is RecordStatus.PRESENT


def _union_providers(p: ChangeProblem, asn: ASN) -> Optional[set]:
    """Providers of the temporary covering record: old record's providers (or, for a
    first publication, the providers actually in use before the change) plus the new ones."""
    old, new = p.records_before.get(asn), p.records_after.get(asn)
    if not _present(new):
        return None
    if _present(old):
        before = set(old.providers)  # type: ignore[union-attr]
    else:
        before = {d.a for d in p.links_before if d.kind == "provider-customer" and d.b == asn}
    return before | set(new.providers)  # type: ignore[union-attr]


def stage_record(p: ChangeProblem, asn: ASN, stage: str) -> Optional[AspaRecord]:
    """Return the ASPA record of ``asn`` at a given stage.

    OLD is the record before the change, NEW the record after, and UNION a
    temporary record listing both the old and the new providers (for a first
    publication: the providers in use before the change).
    """
    old, new = p.records_before.get(asn), p.records_after.get(asn)
    if stage == OLD:
        return old
    if stage == NEW:
        return new
    return AspaRecord(asn, RecordStatus.PRESENT, tuple(sorted(_union_providers(p, asn) or ())))


def stages_available(p: ChangeProblem, asn: ASN) -> List[Tuple[str, str]]:
    """Allowed record transitions for one AS: replace directly, or go through
    the temporary covering record (make-before-break)."""
    old, new = p.records_before.get(asn), p.records_after.get(asn)
    moves = [(OLD, NEW)]
    union = _union_providers(p, asn)
    if union is not None and union != set(new.providers):  # type: ignore[union-attr]
        if not (_present(old) and union == set(old.providers)):  # type: ignore[union-attr]
            moves += [(OLD, UNION), (UNION, NEW)]
    return moves


# ------------------------------------------------------------------ state

@dataclass(frozen=True)
class State:
    """A state of the change in progress (a node of the search).

    Attributes:
        stages: for each changing AS, the latest published record stage.
        links_done: indices of the BGP link changes already applied.
        pending: for each changing AS, the record versions that some
            validator may still hold (one version once a WAIT has passed).
    """
    stages: Tuple[str, ...]                      # per changing AS (latest published)
    links_done: FrozenSet[int]                   # indices into link_changes
    pending: Tuple[Tuple[str, ...], ...]         # per changing AS: versions validators may hold


@dataclass
class Check:
    """Result of checking one state.

    Attributes:
        safe: True if no required route is lost and no legitimate route is
            INVALID in any validator view.
        violations: the legitimate routes rejected (with validator and view).
        exposed: number of leak probes that are still accepted.
        exposed_list: details of those leak probes.
    """
    safe: bool
    violations: List[Dict[str, Any]] = field(default_factory=list)
    exposed: int = 0
    exposed_list: List[Dict[str, Any]] = field(default_factory=list)


def links_of(p: ChangeProblem, done: FrozenSet[int]) -> FrozenSet[RelationshipDecl]:
    """Return the BGP link set after applying the link changes in ``done``."""
    links = set(p.links_before)
    for i, (_, old, new) in enumerate(p.link_changes):
        if i in done:
            if old is not None:
                links.discard(old)
            if new is not None:
                links.add(new)
    return frozenset(links)


def _views(p: ChangeProblem, pending: Tuple[Tuple[str, ...], ...], route: ReceivedRoute
           ) -> List[Dict[ASN, AspaRecord]]:
    """Every database a validator might hold, restricted to ASes on this route."""
    base = {a: r for a, r in p.records_before.items() if a not in p.changing}
    on_path = set(route.wire)
    choices = []
    for asn, versions in zip(p.changing, pending):
        if asn in on_path:
            choices.append([(asn, v) for v in dict.fromkeys(versions)])
        else:
            choices.append([(asn, versions[-1])])
    out = []
    for combo in itertools.product(*choices):
        db = dict(base)
        for asn, stage in combo:
            rec = stage_record(p, asn, stage)
            if rec is not None:
                db[asn] = rec
            else:
                db.pop(asn, None)
        out.append(db)
    return out


def _target_db(p: ChangeProblem) -> Dict[ASN, AspaRecord]:
    """The ASPA database after the change (unchanged records plus the new ones)."""
    db = {a: r for a, r in p.records_before.items() if a not in p.changing}
    db.update({a: r for a, r in p.records_after.items() if r is not None})
    return db


_CHECK_CACHE: Dict[Any, Check] = {}


def check_state(p: ChangeProblem, pending: Tuple[Tuple[str, ...], ...],
                link_sets: Sequence[FrozenSet[RelationshipDecl]], detail: bool = True) -> Check:
    """Check whether a state is safe and count its leak exposure (cached).

    Every legitimate route is checked under every validator view (every mix
    of the pending record versions) and for every link set given (during a
    BGP change both the old and the new link set are in use).

    Args:
        p: the change problem.
        pending: record versions validators may hold, per changing AS.
        link_sets: the BGP link sets in use during the step.
        detail: also record the individual violations and exposed leaks.
    """
    key = (id(p), pending, tuple(link_sets), detail)
    if key not in _CHECK_CACHE:
        _CHECK_CACHE[key] = _check_state(p, pending, link_sets, detail)
    return _CHECK_CACHE[key]


def _check_state(p: ChangeProblem, pending: Tuple[Tuple[str, ...], ...],
                 link_sets: Sequence[FrozenSet[RelationshipDecl]], detail: bool = True) -> Check:
    """SAFE if no legitimate route (from any of `link_sets`, i.e. before/after a
    BGP change) is INVALID under any possible validator view."""
    chk = Check(True)
    seen = set()
    need = p.required_reachability
    for links in link_sets:
        lost = need - reachable_pairs(links, p.origins)
        if lost:
            chk.safe = False
            if detail:
                for v, o in sorted(lost)[:20]:
                    chk.violations.append({"validator": v, "from": None, "path": [o],
                                           "view": "the BGP step order cuts reachability"})
    for links in link_sets:
        for r in received_routes(links, p.origins):
            if (p.validators is not None and r.receiver not in p.validators) or (r.receiver, r.wire) in seen:
                continue
            seen.add((r.receiver, r.wire))
            for db in _views(p, pending, r):
                if verdict_for_route(r.wire, r.sender, r.receiver, r.sender_role, db) is Verdict.INVALID:
                    chk.safe = False
                    if detail:
                        held = {a: ("no record" if a not in db else list(db[a].providers))
                                for a in p.changing if a in r.wire}
                        chk.violations.append({"validator": r.receiver, "from": r.sender,
                                               "path": list(r.wire), "view": held})
                    break
            if not chk.safe and not detail:
                return chk
    # exposure: leaks the TARGET configuration rejects but some view accepts
    target = _target_db(p)
    changing = set(p.changing)
    exposed = set()
    for links in link_sets:
        for pr in leak_probes(links, p.origins):
            if (p.validators is not None and pr.receiver not in p.validators) or not changing & set(pr.wire):
                continue
            if verdict_for_route(pr.wire, pr.sender, pr.receiver, pr.sender_role, target) is not Verdict.INVALID:
                continue
            if any(verdict_for_route(pr.wire, pr.sender, pr.receiver, pr.sender_role, db) is not Verdict.INVALID
                   for db in _views(p, pending, pr)):
                if (pr.receiver, pr.wire) not in exposed:
                    chk.exposed_list.append({"receiver": pr.receiver, "leaker": pr.sender, "path": list(pr.wire)})
                exposed.add((pr.receiver, pr.wire))
    chk.exposed = len(exposed)
    return chk


# ------------------------------------------------------------------ plan execution

@dataclass
class Step:
    """One executed step of a plan, as shown in the report.

    Attributes:
        action: "publish", "bgp" or "wait".
        text: description of the step.
        minutes: how long the step lasts (0, beta or delta).
        safe: whether the state during the step is safe.
        exposed: number of leak probes still accepted during the step.
        violations, exposed_list: the details behind safe and exposed.
    """
    action: str
    text: str
    minutes: float
    safe: bool
    exposed: int
    violations: List[Dict[str, Any]] = field(default_factory=list)
    exposed_list: List[Dict[str, Any]] = field(default_factory=list)


@dataclass
class PlanResult:
    """A complete plan (a named list of steps) with its totals."""
    name: str
    steps: List[Step]

    @property
    def safe(self) -> bool:
        """True if every step of the plan is safe."""
        return all(s.safe for s in self.steps)

    @property
    def minutes(self) -> float:
        """Total duration of the plan in minutes."""
        return sum(s.minutes for s in self.steps)

    @property
    def exposure(self) -> float:
        """Leak exposure in route-minutes: sum of step minutes x exposed leak probes."""
        return sum(s.minutes * s.exposed for s in self.steps)

    @property
    def outage_route_minutes(self) -> float:
        """Outage in route-minutes: sum of step minutes x rejected legitimate routes."""
        return sum(s.minutes * len(s.violations) for s in self.steps)

    @property
    def outage_routes(self) -> int:
        """Number of distinct legitimate routes rejected at some point of the plan."""
        return len({(v["validator"], tuple(v["path"])) for s in self.steps for v in s.violations})

    def to_dict(self) -> Dict[str, Any]:
        """Return the plan, its totals and its steps as a dictionary."""
        return {"name": self.name, "safe": self.safe, "minutes": self.minutes,
                "exposure_route_minutes": self.exposure, "routes_at_risk": self.outage_routes,
                "outage_route_minutes": self.outage_route_minutes,
                "steps": [s.__dict__ for s in self.steps]}


def _initial(p: ChangeProblem) -> State:
    """The start state: every record OLD, no BGP change applied, nothing pending."""
    n = len(p.changing)
    return State(tuple([OLD] * n), frozenset(), tuple((OLD,) for _ in range(n)))


def _describe_publish(p: ChangeProblem, asn: ASN, stage: str) -> str:
    """Describe a publish step, e.g. "publish AS300's ASPA = {AS250}"."""
    rec = stage_record(p, asn, stage)
    if rec is None or rec.status is not RecordStatus.PRESENT:
        return f"withdraw AS{asn}'s ASPA"
    provs = ", ".join(f"AS{x}" for x in rec.providers) or "AS0 (no providers)"
    return f"publish AS{asn}'s ASPA = {{{provs}}}" + (" (temporary union)" if stage == UNION else "")


def _link_text(d: RelationshipDecl) -> str:
    """Describe one link, e.g. 'AS200 provider of AS300' or 'peering AS200-AS300'."""
    return f"AS{d.a} provider of AS{d.b}" if d.kind == "provider-customer" else f"peering AS{d.a}-AS{d.b}"


def _describe_link(op: str, old: Optional[RelationshipDecl], new: Optional[RelationshipDecl]) -> str:
    """Describe a BGP link change (bring up, shut down or reconfigure)."""
    if op == "change":
        return f"BGP: reconfigure session from {_link_text(old)} to {_link_text(new)}"  # type: ignore[arg-type]
    return f"BGP: {'bring up' if op == 'add' else 'shut down'} {_link_text(new if op == 'add' else old)}"  # type: ignore[arg-type]


def apply_action(p: ChangeProblem, st: State, action: Tuple[Any, ...]) -> Tuple[State, Step]:
    """Apply one action to a state and return the new state and the executed step.

    Actions:
        ("publish", i, stage): publish the given record stage for changing AS i
            (0 minutes; the old version stays pending until a WAIT).
        ("bgp", i): apply BGP link change i (beta minutes; old and new routes
            are both checked).
        ("wait",): wait delta minutes; afterwards every validator holds the
            latest version.
    """
    kind = action[0]
    if kind == "publish":
        _, idx, to_stage = action
        stages = list(st.stages)
        stages[idx] = to_stage
        pend = list(st.pending)
        pend[idx] = pend[idx] + (to_stage,)
        ns = State(tuple(stages), st.links_done, tuple(pend))
        chk = check_state(p, ns.pending, [links_of(p, ns.links_done)])
        return ns, Step("publish", _describe_publish(p, p.changing[idx], to_stage), 0.0,
                        chk.safe, chk.exposed, chk.violations, chk.exposed_list)
    if kind == "bgp":
        _, i = action
        ns = State(st.stages, st.links_done | {i}, st.pending)
        chk = check_state(p, st.pending, [links_of(p, st.links_done), links_of(p, ns.links_done)])
        op, old, new = p.link_changes[i]
        return ns, Step("bgp", _describe_link(op, old, new), p.beta, chk.safe, chk.exposed, chk.violations, chk.exposed_list)
    # wait: the state does not change during the wait, but its risks last DELTA minutes
    chk = check_state(p, st.pending, [links_of(p, st.links_done)])
    ns = State(st.stages, st.links_done, tuple((v[-1],) for v in st.pending))
    return ns, Step("wait", f"wait {p.delta:g} min until every validator has the latest records",
                    p.delta, chk.safe, chk.exposed, chk.violations, chk.exposed_list)


def run_plan(p: ChangeProblem, name: str, actions: Sequence[Tuple[Any, ...]]) -> PlanResult:
    """Execute a list of actions from the start state and return the resulting PlanResult."""
    st = _initial(p)
    steps = []
    for a in actions:
        st, step = apply_action(p, st, a)
        steps.append(step)
    return PlanResult(name, steps)


def naive_actions(p: ChangeProblem) -> List[Tuple[Any, ...]]:
    """The naive plan: publish every final record, apply every BGP change, then wait once."""
    acts: List[Tuple[Any, ...]] = [("publish", i, NEW) for i in range(len(p.changing))]
    acts += [("bgp", i) for i in range(len(p.link_changes))]
    return acts + [("wait",)]


def mbb_actions(p: ChangeProblem) -> List[Tuple[Any, ...]]:
    """The make-before-break plan used as the textbook baseline.

    New providers are added first (UNION record, or the final record for a
    pure addition), then one WAIT, then the BGP changes in the order
    add -> change -> remove, then the final records for removals, then a WAIT.
    """
    acts: List[Tuple[Any, ...]] = []
    late = []
    for i, asn in enumerate(p.changing):
        moves = stages_available(p, asn)
        old, new = p.records_before.get(asn), p.records_after.get(asn)
        if (OLD, UNION) in moves:                       # add new providers first, remove later
            acts.append(("publish", i, UNION))
            late.append(("publish", i, NEW))
        elif _present(old) and _present(new) and set(new.providers) <= set(old.providers):  # type: ignore[union-attr]
            late.append(("publish", i, NEW))            # pure removal: after the BGP change
        else:
            acts.append(("publish", i, NEW))            # pure addition or first publication
    if acts:
        acts.append(("wait",))
    # sensible BGP order: bring up new links, then reconfigure, then shut down old ones
    order = {"add": 0, "change": 1, "remove": 2}
    acts += [("bgp", i) for i, _ in sorted(enumerate(p.link_changes), key=lambda e: (order[e[1][0]], e[0]))]
    if late:
        acts += late + [("wait",)]
    return acts


# ------------------------------------------------------------------ search

def search_best(p: ChangeProblem) -> Optional[PlanResult]:
    """Dijkstra over SAFE states. Cost = (minutes, exposure route-minutes, steps)."""
    start = _initial(p)
    n_links = len(p.link_changes)
    goal_stages = tuple([NEW] * len(p.changing))
    counter = itertools.count()
    heap: List[Any] = [((0.0, 0.0, 0), next(counter), start, [])]
    best_cost: Dict[State, Tuple[float, float, int]] = {start: (0.0, 0.0, 0)}
    expanded = 0
    while heap:
        cost, _, st, acts = heapq.heappop(heap)
        if best_cost.get(st, cost) < cost:
            continue
        if st.stages == goal_stages and len(st.links_done) == n_links and all(len(v) == 1 for v in st.pending):
            return run_plan(p, "best (searched)", acts)
        expanded += 1
        if expanded > MAX_SEARCH_STATES:
            return None
        moves: List[Tuple[Any, ...]] = []
        for i, asn in enumerate(p.changing):
            for frm, to in stages_available(p, asn):
                if st.stages[i] == frm:
                    moves.append(("publish", i, to))
        moves += [("bgp", i) for i in range(n_links) if i not in st.links_done]
        if any(len(v) > 1 for v in st.pending):
            moves.append(("wait",))
        for m in moves:
            ns, step = apply_action(p, st, m)
            if not step.safe:
                continue
            nc = (cost[0] + step.minutes, cost[1] + step.minutes * step.exposed, cost[2] + 1)
            if nc < best_cost.get(ns, (float("inf"),) * 3):
                best_cost[ns] = nc
                heapq.heappush(heap, (nc, next(counter), ns, acts + [m]))
    return None


# ------------------------------------------------------------------ top level

def plan_change(p: ChangeProblem) -> Dict[str, Any]:
    """Plan an ASPA change and compare the three plans.

    Checks that the start and target configurations are themselves safe,
    then builds the naive and make-before-break plans and searches for the
    best safe plan (search_best). The result contains all three plans with
    their steps, safety, duration and exposure.

    Args:
        p: the change problem.

    Returns:
        A dictionary used by report.render_plan() and by --json output.
    """
    _CHECK_CACHE.clear()
    n = len(p.changing)
    start_chk = check_state(p, tuple((OLD,) for _ in range(n)), [p.links_before])
    end_chk = check_state(p, tuple((NEW,) for _ in range(n)), [p.links_after])
    result: Dict[str, Any] = {
        "change_id": p.change_id, "description": p.description,
        "changing_records": [f"AS{a}" for a in p.changing],
        "link_changes": [_describe_link(op, o, n) for op, o, n in p.link_changes],
        "delta_minutes": p.delta, "bgp_convergence_minutes": p.beta,
        "start_safe": start_chk.safe, "target_safe": end_chk.safe,
        "start_violations": start_chk.violations, "target_violations": end_chk.violations,
        "first_publication": [f"AS{a}" for a in p.changing if not _present(p.records_before.get(a))],
    }
    naive = run_plan(p, "naive (change everything at once)", naive_actions(p))
    mbb = run_plan(p, "make-before-break", mbb_actions(p))
    best = search_best(p) if start_chk.safe and end_chk.safe else None
    result["plans"] = [x.to_dict() for x in (naive, mbb, best) if x is not None]
    result["best_found"] = best is not None
    return result
