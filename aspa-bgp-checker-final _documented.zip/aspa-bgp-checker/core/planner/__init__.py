"""ASPA change planner: plans record and BGP changes that stay safe while
validators hold different record versions (see docs/change_planner.md)."""
