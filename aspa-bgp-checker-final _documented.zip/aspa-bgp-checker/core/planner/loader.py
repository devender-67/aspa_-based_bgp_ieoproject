"""
core/planner/loader.py -- load a change scenario (JSON) into a ChangeProblem.

Format (schema "aspa-change", version 0.1):
{
  "schema_version": "0.1", "kind": "aspa-change",
  "change_id": "...", "description": "...",
  "topology_before": {"relationships": [ ...provider-customer / peer... ]},
  "topology_after":  {"relationships": [ ... ]},
  "aspa_before": [ ASPA records, same format as scenarios ],
  "aspa_after":  [ ... ],
  "parameters": {"delta_minutes": 60, "bgp_convergence_minutes": 5,
                 "validators": "all" | [ASNs], "origins": "all" | [ASNs]}
}
Only provider-customer and peer links are supported by the route simulator.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, FrozenSet, Optional, Tuple

from core.models import RelationshipDecl
from core.parser import InputError, _parse_asn, _parse_aspa, _parse_topology, _require
from core.planner.plan import ChangeProblem


def _links(raw: Dict[str, Any], where: str) -> FrozenSet[RelationshipDecl]:
    """Parse a link list for the planner (only provider-customer and peer links are supported)."""
    rels = _require(raw, "relationships", where)
    ases = set()
    for r in rels:
        if r.get("type") not in ("provider-customer", "peer"):
            raise InputError(f"{where}: the change planner supports only provider-customer and peer links")
        ases |= {r.get("provider"), r.get("customer"), *r.get("ases", [])}
    ases.discard(None)
    _, decls = _parse_topology({"ases": sorted(ases), "relationships": rels})
    return frozenset(decls)


def parse_change(data: Dict[str, Any]) -> ChangeProblem:
    """Validate a change-scenario dictionary and convert it into a ChangeProblem.

    Expects "kind": "aspa-change", the topology and ASPA records before and
    after, and optional parameters (delta_minutes, bgp_convergence_minutes,
    validators, origins).

    Raises:
        InputError: if the input is malformed.
    """
    if data.get("kind") != "aspa-change":
        raise InputError("not a change scenario (expected \"kind\": \"aspa-change\")")
    before = _links(_require(data, "topology_before", "top level"), "topology_before")
    after = _links(_require(data, "topology_after", "top level"), "topology_after")
    rb = _parse_aspa(data.get("aspa_before", []))
    ra = _parse_aspa(data.get("aspa_after", []))
    params = data.get("parameters", {}) or {}

    def asn_list(key: str) -> Optional[Tuple[int, ...]]:
        """Read an AS-number list parameter; the value "all" (default) returns None."""
        v = params.get(key, "all")
        if v == "all":
            return None
        return tuple(sorted(_parse_asn(x, f"parameters.{key}") for x in v))

    vals = asn_list("validators")
    return ChangeProblem(
        change_id=str(data.get("change_id", "unnamed")),
        description=str(data.get("description", "")),
        links_before=before, links_after=after,
        records_before=rb, records_after=ra,
        delta=float(params.get("delta_minutes", 60)),
        beta=float(params.get("bgp_convergence_minutes", 5)),
        validators=None if vals is None else frozenset(vals),
        origins=asn_list("origins"),
    )


def load_change(path: str) -> ChangeProblem:
    """Read a change-scenario JSON file and parse it with parse_change()."""
    f = Path(path)
    if not f.is_file():
        raise InputError(f"file not found: {path}")
    try:
        return parse_change(json.loads(f.read_text(encoding="utf-8")))
    except json.JSONDecodeError as exc:
        raise InputError(f"{path}: invalid JSON at line {exc.lineno}: {exc.msg}") from None
