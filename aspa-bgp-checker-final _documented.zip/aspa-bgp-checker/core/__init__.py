"""Verification core: input models, parsing, topology, both layers, aggregation,
explanations, the Unknown-resolution engine and the change planner."""
