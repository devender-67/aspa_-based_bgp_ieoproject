"""
core/policy/export_policy.py -- LAYER 2: may the exporter send this route
to this neighbour?

Point of view: the EXPORTING AS. Uses where the route was learned from and
the OTC attribute -- neither is used by Layer 1.

Procedure EXPORT_POLICY_VERIFY(scenario)
  Input : exporter X, receiver Y, learned_from L, prefix, OTC, roles, exceptions
  Output: VALID | INVALID | UNKNOWN, with sub-results
  1. source := role of L seen from X ("local" if no L), per-prefix for complex
  2. target := role of Y seen from X
  3. vf  := VALLEY_FREE(source, target)                     (valley_free.py)
  4. otc := OTC_CHECK(...)                                   (otc.py)
  5. If vf or otc is a violation   -> INVALID
     Else if vf or otc is unknown  -> UNKNOWN
     Else                          -> VALID   (OTC NOT_APPLICABLE counts as no objection)
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple

from core.models import OTC_RFC, ASN, LayerResult, Relation, Scenario, Verdict
from core.policy.otc import NOT_APPLICABLE, UNKNOWN, VIOLATION, check_otc
from core.policy.valley_free import valley_free
from core.topology import Topology

ROLE_NAME = {Relation.CUSTOMER: "customer", Relation.PROVIDER: "provider", Relation.PEER: "peer",
             Relation.RS: "rs", Relation.RS_CLIENT: "rs_client", Relation.COMPLEX: "complex"}
PLAIN = {"customer": "customer", "provider": "provider", "peer": "peer", "rs": "route server",
         "rs_client": "RS-client", "complex": "complex neighbour (no role for this prefix)",
         "local": "itself (locally originated)"}


def _role(topo: Topology, x: ASN, other: Optional[ASN], prefix: Optional[str]) -> Optional[str]:
    """Return what ``other`` is to ``x`` as a role name; 'local' if there is no other AS."""
    if other is None:
        return "local"
    rel = topo.relation(of=x, to=other, prefix=prefix)
    return None if rel is None else ROLE_NAME[rel]


def _exception(s: Scenario) -> Optional[str]:
    """Return the reason of a configured export exception that matches this export, if any."""
    for e in s.policy.exceptions:
        if e.receiving_as == s.export.receiving_as and e.learned_from in (None, s.route.learned_from):
            return e.reason
    return None


def verify_export_policy(s: Scenario, topo: Topology) -> LayerResult:
    """LAYER 2: may the exporter send this route to this neighbour?

    Combines the valley-free rules and the OTC rules from the exporter's
    point of view. A missing relationship is reported as missing information
    (UNKNOWN), never guessed.

    Args:
        s: the scenario.
        topo: the declared topology.

    Returns:
        A LayerResult with verdict VALID, INVALID or UNKNOWN and its reasons.
    """
    x, y, lf = s.export.exporting_as, s.export.receiving_as, s.route.learned_from
    prefix = s.route.prefix
    source = _role(topo, x, lf, prefix)
    target = _role(topo, x, y, prefix)
    missing: List[str] = []
    if source is None:
        missing.append(f"relationship between AS{x} and AS{lf} (route source)")
    elif source == "complex":
        missing.append(f"role of AS{lf} for prefix {prefix} (complex relationship)")
    if target is None:
        missing.append(f"relationship between AS{x} and AS{y} (export target)")
    elif target == "complex":
        missing.append(f"role of AS{y} for prefix {prefix} (complex relationship)")

    src_text = PLAIN["local"] if source == "local" else \
        f"its {PLAIN.get(source or '', 'undeclared neighbour')} AS{lf}"
    tgt_text = f"its {PLAIN.get(target or '', 'undeclared neighbour')} AS{y}"
    situation = f"AS{x} learned this route from {src_text} and wants to send it to {tgt_text}"

    # 3. valley-free
    vf_verdict, vf_rule = valley_free(source, target, _exception(s))

    # 4. OTC
    otc = check_otc(s.route.otc, s.policy.bgp_roles_configured, source, lf, target, x,
                    source_complex=lf is not None and topo.is_complex(x, lf),
                    target_complex=topo.is_complex(x, y))
    if otc["status"] == UNKNOWN:
        if not s.route.otc.known:
            missing.append("OTC state of the received route")

    # 5. combine
    otc_bad, otc_unk = otc["status"] == VIOLATION, otc["status"] == UNKNOWN
    if vf_verdict is Verdict.INVALID or otc_bad:
        verdict = Verdict.INVALID
    elif vf_verdict is Verdict.UNKNOWN or otc_unk:
        verdict = Verdict.UNKNOWN
    else:
        verdict = Verdict.VALID

    reasons = [situation, f"valley-free check: {vf_verdict.value} -- {vf_rule}",
               f"OTC check: {otc['status']} ({otc['received']})"] + [f"OTC step: {t}" for t in otc["steps"]]
    if verdict is Verdict.INVALID:
        deciding = vf_rule if vf_verdict is Verdict.INVALID else otc["rule"]
        if vf_verdict is Verdict.INVALID and otc_bad:
            deciding = f"{vf_rule}; also {otc['rule']}"
    elif verdict is Verdict.UNKNOWN:
        deciding = vf_rule if vf_verdict is Verdict.UNKNOWN else otc["rule"]
    else:
        deciding = vf_rule

    details: Dict[str, Any] = {
        "route_source": source, "export_target": target,
        "valley_free": {"verdict": vf_verdict.value, "rule": vf_rule},
        "otc": otc,
        "bgp_roles_configured": s.policy.bgp_roles_configured,
        "situation": situation,
    }
    summary = {Verdict.VALID: "export permitted", Verdict.INVALID: "export violates policy",
               Verdict.UNKNOWN: "export cannot be decided: policy information missing"}[verdict]
    return LayerResult("EXPORT_POLICY", verdict, summary, reasons, deciding,
                       ["RFC 9234 Sec. 3.1 (roles)", f"{OTC_RFC} Sec. 5 (OTC)",
                        "Gao-Rexford export conventions"], missing, details)
