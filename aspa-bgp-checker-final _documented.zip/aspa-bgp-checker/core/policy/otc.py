"""
core/policy/otc.py -- RFC 9234 Only-To-Customer (OTC) checks (part of Layer 2).

What OTC is: an optional transitive BGP attribute holding an AS number.
Once a route has been sent "downhill or sideways" (to a customer, peer or
RS-client), OTC marks it so that nobody later sends it uphill or sideways.

Roles below are "what the other AS is, seen from the exporter".

Procedure OTC_CHECK(otc, source, source_as, target, local_as)      [RFC 9234 Sec. 5]
  Input : OTC as received, source role/AS, target role, exporter AS
  Output: PASS | VIOLATION | UNKNOWN | NOT_APPLICABLE, plus the OTC sent
  0. If BGP Roles are not configured         -> NOT_APPLICABLE (reported only)
  Ingress, on the session the route was learned on (skipped for local
  routes and for complex sessions, where Roles must not be configured):
  1. OTC present and source is customer or RS-client      -> VIOLATION (leak, ineligible)
  2. OTC present, source is peer, OTC value != peer's AS  -> VIOLATION (leak, ineligible)
  3. OTC absent and source is provider, peer or RS        -> set OTC = source AS
  Egress, on the session toward the receiver (skipped for complex sessions):
  4. OTC present and target is provider, peer or RS       -> VIOLATION (must not propagate)
  5. OTC absent and target is customer, peer, or RS-client
     (the last only when the exporter is an RS)           -> sent with OTC = local AS
  6. Otherwise                                             -> PASS
  If the received OTC state is unknown, steps 1-6 are run for every possible
  state (absent / equal to source AS / some other AS). Same result for all
  -> that result; different results -> UNKNOWN.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple

from core.models import ASN, OtcInput

PASS, VIOLATION, UNKNOWN, NOT_APPLICABLE = "PASS", "VIOLATION", "UNKNOWN", "NOT_APPLICABLE"
OTHER_AS = -1          # placeholder for "an AS other than the source"


def describe_otc(otc: OtcInput) -> str:
    """Describe in words what is known about the OTC attribute of the received route."""
    if not otc.known:
        return "OTC state of the received route was not given"
    if otc.present:
        return f"received with OTC = AS{otc.value}"
    return "received without OTC"


def _one_state(present: bool, value: Optional[ASN], source: Optional[str], source_as: Optional[ASN],
               target: Optional[str], local_as: ASN, ingress_ok: bool, egress_ok: bool
               ) -> Tuple[str, List[str], Optional[ASN], str]:
    """Apply the OTC ingress and egress rules for one known OTC state of the route."""
    steps: List[str] = []
    rule = ""
    if ingress_ok and source not in (None, "local"):
        if present and source in ("customer", "rs_client"):
            return VIOLATION, [f"route carries OTC = {_v(value)} but came from a {source}: "
                               "it was already leaked upstream"], value, "RFC 9234 Sec. 5 ingress rule 1"
        if present and source == "peer" and value != source_as:
            return VIOLATION, [f"route from peer AS{source_as} carries OTC = {_v(value)} != AS{source_as}: "
                               "the peer passed on a route it must not"], value, "RFC 9234 Sec. 5 ingress rule 2"
        if not present and source in ("provider", "peer", "rs"):
            present, value = True, source_as
            steps.append(f"ingress rule 3: OTC added on receipt, value AS{source_as}")
    elif not ingress_ok:
        steps.append("ingress rules skipped: complex session (RFC 9234 Roles are not configured on it)")
    elif source is None:
        steps.append("ingress rules skipped: source relationship not declared")
    if not egress_ok:
        steps.append("egress rules skipped: complex session (RFC 9234 Roles are not configured on it)")
        return PASS, steps, value if present else None, rule
    if target is None:
        if present:
            return UNKNOWN, steps + ["OTC is present and the target relationship is unknown"], value, \
                "RFC 9234 Sec. 5 egress rule 2 (target unknown)"
        return PASS, steps + ["OTC absent: OTC alone does not restrict this export"], None, rule
    if present and target in ("provider", "peer", "rs"):
        return VIOLATION, steps + [f"route carries OTC = {_v(value)} and must not be sent to a {target}"], \
            value, "RFC 9234 Sec. 5 egress rule 2"
    if not present and target in ("customer", "peer", "rs_client"):
        steps.append(f"egress rule 1: sent with OTC = AS{local_as}")
        return PASS, steps, local_as, "RFC 9234 Sec. 5 egress rule 1"
    steps.append("no OTC rule forbids this export")
    return PASS, steps, value if present else None, rule


def _v(value: Optional[ASN]) -> str:
    """Format an OTC value for the report."""
    return "another AS" if value == OTHER_AS else f"AS{value}"


def check_otc(otc: OtcInput, roles_configured: Optional[bool], source: Optional[str],
              source_as: Optional[ASN], target: Optional[str], local_as: ASN,
              source_complex: bool, target_complex: bool) -> Dict[str, Any]:
    """Apply the RFC 9234 Sec. 5 OTC ingress and egress rules.

    If BGP Roles are not configured the rules are reported as NOT_APPLICABLE.
    If the OTC state of the received route is unknown, every possible state
    is tried and the result is UNKNOWN unless they all agree.

    Args:
        otc: OTC information of the received route.
        roles_configured: whether BGP Roles are configured.
        source, source_as: where (and from whom) the route was learned.
        target: what the receiver is to the exporter.
        local_as: the exporting AS.
        source_complex, target_complex: True if that session is complex
            (RFC 9234 roles do not apply to it).

    Returns:
        A dictionary with "status" (PASS, VIOLATION, UNKNOWN or
        NOT_APPLICABLE), the rule, the steps taken and the OTC that would be sent.
    """
    if not roles_configured:
        why = "not configured" if roles_configured is False else "not stated"
        return {"status": NOT_APPLICABLE, "rule": "RFC 9234 Sec. 5 needs BGP Roles",
                "steps": [f"BGP Roles {why} on these sessions: OTC rules not evaluated "
                          "(reported only; the valley-free check still applies)"],
                "sent_otc": None, "received": describe_otc(otc)}

    ingress_ok, egress_ok = not source_complex, not target_complex
    if otc.known:
        states = [(otc.present, otc.value)]
    else:
        states = [(False, None)] + ([(True, source_as)] if source_as else []) + [(True, OTHER_AS)]

    outcomes = []
    for present, value in states:
        st, steps, sent, rule = _one_state(present, value, source, source_as, target, local_as,
                                           ingress_ok, egress_ok)
        label = "absent" if not present else f"OTC = {_v(value)}"
        outcomes.append({"state": label, "status": st, "steps": steps, "sent_otc": sent, "rule": rule})

    statuses = {o["status"] for o in outcomes}
    if len(outcomes) == 1:
        o = outcomes[0]
        return {"status": o["status"], "rule": o["rule"], "steps": o["steps"],
                "sent_otc": o["sent_otc"], "received": describe_otc(otc)}
    if len(statuses) == 1:
        o = outcomes[0]
        return {"status": o["status"], "rule": o["rule"],
                "steps": [f"OTC state unknown, but every possible state gives {o['status']}"],
                "sent_otc": None, "received": describe_otc(otc), "cases": outcomes}
    return {"status": UNKNOWN, "rule": "RFC 9234 Sec. 5 (outcome depends on the unknown OTC state)",
            "steps": [f"if {o['state']}: {o['status']}" for o in outcomes],
            "sent_otc": None, "received": describe_otc(otc), "cases": outcomes}
