"""
core/policy/valley_free.py -- conventional export rules (part of Layer 2).

Sources: RFC 9234 Sec. 3.1 role propagation rules, which write down the
Gao-Rexford "valley-free" convention, plus RS / RS-client roles.

Plain version: you share routes from your CUSTOMERS (and your own) with
everyone, because customers pay you. Routes from PROVIDERS and PEERS go
only to your customers, otherwise you give free transit to someone.

Roles below are "what the other AS is, seen from the exporter":

    route source \\ target | customer | RS-client* | peer | provider | RS
    ---------------------+----------+------------+------+----------+----
    local / customer     |   yes    |    yes     | yes  |   yes    | yes
    provider / peer / RS |   yes    |    yes*    |  no  |    no    | no
    (* RS-client targets exist only when the exporter is a route server,
       and an RS "MAY propagate any available route to an RS-Client")

Procedure VALLEY_FREE(source, target)
  Input : source role (or None if undeclared), target role (or None)
  Output: VALID | INVALID | UNKNOWN, rule text
  1. If a configured exception matches (learned_from, receiver) -> VALID
  2. If target is customer or RS-client      -> VALID (any route may go there)
  3. If source is local or customer          -> VALID (may go anywhere)
  4. If source and target are both known     -> INVALID (non-customer route
                                                 to a non-customer)
  5. Otherwise (a role needed is unknown)    -> UNKNOWN
"""

from __future__ import annotations

from typing import Optional, Tuple

from core.models import Verdict

OPEN_TARGETS = {"customer", "rs_client"}
OPEN_SOURCES = {"local", "customer"}
KNOWN_ROLES = {"local", "customer", "provider", "peer", "rs", "rs_client"}

RULE_TEXT = {
    "peer": "RFC 9234 Sec. 3.1 (Peer): only routes learned from a customer or locally "
            "originated may be sent to a peer",
    "provider": "RFC 9234 Sec. 3.1 (Customer role toward a provider): only routes learned from a "
                "customer or locally originated may be sent to a provider",
    "rs": "RFC 9234 Sec. 3.1 (RS-Client): only routes learned from a customer or locally "
          "originated may be sent to a route server",
}


def valley_free(source: Optional[str], target: Optional[str],
                exception_reason: Optional[str] = None) -> Tuple[Verdict, str]:
    """Apply the conventional (valley-free) export rules of RFC 9234 Sec. 3.1.

    Args:
        source: where the exporter learned the route ("local", "customer",
            "peer", "provider", "rs", "rs_client", "complex" or None).
        target: what the receiver is to the exporter (same vocabulary).
        exception_reason: set if a configured local exception allows the export.

    Returns:
        (verdict, rule): VALID if the export is allowed, INVALID if it is
        forbidden, UNKNOWN if a needed relationship is not declared.
    """
    if exception_reason:
        return Verdict.VALID, f"allowed by a configured export exception: {exception_reason}"
    if target in OPEN_TARGETS:
        return Verdict.VALID, ("RFC 9234 Sec. 3.1: any available route may be sent to a "
                               + ("customer" if target == "customer" else "RS-client (exporter is a route server)"))
    if source in OPEN_SOURCES:
        what = "locally originated" if source == "local" else "learned from a customer"
        return Verdict.VALID, f"RFC 9234 Sec. 3.1: a route {what} may be sent to any neighbour"
    if source in KNOWN_ROLES and target in KNOWN_ROLES:
        return Verdict.INVALID, RULE_TEXT.get(target, "non-customer route sent to a non-customer")
    return Verdict.UNKNOWN, "the role needed to apply RFC 9234 Sec. 3.1 is not declared"
