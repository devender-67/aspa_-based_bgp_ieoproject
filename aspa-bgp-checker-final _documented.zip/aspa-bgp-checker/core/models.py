"""
core/models.py -- shared data types for the whole checker.

Everything the two verification layers exchange is defined here, so the
ASPA engine and the export-policy engine never import each other.

Conventions used everywhere
---------------------------
* An ASN is an int in 1 .. 4294967295. AS 0 appears only inside an ASPA
  provider list, where it means "this AS has no providers".
* AS_PATHs in JSON are in *wire order*: leftmost = most recently added AS
  (the neighbour the route was heard from), rightmost = origin.
  Example: [300, 200, 100] -> AS100 originated, AS200 passed it to AS300.
* The ASPA draft numbers the path the other way: AS(1) = origin,
  AS(N) = neighbour. core/path_builder.py does that conversion once.

Pinned specification: draft-ietf-sidrops-aspa-verification-31 (17 Nov 2026).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, FrozenSet, List, Optional, Tuple, Union

ASN = int
MAX_ASN = 4_294_967_295

ASPA_DRAFT = "draft-ietf-sidrops-aspa-verification-31"
OTC_RFC = "RFC 9234"

# One AS_PATH segment: an int for an AS_SEQUENCE member, a tuple for an AS_SET.
PathSegment = Union[int, Tuple[int, ...]]


class Verdict(str, Enum):
    """Result of one layer or of the overall decision.

    NOT_IMPLEMENTED is kept only so that an unfinished engine can never be
    mistaken for UNKNOWN ("engine ran, information is missing").
    """

    VALID = "VALID"
    INVALID = "INVALID"
    UNKNOWN = "UNKNOWN"
    NOT_IMPLEMENTED = "NOT_IMPLEMENTED"


class Relation(str, Enum):
    """What the OTHER AS is, seen from the AS we are asking about.

    Topology.relation(of=300, to=200) == Relation.PROVIDER
    reads "seen from AS300, AS200 is a provider".
    """

    PROVIDER = "provider"
    CUSTOMER = "customer"
    PEER = "peer"
    RS = "route server"          # the other AS is a route server I am a client of
    RS_CLIENT = "RS-client"      # the other AS is a client of my route server
    COMPLEX = "complex"          # hybrid relationship with no role for this prefix


class RecordStatus(str, Enum):
    """Availability of a synthetic ASPA record.

    PRESENT            -- published and (we pretend) cryptographically valid.
    MISSING            -- no object published for this customer AS.
    INVALID_SIGNATURE  -- an object exists but fails RPKI validation.
                          The draft treats it like no object at all
                          ("No Attestation"), which is NOT the same as an
                          empty provider list.
    """

    PRESENT = "present"
    MISSING = "missing"
    INVALID_SIGNATURE = "invalid_signature"


@dataclass(frozen=True)
class AspaRecord:
    """One ASPA record from the synthetic RPKI database.

    Attributes:
        customer_as: the AS that signed the record (the customer AS, CAS).
        status: PRESENT, MISSING or INVALID_SIGNATURE. Only PRESENT records
            are used for verification; the other two mean "No Attestation".
        providers: the provider ASes the customer authorises. An empty tuple
            on a PRESENT record is an AS0 record ("I have no providers").
    """
    customer_as: ASN
    status: RecordStatus
    # For PRESENT records: the provider set, AS0 removed. An empty tuple means
    # "explicitly no providers" (AS0 record). Always empty for other statuses.
    providers: Tuple[ASN, ...] = ()


@dataclass(frozen=True)
class PrefixRole:
    """Per-prefix role inside a complex relationship.
    kind "provider-customer" uses `provider`; kind "peer" leaves it None."""

    prefix: str
    kind: str
    provider: Optional[ASN] = None


@dataclass(frozen=True)
class RelationshipDecl:
    """One explicitly declared relationship.

    provider-customer : a is the provider of b
    peer              : a and b are settlement-free peers
    route-server      : a is a route server, b is its client
    complex           : hybrid relationship; prefix_roles may give a role per prefix
    """

    kind: str
    a: ASN
    b: ASN
    transparent: bool = True                    # route-server only
    prefix_roles: Tuple[PrefixRole, ...] = ()   # complex only


@dataclass(frozen=True)
class OtcInput:
    """OTC state of the route *as the exporting AS received it*, before the
    exporter's own RFC 9234 ingress processing.

    known == False -> the scenario does not say (incomplete OTC context).
    """

    known: bool
    present: bool = False
    value: Optional[ASN] = None


@dataclass(frozen=True)
class RouteInput:
    """The route as the exporting AS received it.

    Attributes:
        prefix: the announced prefix (only used for complex relationships).
        as_path_received: AS_PATH in wire order (leftmost = most recent AS).
            An AS_SET is stored as a tuple inside the path.
        learned_from: the neighbour the route came from; None if the exporter
            originates the prefix itself.
        otc: what is known about the Only-To-Customer attribute.
    """
    prefix: Optional[str]
    as_path_received: Tuple[PathSegment, ...]   # wire order, may be empty
    learned_from: Optional[ASN]                  # None = locally originated
    otc: OtcInput


@dataclass(frozen=True)
class ExportInput:
    """The proposed export being checked.

    Attributes:
        exporting_as: the AS that wants to send the route (X).
        receiving_as: the neighbour that would receive it (Y).
        prepend_count: how many times X adds its own AS number (default 1).
    """
    exporting_as: ASN
    receiving_as: ASN
    prepend_count: int = 1


@dataclass(frozen=True)
class ExportException:
    """A locally configured exception to the conventional export rules
    (e.g. a paid partial-transit agreement)."""

    learned_from: Optional[ASN]
    receiving_as: ASN
    reason: str


@dataclass(frozen=True)
class PolicyContext:
    # True: RFC 9234 Roles configured on the exporter's sessions.
    # False / None: not configured / not stated -> OTC is reported, not enforced.
    """Local policy facts that the export-policy layer needs.

    Attributes:
        bgp_roles_configured: True if RFC 9234 BGP Roles are configured on the
            exporter's sessions. False or None means OTC rules are reported
            but not enforced.
        exceptions: explicit local export exceptions (e.g. partial transit).
    """
    bgp_roles_configured: Optional[bool] = True
    exceptions: Tuple[ExportException, ...] = ()


@dataclass(frozen=True)
class Scenario:
    """A complete, validated input scenario (one JSON file).

    Built by parser.parse_scenario(); every field is already checked for type
    and consistency, so the engines can trust it. ``expected`` holds the
    hand-derived answer for test fixtures and is None for ordinary inputs.
    """
    scenario_id: str
    description: str
    review_status: str
    ases: FrozenSet[ASN]
    relationships: Tuple[RelationshipDecl, ...]
    aspa_records: Dict[ASN, AspaRecord]
    route: RouteInput
    export: ExportInput
    policy: PolicyContext
    expected: Optional[Dict[str, Any]] = None


@dataclass
class LayerResult:
    """Output of ONE verification layer. Never modified by the other layer."""

    layer: str                                   # "ASPA" or "EXPORT_POLICY"
    verdict: Verdict
    summary: str
    reasons: List[str] = field(default_factory=list)
    rule: Optional[str] = None
    spec_refs: List[str] = field(default_factory=list)
    missing_info: List[str] = field(default_factory=list)
    details: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Return this layer result as a JSON-serialisable dictionary."""
        return {
            "layer": self.layer,
            "verdict": self.verdict.value,
            "summary": self.summary,
            "reasons": self.reasons,
            "rule": self.rule,
            "spec_refs": self.spec_refs,
            "missing_info": self.missing_info,
            "details": self.details,
        }


@dataclass
class OverallResult:
    """Final result after combining the two layers.

    Attributes:
        verdict: the overall verdict.
        reason: one-sentence explanation of how it was reached.
        aspa, policy: the two layer results it was built from.
        rule_applied: the aggregation rule that produced the verdict.
        notes: extra remarks (for example data warnings).
    """
    verdict: Verdict
    reason: str
    aspa: LayerResult
    policy: LayerResult
    rule_applied: str
    notes: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        """Return the overall verdict, reason, rule and notes as a dictionary."""
        return {"verdict": self.verdict.value, "reason": self.reason,
                "rule_applied": self.rule_applied, "notes": self.notes}
