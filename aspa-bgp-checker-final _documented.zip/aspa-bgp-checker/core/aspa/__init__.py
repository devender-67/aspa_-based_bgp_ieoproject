"""Layer 1: ASPA AS_PATH verification (draft-ietf-sidrops-aspa-verification-31)."""
