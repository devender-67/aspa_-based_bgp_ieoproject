"""
core/aspa/validator.py -- LAYER 1: ASPA-based AS_PATH verification.

Point of view: the RECEIVING neighbour. Question: "if the receiver ran ASPA
on the path it is about to get, what would it conclude?"

This layer never looks at where the exporter learned the route (Layer 2).
The only relationship it uses is the receiver's view of the exporter, which
selects the algorithm (draft -31):

  exporter is receiver's customer or peer      -> upstream   (Sec. 5.5)
  exporter is receiver's RS / RS-client        -> upstream   (Sec. 5.5)
  exporter is receiver's provider              -> downstream (Sec. 5.6)
  complex, no role for this prefix             -> downstream (Sec. 6.4, "MAY ... to avoid false positives")
  relationship not declared                    -> run BOTH; same answer -> keep it,
                                                  different answers -> UNKNOWN

Procedure ASPA_VERIFY(path, algorithm, receiver_is_rs_client)
  Input : receiver-visible COMPRESSED_AS_PATH A(1..N), algorithm
  Output: VALID | INVALID | UNKNOWN, with the deciding hop
  1. If the path is empty                                   -> INVALID
  2. If most recent AS != exporter (and receiver is not an
     RS-client, upstream only)                              -> INVALID
  3. If the path contains an AS_SET                         -> INVALID
  4. Compute RAMP_BOUNDS (upstream: max_down = min_down = 0);
     if max_up + max_down < N                               -> INVALID
  5. If min_up + min_down < N                               -> UNKNOWN
  6. Otherwise                                              -> VALID
  (Step numbers match the draft's numbered steps in Sec. 5.5 / 5.6.)
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple

from core.aspa.ramp_logic import (NO_ATTESTATION, NOT_PROVIDER_PLUS, Hop, RampBounds,
                                  first_hop_with, ramp_bounds)
from core.models import (ASPA_DRAFT, ASN, AspaRecord, LayerResult, RecordStatus, Relation,
                         Scenario, Verdict)
from core.path_builder import BuiltPath
from core.topology import Topology

UP, DOWN = "upstream", "downstream"
SEC = {UP: "Sec. 5.5", DOWN: "Sec. 5.6"}


# ------------------------------------------------------------ algorithm choice

def select_algorithms(s: Scenario, topo: Topology) -> Tuple[List[str], bool, str]:
    """Returns (algorithms to run, receiver_is_rs_client, explanation)."""
    x, y = s.export.exporting_as, s.export.receiving_as
    rel = topo.relation(of=y, to=x, prefix=s.route.prefix)
    if rel in (Relation.CUSTOMER, Relation.PEER):
        return [UP], False, f"AS{y} receives from its {rel.value} AS{x} -> upstream algorithm (Sec. 5.5)"
    if rel is Relation.RS:
        return [UP], True, (f"AS{y} is an RS-client receiving from route server AS{x} "
                            "-> upstream algorithm (Sec. 5.5)")
    if rel is Relation.RS_CLIENT:
        return [UP], False, (f"route server AS{y} receives from its RS-client AS{x} "
                             "-> upstream algorithm (Sec. 5.5)")
    if rel is Relation.PROVIDER:
        return [DOWN], False, f"AS{y} receives from its provider AS{x} -> downstream algorithm (Sec. 5.6)"
    if rel is Relation.COMPLEX:
        return [DOWN], False, (f"AS{y}-AS{x} is a complex relationship with no role for this prefix "
                               "-> downstream algorithm, the Sec. 6.4 fallback that avoids false positives")
    return [UP, DOWN], False, (f"no relationship declared between AS{y} and AS{x}: "
                               "running both algorithms")


# ------------------------------------------------------------ helpers

def _rec_text(asn: ASN, db: Dict[ASN, AspaRecord]) -> str:
    """Describe an AS's record state in words (missing, failed validation or the provider list)."""
    rec = db.get(asn)
    if rec is None or rec.status is RecordStatus.MISSING:
        return f"AS{asn} has no ASPA record"
    if rec.status is RecordStatus.INVALID_SIGNATURE:
        return f"AS{asn}'s ASPA fails validation (treated as no record)"
    if not rec.providers:
        return f"AS{asn}'s ASPA declares no providers (AS0)"
    return f"AS{asn}'s ASPA lists providers {{{', '.join(f'AS{p}' for p in rec.providers)}}}"


def _hop_text(h: Hop, db: Dict[ASN, AspaRecord]) -> str:
    """Describe one authorized() hop result together with the record behind it."""
    return f"authorized(AS{h.customer}, AS{h.provider}) = {h.result}: {_rec_text(h.customer, db)}"


def describe_record(asn: ASN, db: Dict[ASN, AspaRecord]) -> Dict[str, Any]:
    """Describe the ASPA record of ``asn`` (present / missing / invalid signature) for the explanation."""
    rec = db.get(asn)
    if rec is None:
        return {"as": asn, "status": "missing", "providers": None, "note": "no record in database"}
    if rec.status is RecordStatus.PRESENT:
        return {"as": asn, "status": "present", "providers": list(rec.providers),
                "note": "explicitly no providers (AS0)" if not rec.providers else ""}
    return {"as": asn, "status": rec.status.value, "providers": None,
            "note": "treated as no attestation" if rec.status is RecordStatus.INVALID_SIGNATURE else ""}


def records_used(path: Tuple[ASN, ...], algorithms: List[str]) -> List[ASN]:
    """ASes whose records the ramp formulas consult.
    Up hops use A(1)..A(N-1); down hops (downstream only) use A(2)..A(N).
    So the upstream check never needs the exporter's own record."""
    n = len(path)
    idx = set(range(0, n - 1))
    if DOWN in algorithms:
        idx |= set(range(1, n))
    return [path[i] for i in sorted(idx)]


# ------------------------------------------------------------ one algorithm

def _run_one(alg: str, s: Scenario, built: BuiltPath, rs_client_rx: bool) -> Dict[str, Any]:
    """Runs one algorithm. Returns verdict, step, rule, reasons, ramps."""
    db = s.aspa_records
    x = s.export.exporting_as
    sec = SEC[alg]
    wire = built.receiver_visible_wire

    if not wire:                                                         # step 1
        return {"verdict": Verdict.INVALID, "step": 1, "rule": f"{sec} step 1: empty AS_PATH",
                "reasons": ["the AS_PATH is empty"]}
    most_recent = wire[0]
    exempt = alg == UP and rs_client_rx
    if not exempt and most_recent != x:                                  # step 2
        return {"verdict": Verdict.INVALID, "step": 2,
                "rule": f"{sec} step 2: most recent AS must be the neighbour",
                "reasons": [f"most recent AS {most_recent} is not the neighbour AS{x}"]}
    if built.has_as_set or built.compressed_origin_first is None:        # step 3
        return {"verdict": Verdict.INVALID, "step": 3, "rule": f"{sec} step 3: AS_SET present",
                "reasons": ["the AS_PATH contains an AS_SET; ASPA evaluates such routes as Invalid"]}

    path = built.compressed_origin_first
    rb: RampBounds = ramp_bounds(path, db)
    n = rb.n
    max_down, min_down = (0, 0) if alg == UP else (rb.max_down, rb.min_down)
    ramps = {"N": n, "max_up_ramp": rb.max_up, "min_up_ramp": rb.min_up,
             "max_down_ramp": max_down, "min_down_ramp": min_down}
    hops = [{"customer": h.customer, "provider": h.provider, "result": h.result, "dir": "up", "i": h.index}
            for h in rb.up_hops]
    if alg == DOWN:
        hops += [{"customer": h.customer, "provider": h.provider, "result": h.result, "dir": "down",
                  "j": h.index} for h in rb.down_hops]
    a = lambda k: path[k - 1]
    reasons: List[str] = []
    suspect: Optional[ASN] = None

    if rb.max_up + max_down < n:                                         # step 5 -> INVALID
        bad_up = first_hop_with(rb.up_hops, NOT_PROVIDER_PLUS)
        if alg == UP:
            assert bad_up is not None
            suspect = bad_up.provider
            reasons.append(f"hop AS{bad_up.customer} -> AS{bad_up.provider}: {_hop_text(bad_up, db)}")
            reasons.append(f"a route received from a customer or peer must climb customer->provider "
                           f"on every hop, so this hop breaks the up-ramp "
                           f"(max_up_ramp = {rb.max_up} < N = {n})")
        else:
            bad_down = first_hop_with(rb.down_hops, NOT_PROVIDER_PLUS, last=True)
            k, l = rb.max_up, n - rb.max_down + 1
            suspect = a(k + 1) if k + 1 <= n else None
            if bad_up:
                reasons.append(f"up-ramp stops at AS{a(k)}: {_hop_text(bad_up, db)}")
            if bad_down:
                reasons.append(f"down-ramp stops at AS{a(l)}: {_hop_text(bad_down, db)}")
            reasons.append(f"even with every missing record assumed favourable, the up-ramp apex AS{a(k)} "
                           f"and down-ramp apex AS{a(l)} are {l - k} hops apart; at most one sideways "
                           f"hop is allowed (max_up_ramp + max_down_ramp = {rb.max_up + rb.max_down} < N = {n})")
        if suspect is not None:
            who = "the exporting AS itself" if suspect == x else f"AS{suspect}"
            reasons.append(f"suspected leak point: {who} (it passed on a route learned from a "
                           "provider or peer); ASPA can locate, not prove, the leaker")
        return {"verdict": Verdict.INVALID, "step": 4,
                "rule": f"{sec} step 4: max_up_ramp{' + max_down_ramp' if alg == DOWN else ''} < N",
                "reasons": reasons, "ramps": ramps, "hops": hops, "suspected_leaker": suspect}

    missing_hops = [h for h in rb.up_hops + (rb.down_hops if alg == DOWN else ()) if h.result == NO_ATTESTATION]
    if rb.min_up + min_down < n:                                         # step 6 -> UNKNOWN
        for h in missing_hops:
            reasons.append(f"hop AS{h.customer} -> AS{h.provider}: {_hop_text(h, db)}")
        reasons.append(f"assuming missing records are favourable the path passes "
                       f"(max sum {rb.max_up + max_down} >= N = {n}); assuming they are not, it fails "
                       f"(min sum {rb.min_up + min_down} < N)")
        return {"verdict": Verdict.UNKNOWN, "step": 5,
                "rule": f"{sec} step 5: min_up_ramp{' + min_down_ramp' if alg == DOWN else ''} < N",
                "reasons": reasons, "ramps": ramps, "hops": hops}

    if alg == UP:                                                        # step 7 -> VALID
        reasons.append("every hop is customer->provider and attested (Provider+), "
                       "so the path is a pure up-ramp")
    else:
        reasons.append(f"up-ramp AS{a(1)}..AS{a(rb.min_up)} and down-ramp AS{a(n - rb.min_down + 1)}..AS{a(n)} "
                       f"together cover the path (min_up + min_down = {rb.min_up + rb.min_down} >= N = {n})")
    for h in missing_hops:
        reasons.append(f"note: {_hop_text(h, db)}, but this record cannot change the result")
    return {"verdict": Verdict.VALID, "step": 6, "rule": f"{sec} step 6: ramps cover the path",
            "reasons": reasons, "ramps": ramps, "hops": hops}


# ------------------------------------------------------------ layer entry point

def verify_aspa(s: Scenario, built: BuiltPath, topo: Topology) -> LayerResult:
    """LAYER 1: verify the receiver-visible AS_PATH with ASPA.

    Chooses the upstream or downstream procedure from the receiver's view of
    the exporter (both if the relationship is undeclared or complex), runs it
    and explains the deciding hop, rule and draft section.

    Args:
        s: the scenario.
        built: the receiver-visible path from build_receiver_path().
        topo: the declared topology.

    Returns:
        A LayerResult with verdict VALID, INVALID or UNKNOWN, the reasons,
        the records examined, the missing records and the suspected leaker.
    """
    algorithms, rs_client_rx, why = select_algorithms(s, topo)
    runs = {alg: _run_one(alg, s, built, rs_client_rx) for alg in algorithms}

    details: Dict[str, Any] = {"algorithms": algorithms, "algorithm_reason": why,
                               "exporter": s.export.exporting_as,
                               "runs": {k: {**v, "verdict": v["verdict"].value} for k, v in runs.items()}}
    missing: List[str] = []
    if built.compressed_origin_first is not None:
        path = built.compressed_origin_first
        details["compressed_path_origin_first"] = [f"AS{a}" for a in path]
        examined = [describe_record(a, s.aspa_records) for a in records_used(path, algorithms)]
        details["records_examined"] = examined
        missing = [f"ASPA record for AS{r['as']} ({r['status']})" for r in examined if r["status"] != "present"]
    else:
        details["records_examined"] = []

    refs = [f"{ASPA_DRAFT} {SEC[a]}" for a in algorithms] + [f"{ASPA_DRAFT} Sec. 5.3-5.4"]
    if len(algorithms) == 1:
        r = runs[algorithms[0]]
        return LayerResult("ASPA", r["verdict"], f"{algorithms[0]} verification: {r['verdict'].value}",
                           [why] + r["reasons"], r["rule"], refs, missing, details)

    # Relationship undeclared: both algorithms were run (project decision Q3).
    up, down = runs[UP]["verdict"], runs[DOWN]["verdict"]
    missing.insert(0, f"relationship between AS{s.export.receiving_as} and AS{s.export.exporting_as}")
    if up is down:
        verdict = up
        summary = f"both algorithms give {up.value}, so the missing relationship does not matter"
    else:
        verdict = Verdict.UNKNOWN
        summary = (f"relationship-dependent: upstream gives {up.value} (if AS{s.export.exporting_as} is "
                   f"AS{s.export.receiving_as}'s customer or peer), downstream gives {down.value} "
                   f"(if it is AS{s.export.receiving_as}'s provider)")
    reasons = [why, summary] + [f"[upstream] {t}" for t in runs[UP]["reasons"]] + \
              [f"[downstream] {t}" for t in runs[DOWN]["reasons"]]
    return LayerResult("ASPA", verdict, summary, reasons,
                       "project rule Q3: run both algorithms when the relationship is undeclared",
                       refs, missing, details)


# ------------------------------------------------------------ lightweight entry point

def verdict_for_route(wire: Tuple[ASN, ...], sender: ASN, receiver: ASN,
                      receiver_view_of_sender: Optional[Relation],
                      db: Dict[ASN, AspaRecord]) -> Verdict:
    """ASPA verdict of one received route, without building a full Scenario.
    Used by the change planner, which checks thousands of routes.
    `wire` is the path exactly as the receiver gets it (sender first)."""
    from types import SimpleNamespace
    from core.path_builder import compress

    if receiver_view_of_sender in (Relation.CUSTOMER, Relation.PEER, Relation.RS, Relation.RS_CLIENT):
        algs = [UP]
    elif receiver_view_of_sender in (Relation.PROVIDER, Relation.COMPLEX):
        algs = [DOWN]
    else:
        algs = [UP, DOWN]
    built = BuiltPath(received_wire=wire[1:], receiver_visible_wire=wire, has_as_set=False,
                      compressed_origin_first=compress(tuple(reversed(wire))),
                      exporter_prepended=True, receiver_loop=receiver in wire)
    shim = SimpleNamespace(aspa_records=db, export=SimpleNamespace(exporting_as=sender))
    rs_client_rx = receiver_view_of_sender is Relation.RS
    results = {_run_one(a, shim, built, rs_client_rx)["verdict"] for a in algs}  # type: ignore[arg-type]
    return results.pop() if len(results) == 1 else Verdict.UNKNOWN
