"""
core/aspa/ramp_logic.py -- provider authorization function and ramp bounds.

Pinned: draft-ietf-sidrops-aspa-verification-31, Sections 5.3 and 5.4.

Vocabulary
----------
* up-ramp   : the part of the path, starting at the origin AS(1), where every
              hop goes customer -> provider (AS(i) -> AS(i+1)).
* down-ramp : the part, starting at the neighbour AS(N) and read backwards,
              where every hop AS(j) -> AS(j-1) is customer -> provider.
              Read forwards it goes provider -> customer ("downhill").
* A leak-free path is: climb up, at most ONE sideways (peer) hop at the top,
  then go down. So up-ramp + down-ramp must cover the whole path:
  up + down >= N.

Procedure AUTHORIZED(x, y)                                       [Sec. 5.3]
  Input : customer AS x, candidate provider AS y, ASPA database
  Output: "Provider+" | "Not Provider+" | "No Attestation"
  1. If x has no valid ASPA (missing or bad signature) -> "No Attestation"
  2. If y is in x's provider set (U-SPAS)              -> "Provider+"
  3. Otherwise                                          -> "Not Provider+"

Procedure RAMP_BOUNDS(A(1..N))                                   [Sec. 5.4]
  1. max_up_ramp   = smallest I with AUTHORIZED(A(I),A(I+1)) = Not Provider+, else N
  2. min_up_ramp   = smallest I with AUTHORIZED(A(I),A(I+1)) != Provider+,    else N
  3. max_down_ramp = N-J+1, J = largest index with AUTHORIZED(A(J),A(J-1)) = Not Provider+, else N
  4. min_down_ramp = N-J+1, J = largest index with AUTHORIZED(A(J),A(J-1)) != Provider+,    else N

"max" bounds give every missing record the benefit of the doubt;
"min" bounds assume the worst about every missing record.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

from core.models import ASN, AspaRecord, RecordStatus

PROVIDER_PLUS = "Provider+"
NOT_PROVIDER_PLUS = "Not Provider+"
NO_ATTESTATION = "No Attestation"


def authorized(x: ASN, y: ASN, db: Dict[ASN, AspaRecord]) -> str:
    """Sec. 5.3. The synthetic DB holds at most one record per AS, so U-SPAS
    is simply that record's provider set (AS0 already removed by the parser)."""
    rec = db.get(x)
    if rec is None or rec.status is not RecordStatus.PRESENT:
        return NO_ATTESTATION
    return PROVIDER_PLUS if y in rec.providers else NOT_PROVIDER_PLUS


@dataclass(frozen=True)
class Hop:
    """One AUTHORIZED() call: is `provider` an attested provider of `customer`?"""

    customer: ASN
    provider: ASN
    result: str
    index: int           # the I (up hops) or J (down hops) of the draft, 1-based


@dataclass(frozen=True)
class RampBounds:
    """Up-ramp and down-ramp bounds of a path (draft-31 Sec. 5.4).

    Attributes:
        n: number of ASes in the compressed path.
        max_up, min_up: longest possible up-ramp when missing records are
            assumed favourable / unfavourable.
        max_down, min_down: the same for the down-ramp.
        up_hops, down_hops: the authorized() result of every hop, kept so the
            explanation can name the hop that decided the verdict.
    """
    n: int
    max_up: int
    min_up: int
    max_down: int
    min_down: int
    up_hops: Tuple[Hop, ...]      # AUTHORIZED(A(i), A(i+1)), i = 1..N-1
    down_hops: Tuple[Hop, ...]    # AUTHORIZED(A(j), A(j-1)), j = 2..N


def ramp_bounds(path: Tuple[ASN, ...], db: Dict[ASN, AspaRecord]) -> RampBounds:
    """`path` is origin-first and compressed: path[0] = A(1)."""
    n = len(path)
    a = lambda k: path[k - 1]                                   # 1-based access, as in the draft
    up = tuple(Hop(a(i), a(i + 1), authorized(a(i), a(i + 1), db), i) for i in range(1, n))
    down = tuple(Hop(a(j), a(j - 1), authorized(a(j), a(j - 1), db), j) for j in range(2, n + 1))

    def first_up(results: Tuple[str, ...]) -> int:
        """Return the index of the first up-hop whose result is in ``results`` (n if none)."""
        hits = [h.index for h in up if h.result in results]
        return min(hits) if hits else n

    def last_down(results: Tuple[str, ...]) -> int:
        """Return the down-ramp length implied by the last down-hop whose result is in ``results``."""
        hits = [h.index for h in down if h.result in results]
        return n - max(hits) + 1 if hits else n

    return RampBounds(
        n=n,
        max_up=first_up((NOT_PROVIDER_PLUS,)),
        min_up=first_up((NOT_PROVIDER_PLUS, NO_ATTESTATION)),
        max_down=last_down((NOT_PROVIDER_PLUS,)),
        min_down=last_down((NOT_PROVIDER_PLUS, NO_ATTESTATION)),
        up_hops=up,
        down_hops=down,
    )


def first_hop_with(hops: Tuple[Hop, ...], result: str, last: bool = False) -> Optional[Hop]:
    """Return the first hop with the given authorized() result.

    Args:
        hops: the hops to search.
        result: PROVIDER_PLUS, NOT_PROVIDER_PLUS or NO_ATTESTATION.
        last: if True, return the last matching hop instead of the first.

    Returns:
        The matching Hop, or None.
    """
    hits: List[Hop] = [h for h in hops if h.result == result]
    if not hits:
        return None
    return hits[-1] if last else hits[0]
