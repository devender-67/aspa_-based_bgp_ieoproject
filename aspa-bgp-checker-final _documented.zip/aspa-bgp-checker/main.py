"""
main.py -- command-line entry point.

Usage:
    python3 main.py --input examples/valid.json
    python3 main.py --input examples/valid.json --json
    python3 main.py --input tests/fixtures/ --summary      # every file in a folder, one line each
    python3 main.py --input examples/changes/transit_to_peering.json --plan

Exit codes: 0 = checked (any verdict), 2 = malformed input.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from core.aggregation import aggregate
from core.aspa.validator import verify_aspa
from core.explanation import render_json, render_text
from core.models import OverallResult, Scenario
from core.parser import InputError, load_scenario
from core.path_builder import BuiltPath, build_receiver_path
from core.policy.export_policy import verify_export_policy
from core.topology import Topology
from core.unknown_resolver import resolve_unknowns


def check(scenario: Scenario) -> Tuple[Topology, BuiltPath, OverallResult, Dict[str, Any]]:
    """Full pipeline for one scenario. Used by the CLI, the tests and (later) FastAPI."""
    topo = Topology(scenario.ases, scenario.relationships)
    built = build_receiver_path(scenario, topo)

    # The two layers run independently: neither sees the other's result.
    aspa_result = verify_aspa(scenario, built, topo)
    policy_result = verify_export_policy(scenario, topo)

    notes = [w for w in built.warnings if "loop detection" in w]
    overall = aggregate(aspa_result, policy_result, notes=notes)
    uncertainty = resolve_unknowns(scenario, {"aspa": aspa_result.verdict,
                                              "policy": policy_result.verdict,
                                              "overall": overall.verdict})
    return topo, built, overall, uncertainty


def run(path: str, as_json: bool, colour: bool) -> int:
    """Check one scenario file and print the report.

    Args:
        path: the scenario JSON file.
        as_json: print JSON instead of the text report.
        colour: use terminal colours in the text report.

    Returns:
        The process exit code (0).
    """
    scenario = load_scenario(path)
    topo, built, overall, uncertainty = check(scenario)
    if as_json:
        print(json.dumps(render_json(scenario, built, topo, overall, uncertainty), indent=2))
    else:
        print(render_text(scenario, built, topo, overall, uncertainty, colour=colour))
    return 0


def summary(folder: str) -> int:
    """Check every scenario in a folder and print one line per scenario.

    For fixtures, the expected overall verdict is printed next to the result
    so that differences are easy to spot.

    Returns:
        The process exit code (0).
    """
    files = sorted(Path(folder).glob("*.json"))
    print(f"{'scenario':<22} {'ASPA':<9} {'POLICY':<9} {'OVERALL':<9} {'class':<15} expected")
    for f in files:
        try:
            s = load_scenario(str(f))
        except InputError as exc:
            print(f"{f.stem:<22} INPUT ERROR: {exc}")
            continue
        _, _, o, u = check(s)
        cls = next(iter(u.get("classification", {}).values()), {}).get("class", "")
        exp = s.expected or {}
        ok = all(exp.get(k) in (None, v) for k, v in
                 (("aspa", o.aspa.verdict.value), ("export_policy", o.policy.verdict.value),
                  ("overall", o.verdict.value)))
        print(f"{s.scenario_id:<22} {o.aspa.verdict.value:<9} {o.policy.verdict.value:<9} "
              f"{o.verdict.value:<9} {cls:<15} {'ok' if ok else 'MISMATCH'}")
    return 0


def main(argv: Optional[List[str]] = None) -> int:
    """Command-line entry point.

    Flags: --input (file or folder), --json, --no-color, --summary, --plan.

    Returns:
        0 on success, 2 if the input is malformed (InputError).
    """
    ap = argparse.ArgumentParser(description="Offline ASPA-based BGP export checker")
    ap.add_argument("--input", required=True, help="scenario JSON file (or a folder with --summary)")
    ap.add_argument("--json", action="store_true", help="print machine-readable JSON")
    ap.add_argument("--no-color", action="store_true", help="disable coloured output")
    ap.add_argument("--summary", action="store_true", help="one line per scenario in a folder")
    ap.add_argument("--plan", action="store_true", help="input is an ASPA change scenario: plan it")
    args = ap.parse_args(argv)
    try:
        if args.summary:
            return summary(args.input)
        if args.plan:
            from core.planner.loader import load_change
            from core.planner.plan import plan_change
            from core.planner.report import render_plan
            result = plan_change(load_change(args.input))
            print(json.dumps(result, indent=2, default=str) if args.json else render_plan(result))
            return 0
        return run(args.input, args.json, not args.no_color)
    except InputError as exc:
        print(f"INPUT ERROR: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
