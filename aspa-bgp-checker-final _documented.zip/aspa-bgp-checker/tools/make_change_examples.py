"""tools/make_change_examples.py -- generate the example change scenarios.

Writes six ASPA change scenarios to examples/changes/ for the change planner
(python3 main.py --input examples/changes/<name>.json --plan).

All six share one small base network:

    AS100 ==peer== AS101        (tier-1 ASes, AS0 records)
      |              |
    AS200          AS250        (transit providers)
      |              |
    AS400          AS410        (other customers)

and differ in how the stub AS300 (and in one case AS310) changes providers.

Usage:
    python3 tools/make_change_examples.py
"""
import json
from typing import Any, Dict, List, Optional


def pc(p: int, c: int) -> Dict[str, Any]:
    """Provider-customer link: AS``p`` is the provider of AS``c``."""
    return {"type": "provider-customer", "provider": p, "customer": c}


def peer(a: int, b: int) -> Dict[str, Any]:
    """Peer link between AS``a`` and AS``b``."""
    return {"type": "peer", "ases": [a, b]}


def rec(a: int, p: Optional[List[int]] = None, s: str = "present") -> Dict[str, Any]:
    """ASPA record of AS``a`` with providers ``p`` (empty list = AS0 record)."""
    r: Dict[str, Any] = {"customer_as": a, "status": s}
    if s == "present":
        r["providers"] = p or []
    return r


# Links and records shared by every example.
BASE = [peer(100, 101), pc(100, 200), pc(101, 250), pc(200, 400), pc(250, 410)]
BREC = [rec(100, []), rec(101, []), rec(200, [100]), rec(250, [101]), rec(400, [200]), rec(410, [250])]


def ch(cid: str, desc: str, before: List[Dict[str, Any]], after: List[Dict[str, Any]],
       rb: List[Dict[str, Any]], ra: List[Dict[str, Any]], delta: int = 60) -> Dict[str, Any]:
    """Build one change scenario.

    Args:
        cid, desc: identifier and description.
        before, after: links added to the base network before / after the change.
        rb, ra: ASPA records added to the base records before / after the change.
        delta: validator lag bound in minutes (BGP convergence is 5 minutes).
    """
    return {"schema_version": "0.1", "kind": "aspa-change", "change_id": cid, "description": desc,
            "topology_before": {"relationships": BASE + before}, "topology_after": {"relationships": BASE + after},
            "aspa_before": BREC + rb, "aspa_after": BREC + ra,
            "parameters": {"delta_minutes": delta, "bgp_convergence_minutes": 5}}


S: Dict[str, Dict[str, Any]] = {}
S["provider_switch"] = ch("CH1-provider-switch", "AS300 moves its transit from AS200 to AS250.",
                          [pc(200, 300)], [pc(250, 300)], [rec(300, [200])], [rec(300, [250])])
S["add_backup"] = ch("CH2-add-backup", "AS300 adds AS250 as a second (backup) provider.",
                     [pc(200, 300)], [pc(200, 300), pc(250, 300)], [rec(300, [200])], [rec(300, [200, 250])])
S["transit_to_peering"] = ch("CH3-transit-to-peering",
                             "AS300 stops buying transit from AS200 and peers with it instead; AS250 becomes its provider.",
                             [pc(200, 300)], [peer(200, 300), pc(250, 300)], [rec(300, [200])], [rec(300, [250])])
S["first_publication"] = ch("CH4-first-publication",
                            "AS300 has no ASPA yet; it switches from AS200 to AS250 and publishes its first ASPA = {AS250}.",
                            [pc(200, 300)], [pc(250, 300)], [], [rec(300, [250])])
S["two_customers"] = ch("CH5-two-customers", "AS300 and AS310 both move from AS200 to AS250 in one maintenance window.",
                        [pc(200, 300), pc(200, 310)], [pc(250, 300), pc(250, 310)],
                        [rec(300, [200]), rec(310, [200])], [rec(300, [250]), rec(310, [250])])
S["broken_target"] = ch("CH6-broken-target", "AS300 adds backup AS250 but its new ASPA forgets AS250.",
                        [pc(200, 300)], [pc(200, 300), pc(250, 300)], [rec(300, [200])], [rec(300, [200])])

if __name__ == "__main__":
    for k, v in S.items():
        with open(f"examples/changes/{k}.json", "w") as fh:
            json.dump(v, fh, indent=2)
    print(f"wrote {len(S)} change scenarios to examples/changes/")
