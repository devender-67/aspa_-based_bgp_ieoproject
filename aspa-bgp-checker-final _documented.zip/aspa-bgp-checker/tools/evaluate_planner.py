"""
tools/evaluate_planner.py -- experiment: naive vs make-before-break vs searched plans.

Generates random Internet-like synthetic topologies, applies random ASPA-related
changes (provider switch, backup provider, transit->peering, first publication,
two customers moving together, de-multihoming), and plans each change three ways.

Usage:
    python3 tools/evaluate_planner.py --runs 120 --seed 1 --out results/planner_eval.csv

Outputs a CSV (one row per scenario and plan) and prints a summary table.
"""

from __future__ import annotations

import argparse
import csv
import random
import statistics
import sys
import time
from pathlib import Path
from typing import Dict, List, Tuple

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from core.models import AspaRecord, RecordStatus, RelationshipDecl  # noqa: E402
from core.planner.plan import ChangeProblem, plan_change  # noqa: E402

KINDS = ["provider_switch", "add_backup", "transit_to_peering", "first_publication",
         "two_customers", "drop_provider"]


def gen_topology(rng: random.Random, n_t1: int = 3, n_t2: int = 6, n_stub: int = 10
                 ) -> Tuple[List[int], List[int], List[int], set]:
    """Generate a random tiered topology: 3 tier-1 ASes (peering), 6 tier-2 and 10 stub ASes."""
    t1 = [100 + i for i in range(n_t1)]
    t2 = [200 + i for i in range(n_t2)]
    stubs = [300 + i for i in range(n_stub)]
    links = set()
    for a in t1:                                    # Tier-1 full mesh of peers
        for b in t1:
            if a < b:
                links.add(RelationshipDecl("peer", a, b))
    for x in t2:                                    # each Tier-2 buys from 1-2 Tier-1s
        for p in rng.sample(t1, rng.choice([1, 2])):
            links.add(RelationshipDecl("provider-customer", p, x))
    for i, a in enumerate(t2):                      # some Tier-2 peering
        for b in t2[i + 1:]:
            if rng.random() < 0.2:
                links.add(RelationshipDecl("peer", a, b))
    for s in stubs:                                 # stubs buy from 1-2 Tier-2s
        for p in rng.sample(t2, rng.choice([1, 1, 2])):
            links.add(RelationshipDecl("provider-customer", p, s))
    return t1, t2, stubs, links


def providers(links: set, asn: int) -> List[int]:
    """Return the providers of ``asn`` in a link set."""
    return sorted(d.a for d in links if d.kind == "provider-customer" and d.b == asn)


def records_for(links: set, ases: List[int], adopt: float, rng: random.Random,
                force: Tuple[int, ...] = ()) -> Dict[int, AspaRecord]:
    """Correct ASPA records for a random subset of ASes (Tier-1s publish AS0)."""
    db = {}
    for a in ases:
        if a in force or rng.random() < adopt:
            db[a] = AspaRecord(a, RecordStatus.PRESENT, tuple(providers(links, a)))
    return db


def gen_change(rng: random.Random, kind: str, adopt: float) -> ChangeProblem:
    """Generate one random change of the given kind on a fresh topology.

    ``adopt`` is the share of ASes that publish ASPA records.
    """
    t1, t2, stubs, links = gen_topology(rng)
    ases = t1 + t2 + stubs
    c = rng.choice(stubs)
    before, after = set(links), set(links)
    old_p = providers(links, c)
    others = [x for x in t2 if x not in old_p]
    movers = [c]
    if kind == "provider_switch":
        o, n = rng.choice(old_p), rng.choice(others)
        after.discard(RelationshipDecl("provider-customer", o, c))
        after.add(RelationshipDecl("provider-customer", n, c))
    elif kind == "add_backup":
        after.add(RelationshipDecl("provider-customer", rng.choice(others), c))
    elif kind == "transit_to_peering":
        o, n = rng.choice(old_p), rng.choice(others)
        after.discard(RelationshipDecl("provider-customer", o, c))
        after.add(RelationshipDecl("peer", o, c))
        after.add(RelationshipDecl("provider-customer", n, c))
    elif kind == "first_publication":
        o, n = rng.choice(old_p), rng.choice(others)
        after.discard(RelationshipDecl("provider-customer", o, c))
        after.add(RelationshipDecl("provider-customer", n, c))
    elif kind == "two_customers":
        o = rng.choice(t2)
        custs = [s for s in stubs if o in providers(links, s)]
        if len(custs) < 2:
            custs = rng.sample(stubs, 2)
            for s in custs:
                before.add(RelationshipDecl("provider-customer", o, s))
                after.add(RelationshipDecl("provider-customer", o, s))
        movers = custs[:2]
        n = rng.choice([x for x in t2 if x != o])
        for s in movers:
            after.discard(RelationshipDecl("provider-customer", o, s))
            after.add(RelationshipDecl("provider-customer", n, s))
    elif kind == "drop_provider":
        if len(old_p) < 2:
            extra = rng.choice(others)
            before.add(RelationshipDecl("provider-customer", extra, c))
            after.add(RelationshipDecl("provider-customer", extra, c))
            old_p = providers(before, c)
        after.discard(RelationshipDecl("provider-customer", rng.choice(old_p), c))

    force = tuple(movers) if kind != "first_publication" else ()
    rb = records_for(before, ases, adopt, random.Random(rng.random()), force)
    if kind == "first_publication":
        rb.pop(c, None)
    ra = {a: r for a, r in rb.items() if a not in movers}
    for m in movers:
        ra[m] = AspaRecord(m, RecordStatus.PRESENT, tuple(providers(after, m)))
    return ChangeProblem(f"{kind}-{c}", kind, frozenset(before), frozenset(after), rb, ra,
                         delta=60.0, beta=5.0)


def main() -> None:
    """Run the experiment and write one CSV row per scenario, plus a printed summary."""
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", type=int, default=120)
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--adopt", type=float, default=0.5, help="share of ASes publishing ASPA")
    ap.add_argument("--out", default="results/planner_eval.csv")
    args = ap.parse_args()
    rng = random.Random(args.seed)
    rows = []
    t0 = time.time()
    for i in range(args.runs):
        kind = KINDS[i % len(KINDS)]
        p = gen_change(rng, kind, args.adopt)
        t = time.time()
        r = plan_change(p)
        dt = time.time() - t
        for pl in r["plans"]:
            rows.append({"run": i, "kind": kind, "plan": pl["name"].split(" ")[0], "safe": pl["safe"],
                         "minutes": pl["minutes"], "exposure": pl["exposure_route_minutes"],
                         "routes_at_risk": pl["routes_at_risk"], "outage": pl["outage_route_minutes"],
                         "target_safe": r["target_safe"], "seconds": round(dt, 3)})
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    with open(args.out, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)

    print(f"{args.runs} scenarios, adoption {args.adopt:.0%}, {time.time() - t0:.0f}s total\n")
    print(f"{'change kind':<20} {'plan':<18} {'unsafe %':>8} {'routes at risk':>15} "
          f"{'minutes':>8} {'exposure':>9}")
    for kind in KINDS:
        for plan in ("naive", "make-before-break", "best"):
            sel = [r for r in rows if r["kind"] == kind and r["plan"] == plan]
            if not sel:
                continue
            unsafe = 100 * sum(not r["safe"] for r in sel) / len(sel)
            print(f"{kind:<20} {plan:<18} {unsafe:>7.0f}% {statistics.mean(r['routes_at_risk'] for r in sel):>15.1f} "
                  f"{statistics.mean(r['minutes'] for r in sel):>8.0f} {statistics.mean(r['exposure'] for r in sel):>9.0f}")
    print("\nAll kinds:")
    for plan in ("naive", "make-before-break", "best"):
        sel = [r for r in rows if r["plan"] == plan]
        print(f"  {plan:<18} unsafe {100 * sum(not r['safe'] for r in sel) / len(sel):5.1f}%  "
              f"mean exposure {statistics.mean(r['exposure'] for r in sel):6.1f} route-min  "
              f"mean duration {statistics.mean(r['minutes'] for r in sel):5.0f} min  (n={len(sel)})")
    secs = [r["seconds"] for r in rows if r["plan"] == "naive"]
    print(f"\nplanning time per scenario: median {statistics.median(secs):.2f}s, max {max(secs):.2f}s")


if __name__ == "__main__":
    main()
