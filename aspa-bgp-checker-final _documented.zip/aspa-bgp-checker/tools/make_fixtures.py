"""
tools/make_fixtures.py -- regenerate tests/fixtures/*.json.

Every expected value below was derived BY HAND from draft-ietf-sidrops-aspa-
verification-31 (Sec. 5.3-5.6) and RFC 9234 (Sec. 3.1, 5), not copied from
the program's output. All fixtures are "proposed" until reviewed by a mentor.

Run:  python3 tools/make_fixtures.py
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Optional

OUT = Path(__file__).resolve().parent.parent / "tests" / "fixtures"
P = "192.0.2.0/24"


def pc(p: int, c: int) -> Dict[str, Any]:
    """Provider-customer relationship declaration."""
    return {"type": "provider-customer", "provider": p, "customer": c}


def peer(a: int, b: int) -> Dict[str, Any]:
    """Peer relationship declaration."""
    return {"type": "peer", "ases": [a, b]}


def rs(r: int, c: int, transparent: bool = True) -> Dict[str, Any]:
    """Route-server relationship declaration."""
    return {"type": "route-server", "rs": r, "client": c, "transparent": transparent}


def rec(a: int, provs: Optional[List[int]] = None, status: str = "present") -> Dict[str, Any]:
    """ASPA record (present with providers, missing, or invalid_signature)."""
    r: Dict[str, Any] = {"customer_as": a, "status": status}
    if status == "present":
        r["providers"] = provs or []
    return r


def sc(sid: str, desc: str, rels: List[Dict[str, Any]], recs: List[Dict[str, Any]],
       path: List[Any], lf: Optional[int], x: int, y: int, expected: Dict[str, Any],
       otc: Any = {"present": False}, prepend: int = 1, roles: Optional[bool] = True,
       extra_ases: List[int] = (), exceptions: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
    """Build one complete fixture scenario with its hand-derived expected result."""
    ases = set(extra_ases) | {x, y} | ({lf} if lf else set())
    for r in rels:
        ases |= {r.get("provider"), r.get("customer"), r.get("rs"), r.get("client"), *r.get("ases", [])}
    ases.discard(None)
    pol: Dict[str, Any] = {"bgp_roles_configured": roles}
    if exceptions:
        pol["export_exceptions"] = exceptions
    return {"schema_version": "0.1", "scenario_id": sid, "description": desc,
            "review_status": "proposed",
            "standards": {"aspa": "draft-ietf-sidrops-aspa-verification-31", "otc": "RFC 9234"},
            "topology": {"ases": sorted(ases), "relationships": rels},
            "aspa_records": recs,
            "route": {"prefix": P, "as_path_received": path, "learned_from": lf, "otc": otc},
            "export": {"exporting_as": x, "receiving_as": y, "prepend_count": prepend},
            "policy_context": pol, "expected": expected}


def E(aspa: str, pol: str, overall: str, why: str, spec: str, missing: List[str] = (),
      **more: Any) -> Dict[str, Any]:
    """Expected result: layer verdicts, overall verdict, reasoning, spec section and extras."""
    d = {"aspa": aspa, "export_policy": pol, "overall": overall, "explanation": why,
         "spec": spec, "missing": list(missing)}
    d.update(more)
    return d


F: List[Dict[str, Any]] = []
CHAIN = [pc(100, 200), pc(200, 300), pc(300, 400)]
CHAIN_RECS = [rec(400, [300]), rec(300, [200]), rec(200, [100]), rec(100, [])]

# ---------------------------------------------------------------- ASPA layer
F.append(sc("A01-valid-path", "Customer route climbs AS400->AS300->AS200 and is sent to provider AS100.",
            CHAIN, CHAIN_RECS, [300, 400], 300, 200, 100,
            E("VALID", "VALID", "VALID", "Upstream: every hop Provider+ (AS400 lists AS300, AS300 lists AS200).",
              "draft-31 Sec. 5.5")))

F.append(sc("A02-invalid-authorization", "AS300 leaked a route from its provider AS400 to its provider AS200.",
            [pc(100, 200), pc(200, 300), pc(400, 300)],
            [rec(400, []), rec(300, [200, 400]), rec(200, [100])], [300, 400], 300, 200, 100,
            E("INVALID", "VALID", "INVALID",
              "authorized(AS400, AS300) = Not Provider+ (AS400 declares no providers): max_up_ramp 1 < N 3. "
              "Suspected leak point AS300. AS200's own export (customer->provider) is allowed.",
              "draft-31 Sec. 5.5 step 4", suspected_leaker=300)))

F.append(sc("A03-missing-record", "As A01 but the origin AS400 published no ASPA.",
            CHAIN, [rec(400, status="missing")] + CHAIN_RECS[1:], [300, 400], 300, 200, 100,
            E("UNKNOWN", "VALID", "UNKNOWN", "authorized(AS400, AS300) = No Attestation: min_up 1 < 3 <= max_up.",
              "draft-31 Sec. 5.5 step 5", ["ASPA record for AS400"],
              any_record={"best": "VALID", "worst": "INVALID"}, consistent={"best": "VALID", "worst": "VALID"},
              classification="LATENT-VALID", settling=[["ASPA:AS400"]])))

F.append(sc("A04-multiple-missing", "As A01 but AS400 and AS300 both published no ASPA.",
            CHAIN, [rec(400, status="missing"), rec(300, status="missing")] + CHAIN_RECS[2:],
            [300, 400], 300, 200, 100,
            E("UNKNOWN", "VALID", "UNKNOWN", "Two No Attestation hops; VALID only if both records list the next AS.",
              "draft-31 Sec. 5.5 step 5", ["ASPA record for AS400", "ASPA record for AS300"],
              any_record={"best": "VALID", "worst": "INVALID"}, consistent={"best": "VALID", "worst": "VALID"},
              classification="LATENT-VALID", settling=[["ASPA:AS300", "ASPA:AS400"]],
              influence={"ASPA:AS300": 0.5, "ASPA:AS400": 0.5})))

F.append(sc("A05-empty-provider-list", "Tier-1 AS100 (no providers, AS0 record) -> customer AS300 -> leaked to provider AS200.",
            [pc(50, 200), pc(200, 300), pc(100, 300)],
            [rec(100, []), rec(300, [100, 200]), rec(200, [50])], [300, 100], 300, 200, 50,
            E("INVALID", "VALID", "INVALID",
              "AS100's explicit empty provider list makes authorized(AS100, AS300) = Not Provider+. "
              "If AS100 had NO record it would be UNKNOWN instead: empty != missing.",
              "draft-31 Sec. 5.3, 5.5 step 4", suspected_leaker=300)))

F.append(sc("A06-prepends-long-upramp", "Origin prepends 3x, exporter prepends 2x; 4-hop pure up-ramp.",
            [pc(100, 200), pc(200, 300), pc(300, 400), pc(400, 500)],
            [rec(500, [400]), rec(400, [300]), rec(300, [200]), rec(200, [100])],
            [300, 400, 500, 500, 500], 300, 200, 100,
            E("VALID", "VALID", "VALID", "Prepends collapse to AS500,AS400,AS300,AS200; every hop Provider+.",
              "draft-31 Sec. 5 (COMPRESSED_AS_PATH), 5.5"), prepend=2))

DOWN_RELS = [pc(300, 400), pc(200, 300), pc(100, 200), peer(200, 210), pc(210, 220), pc(220, 230)]
DOWN_RECS = [rec(400, [300]), rec(300, [200]), rec(200, [100]), rec(210, []), rec(220, [210])]
F.append(sc("A07-valid-downramp", "Up AS400->AS300->AS200, across peer AS210, down AS220 -> customer AS230.",
            DOWN_RELS, DOWN_RECS, [210, 200, 300, 400], 210, 220, 230,
            E("VALID", "VALID", "VALID",
              "Downstream: max_up=min_up=3, max_down=min_down=2, sum 5 >= N 5. OTC=200 (set by AS200 toward its "
              "peer) may go to a customer.", "draft-31 Sec. 5.6; RFC 9234 Sec. 5"),
            otc={"present": True, "value": 200}))

F.append(sc("A08-invalid-valley", "Two sideways hops: AS200 -> peer AS210 -> peer AS215 -> down to AS220 -> AS230.",
            [pc(300, 400), pc(200, 300), pc(100, 200), peer(200, 210), peer(210, 215), pc(215, 220), pc(220, 230)],
            [rec(400, [300]), rec(300, [200]), rec(200, [100]), rec(210, []), rec(215, []), rec(220, [215])],
            [215, 210, 200, 300, 400], 215, 220, 230,
            E("INVALID", "VALID", "INVALID",
              "max_up 3 + max_down 2 = 5 < N 6: apexes AS200 and AS215 are 2 hops apart. Suspected leak point "
              "AS210 (sent a peer route to a peer). AS220's own export is fine.",
              "draft-31 Sec. 5.6 step 4", suspected_leaker=210),
            otc={"present": True, "value": 200}))

F.append(sc("A09-unknown-ramp", "As A07 but AS300 published no ASPA.",
            DOWN_RELS, [DOWN_RECS[0], rec(300, status="missing")] + DOWN_RECS[2:],
            [210, 200, 300, 400], 210, 220, 230,
            E("UNKNOWN", "VALID", "UNKNOWN", "min_up 2 + min_down 2 = 4 < 5 <= max sum 5.",
              "draft-31 Sec. 5.6 step 5", ["ASPA record for AS300"],
              any_record={"best": "VALID", "worst": "INVALID"}, consistent={"best": "VALID", "worst": "VALID"},
              classification="LATENT-VALID", settling=[["ASPA:AS300"]]),
            otc={"present": True, "value": 200}))

F.append(sc("A10-missing-but-irrelevant", "As A07 but the apex peer AS210 published no ASPA.",
            DOWN_RELS, DOWN_RECS[:3] + [rec(210, status="missing"), DOWN_RECS[4]],
            [210, 200, 300, 400], 210, 220, 230,
            E("VALID", "VALID", "VALID",
              "AS210's record is missing but even the min bounds cover the path (3 + 2 = 5): missing != Unknown.",
              "draft-31 Sec. 5.4, 5.6", ["ASPA record for AS210"], settling_size=0),
            otc={"present": True, "value": 200}))

F.append(sc("A11-as-set", "Received path contains an AS_SET.",
            CHAIN, CHAIN_RECS, [300, [64500, 64501], 400], 300, 200, 100,
            E("INVALID", "VALID", "INVALID", "AS_SET present: ASPA evaluates the route as Invalid.",
              "draft-31 Sec. 5.5 step 3")))

# ---------------------------------------------------------------- route servers
F.append(sc("R01-transparent-rs", "Transparent RS AS900 passes client AS300's route to client AS400.",
            [rs(900, 300), rs(900, 400)], [rec(300, [])], [300], 300, 900, 400,
            E("VALID", "VALID", "VALID",
              "No prepend by a transparent RS; RS-client receiver is exempt from the neighbour check; N = 1. "
              "An RS may send any route to an RS-client; sent with OTC = AS900.",
              "draft-31 Sec. 5.1, 5.5 step 2; RFC 9234 Sec. 3.1, 5")))

F.append(sc("R02-rs-client-leak", "RS-client AS300 sends a route from its provider AS200 to route server AS900.",
            [pc(100, 200), pc(200, 300), rs(900, 300)], [rec(100, []), rec(200, [100]), rec(300, [200])],
            [200, 100], 200, 300, 900,
            E("INVALID", "INVALID", "INVALID",
              "ASPA: authorized(AS100, AS200) = Not Provider+. Policy: RS-clients may send only customer/own routes "
              "to an RS; OTC=200 added on ingress, must not go to an RS.",
              "draft-31 Sec. 5.5; RFC 9234 Sec. 3.1, 5")))

F.append(sc("R03-nontransparent-rs", "Non-transparent RS AS900 prepends itself; client AS300 lists AS900 in its ASPA.",
            [rs(900, 300, False), rs(900, 400, False)], [rec(300, [900])], [300], 300, 900, 400,
            E("VALID", "VALID", "VALID", "authorized(AS300, AS900) = Provider+ (non-transparent RS registered).",
              "draft-31 Sec. 4, 5.5")))

F.append(sc("R04-rs-not-registered", "As R03 but AS300's ASPA declares no providers (forgot the RS).",
            [rs(900, 300, False), rs(900, 400, False)], [rec(300, [])], [300], 300, 900, 400,
            E("INVALID", "VALID", "INVALID",
              "AS300 must list non-transparent RS AS900 (Sec. 4); without it the receiver sees Not Provider+. "
              "A registration mistake causing a false INVALID; a data warning flags it.",
              "draft-31 Sec. 4, 5.5 step 4")))

# ---------------------------------------------------------------- complex / undeclared
F.append(sc("C01-complex-aspa-blind", "Hybrid AS200-AS300: AS200 is AS300's provider for this prefix, AS300 is "
            "AS200's provider for another. AS300 leaks this prefix to peer AS400.",
            [pc(100, 200), pc(200, 500),
             {"type": "complex", "ases": [200, 300], "prefix_roles": [
                 {"prefix": P, "type": "provider-customer", "provider": 200},
                 {"prefix": "198.51.100.0/24", "type": "provider-customer", "provider": 300}]},
             peer(300, 400)],
            [rec(500, [200]), rec(200, [100, 300]), rec(300, [200])], [200, 500], 200, 300, 400,
            E("VALID", "INVALID", "INVALID",
              "Both ASes correctly list each other (Sec. 4), so ASPA cannot see the per-prefix role and passes "
              "the path. The policy layer, using the role for THIS prefix, catches the leak.",
              "draft-31 Sec. 4, 6.4; RFC 9234 Sec. 3.1")))

F.append(sc("C02-complex-no-role", "Complex AS300-AS400 with no role for this prefix; AS300 sends a customer route.",
            [pc(300, 600), {"type": "complex", "ases": [300, 400]}], [rec(600, [300])], [600], 600, 300, 400,
            E("VALID", "VALID", "VALID",
              "ASPA uses the downstream fallback (Sec. 6.4) and passes. A customer route may go to any "
              "neighbour, so the missing role does not matter for policy.",
              "draft-31 Sec. 6.4, 5.6; RFC 9234 Sec. 3.1")))

F.append(sc("U01-relationship-undeclared", "AS300 sends a provider route to AS400; AS300-AS400 relationship not declared.",
            [pc(100, 200), pc(200, 300), pc(200, 500), pc(100, 400)],
            [rec(500, [200]), rec(200, [100]), rec(300, [200])], [200, 500], 200, 300, 400,
            E("UNKNOWN", "UNKNOWN", "UNKNOWN",
              "Both algorithms run: upstream INVALID, downstream VALID -> relationship-dependent. Policy: OK only "
              "if AS400 is a customer.", "project rule Q3; draft-31 Sec. 5.5, 5.6",
              ["relationship between AS400 and AS300"],
              any_record={"best": "VALID", "worst": "INVALID"},
              consistent={"best": "VALID", "worst": "INVALID"}, classification="UNDETERMINED",
              settling=[["REL:AS300-AS400"]])))

# ---------------------------------------------------------------- export policy
F.append(sc("P11-customer-to-provider", "Customer route to provider.",
            [pc(100, 200), pc(200, 300)], [rec(300, [200]), rec(200, [100])], [300], 300, 200, 100,
            E("VALID", "VALID", "VALID", "Customer routes may go to anyone.", "RFC 9234 Sec. 3.1")))

F.append(sc("P12-customer-to-peer", "Customer route to peer.",
            [pc(100, 200), pc(200, 300), peer(200, 210)], [rec(300, [200]), rec(200, [100])], [300], 300, 200, 210,
            E("VALID", "VALID", "VALID", "Allowed; sent with OTC = AS200 (egress rule 1).", "RFC 9234 Sec. 3.1, 5")))

F.append(sc("P13-provider-to-customer", "Provider route to customer.",
            [pc(100, 200), pc(200, 300)], [rec(100, []), rec(200, [100])], [100], 100, 200, 300,
            E("VALID", "VALID", "VALID", "Downstream path valid; any route may go to a customer.",
              "draft-31 Sec. 5.6; RFC 9234 Sec. 3.1")))

F.append(sc("P14-provider-to-peer", "Provider route to peer (classic leak).",
            [pc(100, 200), peer(200, 210)], [rec(100, []), rec(200, [100])], [100], 100, 200, 210,
            E("INVALID", "INVALID", "INVALID",
              "Both layers fail: Not Provider+ at AS100->AS200; valley-free and OTC egress rule 2.",
              "draft-31 Sec. 5.5; RFC 9234 Sec. 3.1, 5", suspected_leaker=200)))

F.append(sc("P15-peer-to-provider", "Peer route to provider.",
            [pc(100, 200), peer(200, 210)], [rec(210, []), rec(200, [100])], [210], 210, 200, 100,
            E("INVALID", "INVALID", "INVALID", "Not Provider+ at AS210->AS200; peer route may not go to a provider.",
              "draft-31 Sec. 5.5; RFC 9234 Sec. 3.1, 5", suspected_leaker=200)))

F.append(sc("P16-peer-to-customer", "Peer route to customer.",
            [pc(100, 200), peer(200, 210), pc(200, 300)], [rec(210, []), rec(200, [100])], [210], 210, 200, 300,
            E("VALID", "VALID", "VALID", "Downstream: 1 + 1 = 2 >= N 2 (one sideways hop allowed).",
              "draft-31 Sec. 5.6; RFC 9234 Sec. 3.1")))

PEER_RELS = [pc(210, 220), peer(200, 210), pc(200, 300), pc(100, 200)]
PEER_RECS = [rec(220, [210]), rec(210, []), rec(200, [100])]
F.append(sc("P17-otc-valid", "Peer AS210 sends its customer's route with OTC = AS210 (correct); export to customer.",
            PEER_RELS, PEER_RECS, [210, 220], 210, 200, 300,
            E("VALID", "VALID", "VALID", "OTC equals the peer's AS: no leak (ingress rule 2 not triggered).",
              "RFC 9234 Sec. 5"), otc={"present": True, "value": 210}))

F.append(sc("P18-otc-from-customer", "Customer AS300 sends a route carrying OTC = AS310 (AS300 got it from provider AS310).",
            [pc(100, 200), pc(200, 300), pc(310, 300)],
            [rec(310, status="missing"), rec(300, [200, 310]), rec(200, [100])], [300, 310], 300, 200, 100,
            E("UNKNOWN", "INVALID", "INVALID",
              "OTC ingress rule 1 proves the leak although ASPA cannot (AS310 has no record). A correct AS310 "
              "record would not list its customer AS300 -> ASPA is LATENT-INVALID.",
              "RFC 9234 Sec. 5; draft-31 Sec. 5.5", ["ASPA record for AS310"],
              consistent={"best": "INVALID", "worst": "INVALID"}, classification="LATENT-INVALID"),
            otc={"present": True, "value": 310}))

F.append(sc("P19-source-undeclared", "AS200 exports to its provider a route from AS300; AS200-AS300 relationship not declared.",
            [pc(100, 200)], [rec(300, [200]), rec(200, [100])], [300], 300, 200, 100,
            E("VALID", "UNKNOWN", "UNKNOWN",
              "Policy needs the source role. Prediction: AS300's signed ASPA lists AS200 as its provider, so the "
              "only consistent completion is 'AS300 is AS200's customer' -> LATENT-VALID.",
              "RFC 9234 Sec. 3.1", ["relationship between AS200 and AS300 (route source)"],
              any_record={"best": "VALID", "worst": "INVALID"}, consistent={"best": "VALID", "worst": "VALID"},
              classification="LATENT-VALID"), extra_ases=[300]))

F.append(sc("P20-otc-unknown", "As P17 but the OTC state of the received route is not given.",
            PEER_RELS, PEER_RECS, [210, 220], 210, 200, 300,
            E("VALID", "UNKNOWN", "UNKNOWN",
              "Absent or = AS210 -> fine; = another AS -> ingress rule 2 leak. OTC is the only uncertainty.",
              "RFC 9234 Sec. 5", ["OTC state of the received route"],
              any_record={"best": "VALID", "worst": "INVALID"}, classification="UNDETERMINED",
              settling=[["OTC"]]), otc=None))

F.append(sc("P21-roles-not-configured", "As P12 but BGP Roles are not configured.",
            [pc(100, 200), pc(200, 300), peer(200, 210)], [rec(300, [200]), rec(200, [100])], [300], 300, 200, 210,
            E("VALID", "VALID", "VALID", "OTC reported as NOT_APPLICABLE (roles not configured); valley-free passes.",
              "RFC 9234 Sec. 3.1; project rule Q5", otc_status="NOT_APPLICABLE"), roles=False))

F.append(sc("P22-export-exception", "Provider route to peer allowed by a local partial-transit exception.",
            [pc(100, 200), peer(200, 210)], [rec(100, []), rec(200, [100])], [100], 100, 200, 210,
            E("INVALID", "VALID", "INVALID",
              "Local policy may allow it, but the receiver's ASPA still sees Not Provider+ at AS100->AS200 and "
              "rejects it.", "draft-31 Sec. 5.5"),
            roles=False, exceptions=[{"learned_from": 100, "receiving_as": 210, "reason": "paid partial transit"}]))

# ---------------------------------------------------------------- combined / special
F.append(sc("X01-receiver-loop", "Receiver AS100 already appears in the path (Q8: warning, not input error).",
            [pc(100, 200), pc(100, 300), pc(200, 300)], [rec(100, []), rec(300, [100, 200]), rec(200, [100])],
            [300, 100], 300, 200, 100,
            E("INVALID", "VALID", "INVALID", "AS300 leaked AS100's route; AS100 would also drop it by loop detection.",
              "draft-31 Sec. 5.5; RFC 4271 Sec. 9.1.2", receiver_loop=True)))

F.append(sc("X02-stale-record", "AS200's ASPA still lists former provider AS300 (now its customer). AS300 leaks to peer AS400.",
            [pc(100, 200), pc(200, 300), pc(200, 500), peer(300, 400)],
            [rec(500, [200]), rec(200, [100, 300]), rec(300, [200])], [200, 500], 200, 300, 400,
            E("VALID", "INVALID", "INVALID",
              "Over-permissive record makes authorized(AS200, AS300) = Provider+, hiding the leak from ASPA. "
              "Policy catches it; a data warning flags the stale record.", "draft-31 Sec. 5.3; RFC 9234 Sec. 3.1")))

F.append(sc("L01-local-origin", "AS200 originates the prefix and sends it to provider AS100.",
            [pc(100, 200)], [rec(200, [100])], [], None, 200, 100,
            E("VALID", "VALID", "VALID", "N = 1; locally originated routes may go anywhere.",
              "draft-31 Sec. 5.5; RFC 9234 Sec. 3.1")))

F.append(sc("M01-invalid-signature", "As A01 but AS400's ASPA fails signature validation.",
            CHAIN, [rec(400, status="invalid_signature")] + CHAIN_RECS[1:], [300, 400], 300, 200, 100,
            E("UNKNOWN", "VALID", "UNKNOWN", "A record that fails validation counts as no record (No Attestation).",
              "draft-31 Sec. 5.3", ["ASPA record for AS400"], classification="LATENT-VALID")))


def main() -> None:
    """Write every fixture to tests/fixtures/ (old files are removed first)."""
    OUT.mkdir(parents=True, exist_ok=True)
    for old in OUT.glob("*.json"):
        old.unlink()
    for f in F:
        (OUT / f"{f['scenario_id']}.json").write_text(json.dumps(f, indent=2) + "\n")
    print(f"wrote {len(F)} fixtures to {OUT}")


if __name__ == "__main__":
    main()
