# Templates for your own data

## 1. Check one route export
Copy `my_route.json`, edit it, then run:

    python3 main.py --input examples/templates/my_route.json
    python3 main.py --input examples/templates/my_route.json --json     # machine-readable

Fields to edit:
- `topology.ases`              every AS you mention anywhere
- `topology.relationships`     `provider-customer` {provider, customer}, `peer` {ases:[a,b]},
                               `route-server` {rs, client, transparent}, `complex` {ases, prefix_roles}
- `aspa_records`               status `present` (+ providers list; [] = no providers),
                               `missing`, or `invalid_signature`
- `route.as_path_received`     path as the exporter received it, NEWEST AS FIRST, origin last;
                               [] if the exporter originates the prefix (then learned_from = null)
- `route.learned_from`         must equal the first AS of the path
- `route.otc`                  {"present": false} | {"present": true, "value": AS} | null (unknown)
- `export`                     exporting_as, receiving_as, prepend_count
- `policy_context`             bgp_roles_configured: true / false / null;
                               optional export_exceptions: [{learned_from, receiving_as, reason}]

Check a whole folder of your files:  python3 main.py --input my_folder --summary

## 2. Plan an ASPA change
Copy `my_change.json` (kind "aspa-change"), edit topology_before/after and aspa_before/after, run:

    python3 main.py --input examples/templates/my_change.json --plan

Only provider-customer and peer links are supported by the planner.
